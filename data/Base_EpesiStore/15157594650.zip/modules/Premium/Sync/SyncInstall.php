<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license Commercial
 * @version 1.0
 * @package epesi-premium
 * @subpackage sync
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SyncInstall extends ModuleInstall {
    const version = '1.5.1';

	public function install() {
		$ret = DB::CreateTable('premium_sync_password',"user_login_id I KEY, password C(256) NOTNULL",array('constraints' => ', FOREIGN KEY (user_login_id) REFERENCES user_login(id)'));
		if($ret===false) {
			print('Invalid SQL query - premium_sync_password table install');
			return false;
		}
		return true;
	}
	
	public function uninstall() {
		return DB::DropTable('premium_sync_password');
	}
	
	public function version() {
		return array(self::version);
	}
	
	public function requires($v) {
		return array(
			array('name'=>'Base/Lang','version'=>0),
			array('name'=>'Utils/RecordBrowser','version'=>0));
	}
	
	public static function info() {
		return array(
			'Description'=>'Synchronization Module',
			'Author'=>'abisaga@telaxus.com',
			'License'=>'Commercial');
	}
	
    public static function simple_setup() {
        return array('package'=>__('Data synchronization engine'), 'version' => self::version);
    }
	
}

?>