<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_user()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

$modules = DB::GetAssoc('SELECT tab, caption FROM recordbrowser_table_properties ORDER BY caption ASC');
if (ModuleManager::is_installed('CRM_Calendar')>=0) {
	$modules = array('__agenda' => 'Agenda')+$modules;
}

print('<?xml version="1.0"?>');
print('<modules>');
foreach ($modules as $k=>$v) {
	print('<module>');
	print('<id>'.$k.'</id>');
	print('<label>'.$v.'</label>');
	print('</module>');
}
print('</modules>');


?>