<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage el
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='Μηχανισμός Συγχρονισμού Δεδομένων';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
