<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='Systém synchronizace';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
