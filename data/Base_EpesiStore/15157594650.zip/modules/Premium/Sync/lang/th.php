<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage th
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
