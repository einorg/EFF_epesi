<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fr
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='Processus de synchronisation des données';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
