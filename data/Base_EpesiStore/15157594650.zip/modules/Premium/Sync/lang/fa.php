<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='موتور همگام سازی داده ها';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
