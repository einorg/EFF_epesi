<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage in
 */
global $translations;
$translations['Data synchronization engine']='';
