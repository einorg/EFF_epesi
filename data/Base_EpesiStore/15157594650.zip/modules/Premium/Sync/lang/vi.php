<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage vi
 */
global $translations;
$translations['Sync']='';
$translations['Data synchronization engine']='Phương tiện đồng bộ hóa dữ liệu';
$translations['New sync password']='';
$translations['Confirm new sync password']='';
$translations['User password']='';
$translations['User password incorrect']='';
