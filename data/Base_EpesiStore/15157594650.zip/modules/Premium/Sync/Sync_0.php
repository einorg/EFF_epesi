<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license Commercial
 * @version 1.0
 * @package epesi-premium
 * @subpackage sync
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Sync extends Module {
    public function body() {
        if(!Base_AclCommon::i_am_user()) {
            print(__('First log in to the system.'));
            return;
        }

        $form = $this->init_module(Libs_QuickForm::module_name(),__('Saving settings'));

        //pass
        $form->addElement('header', null, __('Change password'));
        $form->addElement('html','<tr><td colspan=2>'.__('Leave password boxes empty if you prefer your current password').'</td></tr>');
        $form->addElement('password','new_pass',__('New sync password'));
        $form->addElement('password','new_pass_c',__('Confirm new sync password'));
        $form->addRule(array('new_pass', 'new_pass_c'), __('Your passwords don\'t match'), 'compare');
        $form->addRule('new_pass', __('Your password must be longer then 5 chars'), 'minlength', 6);

        //confirmation
        $form->addElement('header', null, __('Confirmation'));
        $form->addElement('password','user_pass', __('User password'));
        $form->registerRule('check_user_pass', 'callback', 'check_user_pass', $this);
        $form->addRule('user_pass', __('User password incorrect'), 'check_user_pass');
        $form->addRule('user_pass', __('Field required'), 'required');

        Base_ActionBarCommon::add('back',__('Back'),$this->create_main_href('Base_User_Settings'));
        Base_ActionBarCommon::add('save',__('Save'),$form->get_submit_form_href());

        if($form->validate_with_message('Setting saved',__('Problem encountered'))) {
            if($form->process(array(&$this, 'submit_user_preferences'))){
                Base_BoxCommon::location('Base_User_Settings');
            }
        } else {
            $form->display();
        }
    }

    public function submit_user_preferences($data) {
        $pass = $data['new_pass'];
        
        $user_id = Acl::get_user();
        if($user_id===null) {
            print(__('Not logged in!'));
            return false;
        }

        $pass_hash = function_exists('password_hash')?password_hash($pass,PASSWORD_DEFAULT):md5($pass);
        DB::Execute('DELETE FROM premium_sync_password WHERE user_login_id=%d', array($user_id));
        DB::Execute('INSERT INTO premium_sync_password(password,user_login_id) VALUES(%s,%d)', array($pass_hash, $user_id));
        return true;
    }

    public function check_user_pass($pass) {
        return Base_User_LoginCommon::check_login(Base_UserCommon::get_my_user_login(), $pass);
    }
}

?>