<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_user()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

if (!isset($_REQUEST['module_id'])) {
	header('HTTP/1.1 400 Bad Request');
	die('<response>ERROR</response>');
}

$module_id = $_REQUEST['module_id'];
if (isset($_REQUEST['last_sync_date'])) {
	$last_sync_date = $_REQUEST['last_sync_date'];
	$crits = array('>=:Edited_on'=>$_REQUEST['last_sync_date']);
} else {
	$last_sync_date = false;
	$crits = array();
}

Utils_RecordBrowserCommon::init($module_id);

$callbacks = DB::GetAssoc('SELECT id, handler_callback FROM crm_calendar_custom_events_handlers');
ob_start();
if ($module_id == '__agenda') {
	$recs = CRM_Calendar_EventCommon::get_all(date('Y-m-d'), date('Y-m-d', strtotime('+1 month')), '()');
	$ret = array();
	foreach ($recs as $v) {
		$id = explode('#',$v['id']);
		$module_id = call_user_func($callbacks[$id[0]], 'recordset');
		$id = $id[1];
		$ret[$id] = array(
			'primary' => $v['title'],
			'secondary' => Base_RegionalSettingsCommon::seconds_to_words($v['duration']),
			'active' => true,
			'module' => $module_id
		);
	}
} else {
	$ret = array();
	$access = self::get_access($module_id, 'browse');
	if ($access !== false) {
		if ($access !== true) $crits = self::merge_crits_new($crits, $access);
		$recs = Utils_RecordBrowserCommon::get_records($module_id, $crits, array(), array(), array(), $last_sync_date?true:false);
		foreach ($recs as $v) {
			$ret[$v['id']] = array(
				'primary' => Premium_SyncCommon::get_primary_label($module_id, $v['id']),
				'secondary' => Premium_SyncCommon::get_secondary_label($module_id, $v['id']),
				'active' => isset($v[':active'])?$v[':active']:true,
				'module' => $module_id
			);
		}
	}
}
ob_get_clean();

print('<?xml version="1.0"?>');
print('<records>');

foreach ($ret as $k=>$v) {
	print('<record>');
	print('<module>'.$v['module'].'</module>');
	print('<id>'.$k.'</id>');
	if (!$v['active'])
		print('<action>'.'DELETED'.'</action>');
	print('<primarylabel>'.htmlspecialchars($v['primary']).'</primarylabel>');
//	print('<secondarylabel>'.htmlspecialchars($v['secondary']).'</secondarylabel>');
	print('</record>');
}
print('</records>');


?>