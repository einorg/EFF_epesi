<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

header("Content-type: text/xml"); 

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_user()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

if (!isset($_REQUEST['table'])) {
	header('HTTP/1.1 400 Bad Request');
	die('<response>ERROR</response>');
}

$table = $_REQUEST['table'];

$array = Utils_CommonDataCommon::get_array($table);

print('<?xml version="1.0"?>');
print('<table>');
foreach ($array as $k=>$v) {
	print('<row>');
	print('<key>'.$k.'</key>');
	print('<value>'.htmlspecialchars($v).'</value>');
	print('</row>');
}
print('</table>');


?>