<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

@DB::CreateTable('premium_sync_password',"user_login_id I KEY, password C(256) NOTNULL",array('constraints' => ', FOREIGN KEY (user_login_id) REFERENCES user_login(id)'));
