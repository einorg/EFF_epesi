<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_user()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

if (!isset($_REQUEST['module_id']) || !isset($_REQUEST['record_id'])) {
	header('HTTP/1.1 400 Bad Request');
	die('<response>ERROR</response>');
}

$module_id = $_REQUEST['module_id'];
$record_id = $_REQUEST['record_id'];

/*if ($module_id=='__calendar'){
	$id = explode('#', $record_id);
	$callback = DB::GetOne('SELECT handler_callback FROM crm_calendar_custom_events_handlers WHERE id=%d', $id[0]);
	$module_id = call_user_func($callback, 'recordset');
	$record_id = $id[1];
}*/

Utils_RecordBrowserCommon::init($module_id);

if ($record_id!='NEW') {
	if(!isset($_REQUEST['last_sync_date'])) {
		header('HTTP/1.1 400 Bad Request');
		die('<response>ERROR</response>');
	}
	$last_sync_date = $_REQUEST['last_sync_date'];
	if (!is_numeric($last_sync_date)) $last_sync_date = strtotime($last_sync_date);

	$rec = Utils_RecordBrowserCommon::get_record($module_id, $record_id);
	$view_access = Utils_RecordBrowserCommon::get_access($module_id, 'view', $rec);
	$edit_access = Utils_RecordBrowserCommon::get_access($module_id, 'edit', $rec);
	if (!$rec) {
		header('HTTP/1.1 404 Not found');
		die('<response>ERROR</response>');
	}
	if (!$view_access || !$edit_access) {
		header('HTTP/1.1 403 Forbidden');
		die('<response>ERROR</response>');
	}

	Utils_RecordBrowserCommon::init($module_id);
	$ret = DB::Execute('SELECT * FROM '.$module_id.'_edit_history WHERE edited_on>=%T AND '.$module_id.'_id=%d',array(date('Y-m-d H:i:s', $last_sync_date), $record_id));
	if (!$ret->EOF) {
		die('<response>DIRTY_READ</response>');
	}

	$values = array();
	foreach ($rec as $k=>$v) {
		if (!isset(Utils_RecordBrowserCommon::$hash[$k])) continue;
		if (isset($view_access[$k]) && !$view_access[$k]) continue;
		if (isset($edit_access[$k]) && !$edit_access[$k]) continue;
		if (isset($_REQUEST['f_'.$k])) {
			$value = $_REQUEST['f_'.$k];
			if (Utils_RecordBrowserCommon::$table_rows[Utils_RecordBrowserCommon::$hash[$k]]['type']=='multiselect') {
				$value = Utils_RecordBrowserCommon::decode_multi($value);
			}
			$values[$k] = $value;
		}
	}

	Utils_RecordBrowserCommon::update_record($module_id, $record_id, $values);
	print('<response>OK</response>');
} else {
	$values = array();
	Utils_RecordBrowserCommon::init($module_id);
	$add_access = Utils_RecordBrowserCommon::get_access($module_id, 'add', array());
	if (!$add_access) {
		header('HTTP/1.1 403 Forbidden');
		die('<response>ERROR</response>');
	}
	foreach ($_REQUEST as $k=>$v) if (strpos($k, 'f_')!==false) {
		$k = str_replace('f_','',$k);
		if (!isset(Utils_RecordBrowserCommon::$hash[$k])) continue;
		if (Utils_RecordBrowserCommon::$table_rows[Utils_RecordBrowserCommon::$hash[$k]]['type']=='multiselect') {
			$v = Utils_RecordBrowserCommon::decode_multi($v);
		}
		$values[$k] = $v;
	}
	$record_id = Utils_RecordBrowserCommon::new_record($module_id, $values);
	print('<response>'.$record_id.'</response>');
}

?>
