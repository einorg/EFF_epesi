<?php
define('CID',false);

require_once('../../../include.php');

ModuleManager::load_modules();

header("Content-type: text/xml"); 

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!isset($_REQUEST['login']) || !isset($_REQUEST['password'])) {
	header('HTTP/1.1 400 Bad Request');
	die('<response>ERROR</response>');
}

$login = $_REQUEST['login'];
$password = $_REQUEST['password'];

if (Premium_SyncCommon::check_login($login, $password)) {
	Acl::set_user(Base_UserCommon::get_user_id($login));
	if (!defined('LOGIN_CHECK')) die('<response>OK</response>');
} else {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

?>