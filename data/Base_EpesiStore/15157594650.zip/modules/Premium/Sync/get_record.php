<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_user()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

if (!isset($_REQUEST['module_id']) || !isset($_REQUEST['record_id'])) {
	header('HTTP/1.1 400 Bad Request');
	die('<response>ERROR</response>');
}

$module_id = $_REQUEST['module_id'];
$record_id = $_REQUEST['record_id'];

/*if ($module_id=='__calendar'){
	$id = explode('#', $record_id);
	$callback = DB::GetOne('SELECT handler_callback FROM crm_calendar_custom_events_handlers WHERE id=%d', $id[0]);
	$module_id = call_user_func($callback, 'recordset');
	$record_id = $id[1];
}*/

Utils_RecordBrowserCommon::init($module_id);

if ($record_id=='DEFAULT')
	$rec = Premium_SyncCommon::get_default_record($module_id);
else
	$rec = Utils_RecordBrowserCommon::get_record($module_id, $record_id);

$hash = Utils_RecordBrowserCommon::$hash;
$table_rows = Utils_RecordBrowserCommon::$table_rows;
if ($record_id=='DEFAULT') {
	$view_access = $edit_access = true;
} else {
	$view_access = Utils_RecordBrowserCommon::get_access($module_id, 'view', $rec);
	$edit_access = Utils_RecordBrowserCommon::get_access($module_id, 'edit', $rec);
}

if (!$rec) {
	header('HTTP/1.1 404 Not found');
	die('<response>RECORD_NOT_FOUND</response>');
}

if (!$view_access) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NO_ACCESS</response>');
}

print('<?xml version="1.0"?>');
print('<record>');

foreach ($rec as $k=>$v) {
	if (!isset($hash[$k])) continue;
	if (isset($view_access[$k]) && !$view_access[$k]) continue;
	if (isset($edit_access[$k]) && !$edit_access[$k]) $acc = 'read-only';
	else $acc = 'full';
	$field = $table_rows[$hash[$k]];
	if ($field['type']=='multiselect') $v = Utils_RecordBrowserCommon::encode_multi($v);

	$value = Utils_RecordBrowserCommon::get_val($module_id, $k, $rec, true);
	$value = str_replace(array('&nbsp;','<br>'), array(' ',"\n"), $value);
	$value = htmlspecialchars($value);

	print('<field>');
	print('<id>'.htmlspecialchars($k).'</id>');
	print('<label>'.htmlspecialchars($field['name']).'</label>');
	print('<value>'.$value.'</value>');
	print('<rawvalue>'.htmlspecialchars($v).'</rawvalue>');
	print('<permission>'.$acc.'</permission>');
	print('<type>'.($field['type']=='commondata'?'select':$field['type']).'</type>');
	print('<required>'.$field['required'].'</required>');
	print('<param>');
	print(Premium_SyncCommon::format_param($module_id, $field, $rec));
	print('</param>');
	print('</field>');
}

print('</record>');

?>