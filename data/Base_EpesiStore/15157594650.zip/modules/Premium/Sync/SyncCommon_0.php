<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license Commercial
 * @version 1.0
 * @package epesi-premium
 * @subpackage sync
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SyncCommon extends ModuleCommon {
	public static function get_primary_label($tab, $id) {
		$str = Utils_RecordBrowserCommon::create_default_linked_label($tab, $id, true, false);
		$str = strip_tags($str);
		return $str;
	}

	public static function get_secondary_label($tab, $id) {
		return '';
	}
	
	public static function format_param($tab, $field, $record) {
		$result = 'RAW!'.serialize($field['param']);
		$param = $field['param'];
		switch ($field['type']) {
			case 'multiselect': 
			case 'select': 		if ($param=='') {
									$QF = DB::GetOne('SELECT callback FROM '.$tab.'_callback WHERE field=%s AND freezed=%d', array($field['name'], 0));
									if ($QF=='CRM_ContactsCommon::QFfield_company_contact') {
										$result = '<specialfield>company_contact</specialfield>';
										break;
									}
								}
								$param = explode(';', $param);
								$first = explode('::', $param[0]);
								if ($first[0]=='__COMMON__') {
									$result = '<source>COMMONDATA</source>';
									$result .= '<order>'.'value'.'</order>';
									$result .= '<array>'.$first[1].'</array>';
									break;
								}
								$result = '<source>'.$first[0].'</source>';
								if (!isset($first[1])) $first[1] = '';
								$result .= '<fields>'.preg_replace('/[^a-z0-9]/','_',strtolower($first[1])).'</fields>';
								
								if (!isset($param[1])) $param[1] = '';
								if (!isset($param[2])) $param[2] = '';
								if ($first[0]=='contact') 
									$second = explode('::', $param[2]);
								else
									$second = explode('::', $param[1]);
								if (is_callable($second))
									$second = call_user_func($second, $record, true, $field);
								else
									$second = '';
								$result .= '<crits>'.self::format_crits($first[0], $second).'</crits>';
								
								if ($first[0]=='contact') 
									$third = explode('::', $param[1]);
								else
									$third = explode('::', $param[2]);
								if (is_callable($third)) {
									$value = self::get_formatting_record($first[0]);
									$third = @call_user_func($third, $value, true, $field);
								} else
									$third = '';
								$result .= '<format>'.$third.'</format>';
								break;
			case 'commondata': 	$result = '<source>COMMONDATA</source>';
								$result .= '<order>'.($param['order_by_key']?'key':'value').'</order>';
								$result .= '<array>'.$param['array_id'].'</array>';
								break;
			case 'long text':
			case 'text':		$result = '<maxlength>'.$param.'</maxlength>';
								break;
			case 'calculated':
			case 'timestamp':
			case 'checkbox':
			case 'integer':
			case 'hidden':
			case 'time':
			case 'date':		$result = '';
								break;
		}
		return $result;
	}
	
	public static function get_formatting_record($tab) {
		Utils_RecordBrowserCommon::init($tab);
		$record = array();
		foreach (Utils_RecordBrowserCommon::$table_rows as $t) {
			$record[$t['id']] = '{'.$t['id'].'}';
		}
		return $record;
	}

	public static function get_default_record($tab) {
		Utils_RecordBrowserCommon::init($tab);
		$record = array();
		foreach (Utils_RecordBrowserCommon::$table_rows as $t) {
			$record[$t['id']] = '';
		}
		$record = @Utils_RecordBrowserCommon::record_processing($tab, $record, 'adding');
		$record['id'] = 'DEFAULT';
		return $record;
	}
	
	public static function format_crits($tab, $crits) {
		if (!$tab || !$crits || $tab == '__RECORDSETS__' || strpos($tab, ',') !== false) return '';
		$preparsed = Utils_RecordBrowserCommon::build_query($tab, $crits);
		$formatted = $preparsed['sql'];
		$formatted = substr($formatted, 13+strpos($formatted, 'active=1'));
		$formatted = str_replace('\\', '', $formatted);
		$formatted = str_replace('r.f_', '', $formatted);
		$formatted = preg_replace('/\(false OR ((\([^)]+\)[^)]*)+)\)/', '($1)', $formatted);
		$formatted = preg_replace('/CONCAT\(\'\%\'\,([^,]+)\,\'\%\'\)/', '$1', $formatted);
		$formatted = vsprintf($formatted, $preparsed['vals']);
		return $formatted;
	}
	
	public static function check_login($username, $pass) {
		$hash = DB::GetOne('SELECT p.password FROM user_login u JOIN premium_sync_password p ON u.id=p.user_login_id WHERE u.login=%s AND u.active=1', array($username));
		if(!$hash) return false;
		if(strlen($hash)==32) //md5
		    return md5($pass)==$hash;
		return password_verify($pass,$hash);
	}

	public static function user_settings() {
		if(Base_AclCommon::i_am_user()) return array(__('Sync')=>'body');
		return array();
	}
}

?>