<?php
define('LOGIN_CHECK',true);
require_once('authenticate.php');

header("Content-type: text/xml"); 

if (ModuleManager::is_installed('Premium_Sync')<0) {
	header('HTTP/1.1 403 Forbidden');
	die('<response>NA</response>');
}

if (!Acl::is_admin()) {
	header('HTTP/1.1 401 Unauthorized');
	die('<response>ERROR</response>');
}

global $translations;
global $custom_translations;
Base_LangCommon::load();

$strings = array();
if (!isset($translations['Premium_Sync'])) $translations['Premium_Sync'] = array();
if (!isset($custom_translations['Premium_Sync'])) $custom_translations['Premium_Sync'] = array();
foreach ($translations['Premium_Sync'] as $k=>$v)
	$strings[$k] = $v;
foreach ($custom_translations['Premium_Sync'] as $k=>$v) 
	$strings[$k] = $v;

print('<?xml version="1.0"?>');
print('<strings>');
foreach ($strings  as $k=>$v) {
	print('<string>');
	print('<original>'.htmlspecialchars($k).'</original>');
	print('<translated>'.htmlspecialchars($v).'</translated>');
	print('</string>');
}
print('</strings>');


?>