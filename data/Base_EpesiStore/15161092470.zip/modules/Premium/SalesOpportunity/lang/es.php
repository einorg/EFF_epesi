<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage es
 */
global $translations;
$translations['Events']='Actividades';
$translations['Sales Opportunity']='Oportunidades';
$translations['Follow-up Date']='Fecha Seguimiento';
$translations['Contract Amount']='Suma de Contrato';
$translations['Sales Opportunities']='Oportunidades';
$translations['Lists Sales opportunities']='Listado de Oportunidades';
$translations['Opportunity Name']='Nombre Oportunidad';
$translations['Probability (%%)']='Probabilidad (%%)';
$translations['New Sales Opportunity']='Nueva Oportunidad de Venta';
$translations['Opportunity Manager']='Gestor de la Oportunidad';
$translations['Lead Source']='Origen / Fuente';
$translations['Close Date']='Fecha de Cierre';
$translations['Prospecting']='Prospección';
$translations['Evaluation']='Evaluación';
$translations['Negotiations']='Negociación';
$translations['Contract Won']='Contrato Ganado';
$translations['Contract Lost']='Contrato Perdido';
$translations['New Customer']='No Cliente';
$translations['Existing Customer']='Cliente (Nuevo Proyecto)';
$translations['Web Site']='Página Web';
$translations['Referral']='Referencia';
$translations['Advert']='Anuncio';
