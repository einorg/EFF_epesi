<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ja
 */
global $translations;
$translations['Events']='イベント';
$translations['Sales Opportunity']='販売機会';
$translations['Follow-up Date']='フォローアップ日付';
$translations['Contract Amount']='契約金額';
$translations['Sales Opportunities']='販売機会';
$translations['Lists Sales opportunities']='販売機会表';
$translations['Opportunity Name']='機会名称';
$translations['Probability (%%)']='見込み (%%)';
$translations['New Sales Opportunity']='新規販売機会';
$translations['Opportunity Manager']='機会管理者';
$translations['Lead Source']='リードソース';
$translations['Close Date']='終了日';
$translations['Prospecting']='見透し';
$translations['Evaluation']='評価';
$translations['Negotiations']='交渉';
$translations['Contract Won']='契約受注';
$translations['Contract Lost']='契約失注';
$translations['New Customer']='新規顧客';
$translations['Existing Customer']='既存顧客';
$translations['Web Site']='ウェブサイト';
$translations['Referral']='参照';
$translations['Advert']='宣伝';
