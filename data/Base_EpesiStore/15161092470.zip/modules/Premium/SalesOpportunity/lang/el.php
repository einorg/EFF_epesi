<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage el
 */
global $translations;
$translations['Events']='Γεγονότα';
$translations['Sales Opportunity']='Προσφορές';
$translations['Follow-up Date']='';
$translations['Contract Amount']='';
$translations['Sales Opportunities']='Προσφορές';
$translations['Lists Sales opportunities']='Λίστα Προσφορών';
$translations['Opportunity Name']='';
$translations['Probability (%%)']='Πιθανότητα (%%)';
$translations['New Sales Opportunity']='Ευκαιρία για Νέα Πώληση';
$translations['Opportunity Manager']='Πωλητής';
$translations['Lead Source']='';
$translations['Close Date']='';
$translations['Prospecting']='';
$translations['Evaluation']='';
$translations['Negotiations']='';
$translations['Contract Won']='';
$translations['Contract Lost']='';
$translations['New Customer']='';
$translations['Existing Customer']='';
$translations['Web Site']='';
$translations['Referral']='';
$translations['Advert']='';
