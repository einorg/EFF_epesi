<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage et
 */
global $translations;
$translations['Events']='Sündmused';
$translations['Sales Opportunity']='';
$translations['Follow-up Date']='';
$translations['Contract Amount']='';
$translations['Sales Opportunities']='';
$translations['Lists Sales opportunities']='';
$translations['Opportunity Name']='';
$translations['Probability (%%)']='';
$translations['New Sales Opportunity']='';
$translations['Opportunity Manager']='';
$translations['Lead Source']='';
$translations['Close Date']='';
$translations['Prospecting']='';
$translations['Evaluation']='';
$translations['Negotiations']='';
$translations['Contract Won']='';
$translations['Contract Lost']='';
$translations['New Customer']='';
$translations['Existing Customer']='';
$translations['Web Site']='';
$translations['Referral']='';
$translations['Advert']='';
