<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ro
 */
global $translations;
$translations['Events']='Evenimente';
$translations['Sales Opportunity']='Oportunitati vanzari';
$translations['Follow-up Date']='Data urmarire';
$translations['Contract Amount']='Total Comanda';
$translations['Sales Opportunities']='Oportunitati de vanzare';
$translations['Lists Sales opportunities']='';
$translations['Opportunity Name']='Denumire oportunitate';
$translations['Probability (%%)']='Probabilitate (%%)';
$translations['New Sales Opportunity']='Oportunitate vanzari noua';
$translations['Opportunity Manager']='';
$translations['Lead Source']='';
$translations['Close Date']='Data sfarsit';
$translations['Prospecting']='Prospectare';
$translations['Evaluation']='Evaluare';
$translations['Negotiations']='Negocieri';
$translations['Contract Won']='Contract castigat';
$translations['Contract Lost']='Contract pierdut';
$translations['New Customer']='';
$translations['Existing Customer']='';
$translations['Web Site']='';
$translations['Referral']='';
$translations['Advert']='';
