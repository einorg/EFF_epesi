<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Events']='رویدادها';
$translations['Sales Opportunity']='فرصت فروش';
$translations['Follow-up Date']='تاریخ پیگیری';
$translations['Contract Amount']='مبلغ قرارداد';
$translations['Sales Opportunities']='فرصت های فروش';
$translations['Lists Sales opportunities']='فهرست کردن فرصت های فروش';
$translations['Opportunity Name']='نام فرصت';
$translations['Probability (%%)']='احتمال(%%)';
$translations['New Sales Opportunity']='فرصت فروش جدید';
$translations['Opportunity Manager']='مدیریت فرصت';
$translations['Lead Source']='منبع برگزیده';
$translations['Close Date']='تاریخ اتمام';
$translations['Prospecting']='در حال پیگیری';
$translations['Evaluation']='در حال بررسی';
$translations['Negotiations']='در حال مذاکره';
$translations['Contract Won']='قرارداد پیروز شده';
$translations['Contract Lost']='قرارداد از دست رفته';
$translations['New Customer']='مشتری جدید';
$translations['Existing Customer']='مشتری موجود';
$translations['Web Site']='وب سایت';
$translations['Referral']='مراجعه';
$translations['Advert']='تبلیغات';
