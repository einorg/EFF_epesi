<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Events']='Ereignisse';
$translations['Sales Opportunity']='Verkaufsgelegenheit';
$translations['Follow-up Date']='Wiedervorlagedatum';
$translations['Contract Amount']='Auftragsvolumen';
$translations['Sales Opportunities']='Verkaufsgelegenheiten';
$translations['Lists Sales opportunities']='Listet mögliche Aufträge';
$translations['Opportunity Name']='Absatzchance Beschreibung';
$translations['Probability (%%)']='Chancen in (%%)';
$translations['New Sales Opportunity']='Neue Absatzchance';
$translations['Opportunity Manager']='Absatzchance Manager';
$translations['Lead Source']='Ursprung';
$translations['Close Date']='Beendet am';
$translations['Prospecting']='Kundensuche';
$translations['Evaluation']='Abklärung';
$translations['Negotiations']='Verhandlungen';
$translations['Contract Won']='Auftrag bekommen';
$translations['Contract Lost']='Auftrag verloren';
$translations['New Customer']='Neuer Kunde';
$translations['Existing Customer']='Bestehender Kunde';
$translations['Web Site']='Webseite';
$translations['Referral']='Empfehlung';
$translations['Advert']='Inserat';
