<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sk
 */
global $translations;
$translations['Events']='Události';
$translations['Sales Opportunity']='Obchodné príležitosti';
$translations['Follow-up Date']='Ďalší dátum';
$translations['Contract Amount']='Hodnota kontraktu';
$translations['Sales Opportunities']='Obchodné príležitosti';
$translations['Lists Sales opportunities']='Zoznam obchodných príležitosti';
$translations['Opportunity Name']='Názov príležitosti';
$translations['Probability (%%)']='Pravdepodobnosť';
$translations['New Sales Opportunity']='Nová obchodná príležitosť';
$translations['Opportunity Manager']='Obchodný manažér';
$translations['Lead Source']='Pôvod príležitosti';
$translations['Close Date']='Dátum ukončenia';
$translations['Prospecting']='Prieskum';
$translations['Evaluation']='Hodnotenie';
$translations['Negotiations']='Rokovania';
$translations['Contract Won']='Kontrakt úspešný';
$translations['Contract Lost']='Kontrakt stratený';
$translations['New Customer']='Nový zákaznik';
$translations['Existing Customer']='Existujúci zákazník';
$translations['Web Site']='Web stránka';
$translations['Referral']='Referencia';
$translations['Advert']='Reklama';
