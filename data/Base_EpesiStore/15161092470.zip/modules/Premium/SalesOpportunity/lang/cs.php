<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Events']='Události';
$translations['Sales Opportunity']='Zakázka';
$translations['Follow-up Date']='Další datum';
$translations['Contract Amount']='Hodnota kontraktu';
$translations['Sales Opportunities']='Zakázky';
$translations['Lists Sales opportunities']='Seznam zakázek';
$translations['Opportunity Name']='Název';
$translations['Probability (%%)']='Pravděpodobnost (%%)';
$translations['New Sales Opportunity']='Nová zakázka';
$translations['Opportunity Manager']='Obchodní manažer';
$translations['Lead Source']='Vznik poptávky';
$translations['Close Date']='Skončeno dne';
$translations['Prospecting']='Poptávání';
$translations['Evaluation']='Nacenění';
$translations['Negotiations']='Vyjednávání';
$translations['Contract Won']='Kontrakt vyhrán';
$translations['Contract Lost']='Kontrakt prohrán';
$translations['New Customer']='Nový zákazník';
$translations['Existing Customer']='Stávající zákazník';
$translations['Web Site']='Web';
$translations['Referral']='Reference';
$translations['Advert']='Reklama';
