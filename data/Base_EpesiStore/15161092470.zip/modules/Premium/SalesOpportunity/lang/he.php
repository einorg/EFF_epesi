<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage he
 */
global $translations;
$translations['Events']='אירועים';
$translations['Sales Opportunity']='הזדמנויות מכירה';
$translations['Follow-up Date']='תאריך מעקב';
$translations['Contract Amount']='סכום חוזה';
$translations['Sales Opportunities']='הזדמנויות מכירה';
$translations['Lists Sales opportunities']='רשימת הזדמנויות מכירה';
$translations['Opportunity Name']='תיאור הזדמנות \\ הזמנה';
$translations['Probability (%%)']='הסתברות באחוזים';
$translations['New Sales Opportunity']='הזדמנויות מכירה חדשות';
$translations['Opportunity Manager']='מנהל הזדמנות \\ הזמנה';
$translations['Lead Source']='מקור הלייד';
$translations['Close Date']='תאריך סגירה';
$translations['Prospecting']='סיקור';
$translations['Evaluation']='הערכה';
$translations['Negotiations']='משא ומתן';
$translations['Contract Won']='זכיה במכרז';
$translations['Contract Lost']='הפסד במכרז';
$translations['New Customer']='לקוח חדש';
$translations['Existing Customer']='לקוח קיים';
$translations['Web Site']='אתר אינטרנט';
$translations['Referral']='הפניה';
$translations['Advert']='פרסומת';
