<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fr
 */
global $translations;
$translations['Events']='Evènements';
$translations['Sales Opportunity']='Devis et contrats';
$translations['Follow-up Date']='Date de suivi';
$translations['Contract Amount']='Montant contrat';
$translations['Sales Opportunities']='Opportunités de ventes';
$translations['Lists Sales opportunities']='Possibilités listes de ventes';
$translations['Opportunity Name']='Intitulé du devis/contrat';
$translations['Probability (%%)']='Probabilité (%%)';
$translations['New Sales Opportunity']='Nouveau devis/contrat';
$translations['Opportunity Manager']='Gestion des devis/contrats';
$translations['Lead Source']='';
$translations['Close Date']='Date de fin';
$translations['Prospecting']='';
$translations['Evaluation']='';
$translations['Negotiations']='';
$translations['Contract Won']='';
$translations['Contract Lost']='';
$translations['New Customer']='';
$translations['Existing Customer']='Client existant';
$translations['Web Site']='Site Web';
$translations['Referral']='';
$translations['Advert']='Pub';
