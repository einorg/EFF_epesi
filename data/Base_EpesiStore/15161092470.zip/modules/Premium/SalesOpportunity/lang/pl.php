<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Events']='Wydarzenia';
$translations['Sales Opportunity']='Szansa Sprzedaży';
$translations['Follow-up Date']='Data Sprawdzenia';
$translations['Contract Amount']='Kwota transakcji';
$translations['Sales Opportunities']='Szanse Sprzedaży';
$translations['Lists Sales opportunities']='Lista ofert handlowych';
$translations['Opportunity Name']='Nazwa Oferty';
$translations['Probability (%%)']='Prawdopodobieństwo (%%):';
$translations['New Sales Opportunity']='Nowa szansa sprzedaży';
$translations['Opportunity Manager']='Kierownik projektu';
$translations['Lead Source']='Źródło';
$translations['Close Date']='Data zamknięcia';
$translations['Prospecting']='Poszukiwania';
$translations['Evaluation']='Ewaluacja';
$translations['Negotiations']='Negocjacje';
$translations['Contract Won']='Kontrakt Wygrany';
$translations['Contract Lost']='Oferta Odrzucona';
$translations['New Customer']='Nowy klient';
$translations['Existing Customer']='Istniejący klient';
$translations['Web Site']='Strona internetowa';
$translations['Referral']='Polecenie';
$translations['Advert']='Ogłoszenie';
