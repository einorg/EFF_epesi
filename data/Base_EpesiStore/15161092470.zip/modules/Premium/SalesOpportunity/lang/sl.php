<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sl
 */
global $translations;
$translations['Events']='Dogodki';
$translations['Sales Opportunity']='Ponudba';
$translations['Follow-up Date']='Spremljaj / Preveri';
$translations['Contract Amount']='Znesek ponudbe (brez DDV)';
$translations['Sales Opportunities']='Ponudbe';
$translations['Lists Sales opportunities']='Seznam ponudb';
$translations['Opportunity Name']='Št. in kratek opis ponudbe';
$translations['Probability (%%)']='Verjetnost uspeha (%%)';
$translations['New Sales Opportunity']='Nova ponudba';
$translations['Opportunity Manager']='Nosilec';
$translations['Lead Source']='Vir ponudbe';
$translations['Close Date']='Velja do';
$translations['Prospecting']='Obetajoča';
$translations['Evaluation']='Ocenjena';
$translations['Negotiations']='Pogajanja';
$translations['Contract Won']='Realizirana';
$translations['Contract Lost']='Zavrnjena';
$translations['New Customer']='Nov kupec';
$translations['Existing Customer']='Obstoječi kupec';
$translations['Web Site']='Splet';
$translations['Referral']='Povpraševanje';
$translations['Advert']='Oglaševanje';
