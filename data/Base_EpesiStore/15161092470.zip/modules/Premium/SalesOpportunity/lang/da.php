<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage da
 */
global $translations;
$translations['Events']='Events';
$translations['Sales Opportunity']='Salgsmulighed';
$translations['Follow-up Date']='Opfølgning Dato';
$translations['Contract Amount']='Kontrakt Beløb';
$translations['Sales Opportunities']='Salgsmuligheder';
$translations['Lists Sales opportunities']='Lister salgsmuligheder';
$translations['Opportunity Name']='Muligheden Name';
$translations['Probability (%%)']='Sandsynlighed (%%)';
$translations['New Sales Opportunity']='Ny Salgsmulighed';
$translations['Opportunity Manager']='Muligheden manager';
$translations['Lead Source']='Føre Source';
$translations['Close Date']='Luk Dato';
$translations['Prospecting']='Forundersøgelse';
$translations['Evaluation']='Evaluering';
$translations['Negotiations']='Forhandlingerne';
$translations['Contract Won']='Kontrakt Vandt';
$translations['Contract Lost']='Kontrakt Tabt';
$translations['New Customer']='Ny kunde';
$translations['Existing Customer']='Eksisterende kunde';
$translations['Web Site']='Hjemmeside';
$translations['Referral']='Henvisning';
$translations['Advert']='Annonce';
