<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt
 */
global $translations;
$translations['Events']='';
$translations['Sales Opportunity']='Oportunidade de Venda';
$translations['Follow-up Date']='Data de acompanhamento';
$translations['Contract Amount']='Valor do Contrato';
$translations['Sales Opportunities']='Oportunidades de Venda';
$translations['Lists Sales opportunities']='Lista de Oportunidade de vendas';
$translations['Opportunity Name']='Nome da oportunidade';
$translations['Probability (%%)']='Probabilidade';
$translations['New Sales Opportunity']='Nova Oportunidade de Venda';
$translations['Opportunity Manager']='Gerente de Oportunidade';
$translations['Lead Source']='Origem';
$translations['Close Date']='Data de encerramento';
$translations['Prospecting']='prospecção';
$translations['Evaluation']='avaliação';
$translations['Negotiations']='Negociações';
$translations['Contract Won']='Negócio fechado';
$translations['Contract Lost']='Negócio perdido';
$translations['New Customer']='Novo Cliente';
$translations['Existing Customer']='Cliente Existente';
$translations['Web Site']='';
$translations['Referral']='';
$translations['Advert']='';
