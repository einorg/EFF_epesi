<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hr
 */
global $translations;
$translations['Events']='Događaji';
$translations['Sales Opportunity']='Natječaj';
$translations['Follow-up Date']='Datum revizije';
$translations['Contract Amount']='Ugovorna vrijednost';
$translations['Sales Opportunities']='Natječaji';
$translations['Lists Sales opportunities']='Ispiši natječaje';
$translations['Opportunity Name']='Naziv natječaja';
$translations['Probability (%%)']='Mogučnost (%%)';
$translations['New Sales Opportunity']='Novi natječaj';
$translations['Opportunity Manager']='Odgovorni';
$translations['Lead Source']='Glavni izvor';
$translations['Close Date']='Datum završetka';
$translations['Prospecting']='Potencijalno';
$translations['Evaluation']='Evaluacija';
$translations['Negotiations']='Pregovori';
$translations['Contract Won']='Natječaj dobiven';
$translations['Contract Lost']='Natječaj izgubljen';
$translations['New Customer']='Novi partner';
$translations['Existing Customer']='Postojeći partner';
$translations['Web Site']='Web stranica';
$translations['Referral']='Preporuka';
$translations['Advert']='Oglas';
