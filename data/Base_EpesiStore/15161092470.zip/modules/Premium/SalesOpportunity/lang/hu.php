<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hu
 */
global $translations;
$translations['Events']='';
$translations['Sales Opportunity']='Értékesítési lehetőség';
$translations['Follow-up Date']='Követési dátum';
$translations['Contract Amount']='';
$translations['Sales Opportunities']='Értékesítési lehetőségek ';
$translations['Lists Sales opportunities']='';
$translations['Opportunity Name']='Lehetőség megnevezése';
$translations['Probability (%%)']='';
$translations['New Sales Opportunity']='';
$translations['Opportunity Manager']='';
$translations['Lead Source']='';
$translations['Close Date']='';
$translations['Prospecting']='Kilátás';
$translations['Evaluation']='Kiértékelés';
$translations['Negotiations']='Megállapodások';
$translations['Contract Won']='A szerződést megnyerte';
$translations['Contract Lost']='A szerződés elveszett';
$translations['New Customer']='';
$translations['Existing Customer']='';
$translations['Web Site']='';
$translations['Referral']='';
$translations['Advert']='';
