<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage nl
 */
global $translations;
$translations['Events']='Gebeurtenissen';
$translations['Sales Opportunity']='Verkoop mogelijkheid';
$translations['Follow-up Date']='';
$translations['Contract Amount']='';
$translations['Sales Opportunities']='Potentiele Clienten / Wachtlijst';
$translations['Lists Sales opportunities']='Lijst potentiele clienten';
$translations['Opportunity Name']='Naam Potentiele Client';
$translations['Probability (%%)']='';
$translations['New Sales Opportunity']='Nieuwe potentiele client';
$translations['Opportunity Manager']='Begeleider';
$translations['Lead Source']='';
$translations['Close Date']='';
$translations['Prospecting']='';
$translations['Evaluation']='Evaluatie';
$translations['Negotiations']='';
$translations['Contract Won']='Contract gewonnen';
$translations['Contract Lost']='Contract verloren';
$translations['New Customer']='Nieuwe klant';
$translations['Existing Customer']='Bestaande klant';
$translations['Web Site']='Website';
$translations['Referral']='';
$translations['Advert']='Advertentie';
