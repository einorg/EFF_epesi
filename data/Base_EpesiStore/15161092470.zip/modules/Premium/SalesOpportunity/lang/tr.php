<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage tr
 */
global $translations;
$translations['Events']='Olaylar';
$translations['Sales Opportunity']='Satış Teklifi';
$translations['Follow-up Date']='Takip tarihi';
$translations['Contract Amount']='Sözleşme Tutarı';
$translations['Sales Opportunities']='Satış Teklifleri';
$translations['Lists Sales opportunities']='Satış Raporlarını listele';
$translations['Opportunity Name']='Teklif Adı';
$translations['Probability (%%)']='Olasılık (%%)';
$translations['New Sales Opportunity']='Yeni Satış Teklifi';
$translations['Opportunity Manager']='Teklif Sorumlusu';
$translations['Lead Source']='Müşteri Kaynağı';
$translations['Close Date']='Kapanış Tarihi';
$translations['Prospecting']='Araştırma';
$translations['Evaluation']='Deneme';
$translations['Negotiations']='Görüşmeler';
$translations['Contract Won']='Kazanılan şözleşme';
$translations['Contract Lost']='Kaybedilen Sözleşme';
$translations['New Customer']='Yeni Müşteri';
$translations['Existing Customer']='Mevcut Müşteri';
$translations['Web Site']='Web Sitesi';
$translations['Referral']='Referans';
$translations['Advert']='Reklam';
