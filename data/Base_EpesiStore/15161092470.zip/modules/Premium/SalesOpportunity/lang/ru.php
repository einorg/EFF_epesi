<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ru
 */
global $translations;
$translations['Events']='События';
$translations['Sales Opportunity']='Заказы / Продажи';
$translations['Follow-up Date']='Дата обр.связи';
$translations['Contract Amount']='Сумма сделки';
$translations['Sales Opportunities']='Заказы и продажи';
$translations['Lists Sales opportunities']='Списки продаж';
$translations['Opportunity Name']='Название заказа / продажи ';
$translations['Probability (%%)']='Рентабельность (%%)';
$translations['New Sales Opportunity']='Новая продажа';
$translations['Opportunity Manager']='Ответственный';
$translations['Lead Source']='Источник';
$translations['Close Date']='Закрыть дату';
$translations['Prospecting']='Диагностика';
$translations['Evaluation']='Оценка';
$translations['Negotiations']='Ожидание комплектующих';
$translations['Contract Won']='Сделка состоялась';
$translations['Contract Lost']='Сделка не состоялась';
$translations['New Customer']='Новый клиент';
$translations['Existing Customer']='Существующий клиент';
$translations['Web Site']='Сайт';
$translations['Referral']='Реферрал';
$translations['Advert']='Реклама';
