<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage lt
 */
global $translations;
$translations['Events']='Įvykiai';
$translations['Sales Opportunity']='Objektai';
$translations['Follow-up Date']='Sekanti data';
$translations['Contract Amount']='Sutarties suma';
$translations['Sales Opportunities']='Potencialas';
$translations['Lists Sales opportunities']='Objektų sąrašas';
$translations['Opportunity Name']='Objekto pavadinimas';
$translations['Probability (%%)']='Tikimybė';
$translations['New Sales Opportunity']='Naujas objektas';
$translations['Opportunity Manager']='Atsakingas vadybininkas';
$translations['Lead Source']='Info šaltinis';
$translations['Close Date']='Pabaigos data';
$translations['Prospecting']='Svajonės';
$translations['Evaluation']='Vykdomas';
$translations['Negotiations']='Pasiūlymas';
$translations['Contract Won']='Laimėtas';
$translations['Contract Lost']='Pralaimėtas';
$translations['New Customer']='Naujas klientas';
$translations['Existing Customer']='Esamas klientas';
$translations['Web Site']='Tinklapis';
$translations['Referral']='Pagal nukreipimą';
$translations['Advert']='Reklama';
