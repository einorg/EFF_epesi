<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt_PT
 */
global $translations;
$translations['Events']='Eventos';
$translations['Sales Opportunity']='Oportunidades';
$translations['Follow-up Date']='';
$translations['Contract Amount']='';
$translations['Sales Opportunities']='Oportunidades';
$translations['Lists Sales opportunities']='Lista de oportunidades';
$translations['Opportunity Name']='Nome da oportunidade';
$translations['Probability (%%)']='Probabilidade (%%)';
$translations['New Sales Opportunity']='Nova oportunidade';
$translations['Opportunity Manager']='Gestor da oportunidade';
$translations['Lead Source']='Fonte da pista';
$translations['Close Date']='';
$translations['Prospecting']='';
$translations['Evaluation']='Avaliação';
$translations['Negotiations']='Negociações';
$translations['Contract Won']='';
$translations['Contract Lost']='';
$translations['New Customer']='Novo cliente';
$translations['Existing Customer']='Cliente existente';
$translations['Web Site']='Sítio';
$translations['Referral']='Referenciador';
$translations['Advert']='Anúncio';
