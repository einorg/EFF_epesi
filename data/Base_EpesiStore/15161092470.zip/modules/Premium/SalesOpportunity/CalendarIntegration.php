<?php

/**
 * WARNING: This is a commercial software
 * Please see the included license.html file for more information
 *
 * @author Adam Bukowski <abukowski@telaxus.com>, Norbert Nader
 * @copyright Copyright &copy; 2016, Telaxus LLC
 * @license Commercial
 * @version 0.1
 * @package epesi-premium
 * @subpackage salesopportunity
 */
class Premium_SalesOpportunity_CalendarIntegration {

    /**
     * @var $rs RBO_RecordsetAccessor
     */
    private $rs;

    function __construct() {
        $this->rs = new RBO_RecordsetAccessor('premium_salesopportunity');
    }

    public static function handler($action) {
        $args = func_get_args();
        array_shift($args);
        $obj = new self();
        return call_user_func_array(array($obj, $action), $args);
    }

    public function get_all($start, $end, $filter) {
        $crits = array();
        // if $filter is other than ALL
        if ($filter != '()') {
            $contacts_crits = explode(',', trim($filter, '()'));
            $crits = rb_or(array(
                    'employees' => $contacts_crits,
                    'customers' => $contacts_crits,
                    'opportunity_manager' => $contacts_crits
                )
            );
        }
        $crits = rb_and($crits, rb_and(array('<=follow_up_date' => $end, '>=follow_up_date' => $start)));

        $ret = array();
        $records = $this->rs->get_records($crits);
        foreach ($records as $r) {
            $ret[] = $this->get($r);
        }
        return $ret;
    }

    public function update($id, $start, $duration, $timeless) {
        if ($timeless != 'timeless') return false;
        $record = $this->rs->get_record($id);
        $access = Utils_RecordBrowserCommon::get_access($this->rs->table_name(), 'edit', $record);
        $field = 'follow_up_date';
        if (is_array($access) && isset($access[$field]) && $access[$field]) {
            $new_date = date('Y-m-d', $start);
            if ($new_date != $record->follow_up_date) {
                $record->follow_up_date = $new_date;
                $record->save();
            }
            return true;
        }
        return false;
    }

    public function get($id) {
        $record = null;
        if (is_numeric($id)) {
            $record = $this->rs->get_record($id);
        } else {
            $record = is_array($id) ? $this->rs->record_to_object($id) : $id;
        }

        $event = array('type' => __('Sales Opportunity'));
        $event['id'] = $record->id;
        $event['start'] = strtotime($record->follow_up_date);
        $event['timeless'] = $record->follow_up_date;
        $event['duration'] = -1;
        $event['title'] = $record->opportunity_name;
        $event['description'] = $record->description;
        $event['status'] = 'active';
        $event['color'] = 'magenta';
        $event['delete_action'] = false;
        $event['view_action'] = Utils_RecordBrowserCommon::create_record_href($this->rs->table_name(), $record->id, 'view');
        $event['custom_tooltip'] =
            '<center><b>'.
            __('Sales Opportunity').
            '</b></center><br>'.
            Utils_RecordBrowserCommon::default_record_tooltip($this->rs->table_name(), $record->id).'<hr>'.
            CRM_ContactsCommon::get_html_record_info($record['created_by'],$record['created_on'],null,null);

        return $event;
    }

    public function delete($id) {
        if (!Utils_RecordBrowserCommon::get_access($this->rs->table_name(), 'delete', $this->rs->get_record($id)))
            return false;
        $this->rs->delete_record($id);
        return true;
    }

    public function new_event_types() {
        return array(array('label' => __('Sales Opportunity'), 'icon' => null));
    }

    public function new_event($timestamp, $timeless, $id, $object, $cal_obj) {
        $rb = $this->rs->create_rb_module($cal_obj);
        $defaults = $rb->custom_defaults;
        $defaults['follow_up_date'] = date('Y-m-d', $timestamp);
        Base_BoxCommon::push_module('Utils_RecordBrowser', 'view_entry',
            array('add', null, $defaults), $this->rs->table_name());
    }

    public function view_event($id, $cal_obj) {
        $rb = $this->rs->create_rb_module($cal_obj);
        $rb->view_entry('view', $id);
    }

    public function edit_event($id, $cal_obj) {
        $rb = $this->rs->create_rb_module($cal_obj);
        $rb->view_entry('edit', $id);
    }

    public function recordset() {
        return 'premium_salesopportunity';
    }
}