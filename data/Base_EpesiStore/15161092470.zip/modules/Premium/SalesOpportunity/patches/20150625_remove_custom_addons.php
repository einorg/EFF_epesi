<?php

defined("_VALID_ACCESS") || die('Direct access forbidden');

class RemoveCustomAddonsPatch
{

    protected static $recordset = 'premium_salesopportunity';
    protected static $custom_field = 'opportunity';
    protected static $custom_field_name = 'Opportunity';
    protected static $related_field = 'related';


    protected static function new_related($rs)
    {
        $related_tab = $rs . '_related';
        $arr = array('recordset' => self::$recordset);
        if (Utils_RecordBrowserCommon::check_table_name($related_tab, false, false)) {
            $records = Utils_RecordBrowserCommon::get_records_count($related_tab, $arr);
            if (!$records) {
                Utils_RecordBrowserCommon::new_record($related_tab, $arr);
            }
        }
    }

    public static function run()
    {
        if (ModuleManager::is_installed('CRM_Tasks') >= 0) {
            self::handle_related_rs('task');
        }
        if (ModuleManager::is_installed('CRM_PhoneCall') >= 0) {
            self::handle_related_rs('phonecall');
        }
        if (ModuleManager::is_installed('CRM_Meeting') >= 0) {
            self::handle_related_rs('crm_meeting');
        }
    }

    protected static function handle_related_rs($rs)
    {
        $cp = Patch::checkpoint("checkpoint_$rs");
        if ($cp->is_done()) {
            return;
        }

        if ($cp->get('add_related', true)) {
            self::new_related($rs);
            $cp->set('add_related', false);
        }

        $next_id_to_process = $cp->get('id', 1);
        $per_chunk = 50;
        while (($records = Utils_RecordBrowserCommon::get_records($rs, array('>=id' => $next_id_to_process), array(), array(), $per_chunk, true))) {
            foreach ($records as $r) {
                if ($r['id'] >= $next_id_to_process) {
                    Patch::require_time(1);
                    if (!isset($r[self::$custom_field])) {
                        // no field at all - exit!
                        $cp->done();
                        return;
                    }

                    if ($r[self::$custom_field]) {
                        $related = $r[self::$related_field];
                        $related[] = self::$recordset . '/' . $r[self::$custom_field];
                        $values = array(self::$related_field => array_unique($related));
                        Utils_RecordBrowserCommon::update_record($rs, $r['id'], $values, false, null, true);
                    }
                }
                $next_id_to_process = $r['id'] + 1;
                $cp->set('id', $next_id_to_process);
            }
        }

        Utils_RecordBrowserCommon::delete_record_field($rs, self::$custom_field_name);
        $cp->done();
    }
}

RemoveCustomAddonsPatch::run();
