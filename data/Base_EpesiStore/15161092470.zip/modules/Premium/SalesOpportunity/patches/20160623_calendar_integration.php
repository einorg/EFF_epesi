<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

CRM_CalendarCommon::new_event_handler(_M('Sales Opportunities'), array('Premium_SalesOpportunity_CalendarIntegration', 'handler'));

