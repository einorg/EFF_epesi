<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

$meta = Utils_RecordBrowserCommon::init('premium_salesopportunity');
if(isset($meta['Probability'])) {
    Utils_RecordBrowserCommon::new_record_field('premium_salesopportunity',array('name' => _M('Probability (%%)'), 'type'=>'integer', 'required'=>true, 'visible'=>true, 'extra'=>false,'position'=>'Probability'));
    DB::Execute('UPDATE premium_salesopportunity_data_1 SET f_probability____=f_probability');
    Utils_RecordBrowserCommon::delete_record_field('premium_salesopportunity','Probability');
}
