<?php

defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::set_display_callback('premium_salesopportunity', 'Employees', array('Premium_SalesOpportunityCommon', 'display_employees'));