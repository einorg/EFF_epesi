<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

if (ModuleManager::is_installed('CRM_Tasks')>=0)
	Utils_RecordBrowserCommon::new_record_field('task', _M('Opportunity'), 'select', true, false, 'premium_salesopportunity::Opportunity Name;Premium_SalesOpportunityCommon::crm_opportunity_reference_crits', '', false);
if (ModuleManager::is_installed('CRM_PhoneCall')>=0)
	Utils_RecordBrowserCommon::new_record_field('phonecall', _M('Opportunity'), 'select', true, false, 'premium_salesopportunity::Opportunity Name;Premium_SalesOpportunityCommon::crm_opportunity_reference_crits', '', false);
if (ModuleManager::is_installed('CRM_Meeting')>=0)
	Utils_RecordBrowserCommon::new_record_field('crm_meeting', _M('Opportunity'), 'select', true, false, 'premium_salesopportunity::Opportunity Name;Premium_SalesOpportunityCommon::crm_opportunity_reference_crits', '', false);

?>