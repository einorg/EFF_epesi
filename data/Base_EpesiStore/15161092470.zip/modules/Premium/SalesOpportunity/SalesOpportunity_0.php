<?php
/**
 * Sales Opportunity Tracker
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunity extends Module {
	private $rb;

	public function body() {
		$this->rb = $this->init_module('Utils/RecordBrowser','premium_salesopportunity','premium_salesopportunity');
		$this->rb->set_header_properties(array(
						'notes'=>array('width'=>10, 'wrapmode'=>'nowrap'),
						'customers'=>array('wrapmode'=>'nowrap')
						));
		// set defaults
		$me = CRM_ContactsCommon::get_my_record();
		$this->rb->set_defaults(array('opportunity_manager'=>$me['id'], 'employees'=>$me['id'], 'start_date'=>date('Y-m-d'), 'status'=>0));
		$this->rb->set_header_properties(array(
			'start_date'=>array('width'=>'80px'),
			'follow_up_date'=>array('width'=>'80px'),
			'close_date'=>array('width'=>'80px'),
			'notes'=>array('width'=>'30px'),
			'status'=>array('width'=>'8')
			));
        $sts = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status', true);
        $trans = array('__NULL__'=>array(), '__ALL_ACTIVE__'=>array('status'=>array(0,1,2,3,4,5,6,7,8,9)));
        foreach ($sts as $k=>$v)
            $trans[$k] = array('status'=>$k);
        $this->rb->set_custom_filter('status',array('type'=>'select','label'=>__('Status'),'args'=>array('__NULL__'=>'['.__('All').']','__ALL_ACTIVE__'=>'['.__('All active').']')+$sts,'trans'=>$trans));
		$this->display_module($this->rb);
	}

	public function applet($conf, & $opts) {
		$opts['go'] = true;
		$opts['title'] = __('Sales Opportunity');
		$me = CRM_ContactsCommon::get_my_record();
		if ($me['id']==-1) {
			CRM_ContactsCommon::no_contact_message();
			return;
		}
		$rb = $this->init_module('Utils/RecordBrowser','premium_salesopportunity','premium_salesopportunity');
		$statuss = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status');
		$status = array();
		foreach ($statuss as $i=>$v)
			if (isset($conf['status_'.$i]) && $conf['status_'.$i]) $status[] = $i;
		$crits = array();
		$crits['status'] = $status;
		$crits['employees'] = array($me['id']);
		if ($conf['follow_up_date']!=-1) {
			$crits['(<=follow_up_date'] = date('Y-m-d', strtotime('+'.$conf['follow_up_date'].' days'));
			$crits['|follow_up_date'] = '';
		}
		$conds = array(
									array(	array('field'=>'opportunity_name', 'width'=>20),
											array('field'=>'follow_up_date', 'width'=>10),
											array('field'=>'status', 'width'=>10)
										),
									$crits,
									array('follow_up_date'=>'ASC','status'=>'ASC'),
									array('Premium_SalesOpportunityCommon','applet_info_format'),
									15,
									$conf,
									& $opts
				);
		$opts['actions'][] = Utils_RecordBrowserCommon::applet_new_record_button('premium_salesopportunity',array('employees'=>array($me['id']),'status'=>0, 'start_date'=>date('Y-m-d')));
		$this->display_module($rb, $conds, 'mini_view');
	}

	public function caption(){
		if (isset($this->rb)) return $this->rb->caption();
	}
	
	public function contact_addon($arg) {
		$rb = $this->init_module('Utils/RecordBrowser','premium_salesopportunity','premium_salesopportunity');
		$params = array(array('customers'=>'P:'.$arg['id']), array('customers'=>false), array('id'=>'DESC'));

		$me = CRM_ContactsCommon::get_my_record();
		$rb->set_defaults(array('customers'=>'P:'.$arg['id'], 'opportunity_manager'=>$me['id'], 'employees'=>$me['id'], 'start_date'=>date('Y-m-d'), 'status'=>0));
		$this->display_module($rb,$params,'show_data');
	}

	public function company_addon($arg) {
		$cus = array('C:'.$arg['id']);
		$cont = CRM_ContactsCommon::get_contacts(array('(company_name'=>$arg['id'],'|related_companies'=>array($arg['id'])) );
		foreach ($cont as $c) $cus[] = 'P:'.$c['id'];
		$rb = $this->init_module('Utils/RecordBrowser','premium_salesopportunity','premium_salesopportunity');
		$params = array(array('customers'=>$cus), array(), array('id'=>'DESC'));

		$me = CRM_ContactsCommon::get_my_record();
		$rb->set_defaults(array('customers'=>'C:'.$arg['id'], 'opportunity_manager'=>$me['id'], 'employees'=>$me['id'], 'start_date'=>date('Y-m-d'), 'status'=>0));
		$this->display_module($rb,$params,'show_data');
	}

	
	public function activities_addon($r) {
		$gb = $this->init_module('Utils_GenericBrowser',null,'activities_addon');
		$gb->set_table_columns(array(
				array('name'=>'Type', 'width'=>3),
				array('name'=>'Title', 'width'=>9),
				array('name'=>'Employees', 'width'=>9),
				array('name'=>'Date/Deadline', 'width'=>9)
			));
		$inc_task = (ModuleManager::is_installed('CRM_Tasks')>=0);
		$inc_meeting = (ModuleManager::is_installed('CRM_Meeting')>=0);
		$inc_phonecall = (ModuleManager::is_installed('CRM_PhoneCall')>=0);
		$count = 0;
        $rec_id = 'premium_salesopportunity/' . $r['id'];
		if ($inc_task) $count += $count_tasks = Utils_RecordBrowserCommon::get_records_count('task', array('related'=>$rec_id));
		if ($inc_phonecall) $count += $count_phonecalls = Utils_RecordBrowserCommon::get_records_count('phonecall', array('related'=>$rec_id));
		if ($inc_meeting) $count += $count_meetings = Utils_RecordBrowserCommon::get_records_count('crm_meeting', array('related'=>$rec_id));
		$limit = $gb->get_limit($count);
		$rec_limit = array('numrows'=>$limit['offset']+$limit['numrows'], 'offset'=>0);

		$tasks = array();
		$phonecalls = array();
		$meetings = array();
		if ($inc_task) $tasks = Utils_RecordBrowserCommon::get_records('task', array('related'=>$rec_id), array(), array('deadline'=>'DESC'));
		if ($inc_phonecall) $phonecalls = Utils_RecordBrowserCommon::get_records('phonecall', array('related'=>$rec_id), array(), array('date_and_time'=>'DESC'));
		if ($inc_meeting) $meetings = Utils_RecordBrowserCommon::get_records('crm_meeting', array('related'=>$rec_id), array(), array('date'=>'DESC', 'time'=>'DESC'));
		$activities = array();
		$count = 0;
		while ($count<$rec_limit['numrows']) {
			$task = reset($tasks);
			$phonecall = reset($phonecalls);
			$meeting = reset($meetings);
			if ($task) $task_tstamp = intval(strtotime($task['deadline']));
			else $task_tstamp = -1;
			if ($phonecall) $phonecall_tstamp = strtotime($phonecall['date_and_time']);
			else $phonecall_tstamp = -1;
			if ($meeting) $meeting_tstamp = strtotime($meeting['date'].' '.date('H:i:s',strtotime($meeting['time'])));
			else $meeting_tstamp = -1;
			if (!$task && !$meeting && !$phonecall) break;
			$pick = 'task';
			if ($phonecall_tstamp>$task_tstamp) $pick = 'phonecall';
			if ($meeting_tstamp>$task_tstamp && $meeting_tstamp>$phonecall_tstamp) $pick = 'meeting';
			switch ($pick) {
				case 'task':
						$task = array_shift($tasks);
						$arr = array(
							'Task',
							CRM_TasksCommon::display_title($task,false),
							CRM_ContactsCommon::display_contact(array('emp'=>$task['employees']),false,array('id'=>'emp','param'=>';CRM_ContactsCommon::contact_format_no_company')),
							$task['deadline']?Base_RegionalSettingsCommon::time2reg($task['deadline'],false,true,false):'---'
						);
						$tab = 'task';
						$id = $task['id'];
						break;
				case 'phonecall':
						$phonecall = array_shift($phonecalls);
						$arr = array(
							'Phonecall',
							CRM_PhoneCallCommon::display_subject($phonecall),
							CRM_ContactsCommon::display_contact(array('emp'=>$phonecall['employees']),false,array('id'=>'emp','param'=>';CRM_ContactsCommon::contact_format_no_company')),
							Base_RegionalSettingsCommon::time2reg($phonecall['date_and_time'], 'without_seconds',true,false)
						);
						$tab = 'phonecall';
						$id = $phonecall['id'];
						break;
				case 'meeting':
						$meeting = array_shift($meetings);
						$arr = array(
							'Meeting',
							CRM_MeetingCommon::display_title($meeting),
							CRM_ContactsCommon::display_contact(array('emp'=>$meeting['employees']),false,array('id'=>'emp','param'=>';CRM_ContactsCommon::contact_format_no_company')),
							Base_RegionalSettingsCommon::time2reg($meeting_tstamp, 'without_seconds')
						);
						$tab = 'crm_meeting';
						$id = $meeting['id'];
						break;
				default:
						$arr = array(
							'Error',
							$pick,
							serialize($$pick),
							''
						);
			}
			if ($count>=$limit['offset']) {
				$gb_row = $gb->get_new_row();
				$gb_row->add_data_array($arr);
				$gb_row->add_action(Utils_RecordBrowserCommon::create_record_href($tab, $id, 'view'), 'View');
				$gb_row->add_action(Utils_RecordBrowserCommon::create_record_href($tab, $id, 'edit'), 'Edit');
			}
			$count++;
		}
		$this->display_module($gb);
	}
}

?>