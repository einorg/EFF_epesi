<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage da
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='Salgsmedarbejder';
$translations['Total']='Total';
$translations['Sales Opportunity']='Salgsmulighed';
$translations['Projects - Report, %s']='Projekter - rapportere% s';
$translations['Projects_Report_%s']='Projects_Report_% s';
$translations['Sales Opportunities by Salesman']='Salgsmuligheder efter Salgsmedarbejder';
$translations['View Sales Report']='Vis salgsrapport';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Salgsmulighed Rapport';
