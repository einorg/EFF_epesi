<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Contracts Sold']='Kontrakt wygrany';
$translations['Salesman']='Sprzedawca';
$translations['Total']='Suma';
$translations['Sales Opportunity']='Szansa Sprzedaży';
$translations['Projects - Report, %s']='Projekty - Raport, %';
$translations['Projects_Report_%s']='Projekty_Raport_%';
$translations['Sales Opportunities by Salesman']='Szanse sprzedaży według Sprzedawcy';
$translations['View Sales Report']='Zobacz raport sprzedaży';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='Wartość kontraktu';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Raport Szans Sprzedaży';
