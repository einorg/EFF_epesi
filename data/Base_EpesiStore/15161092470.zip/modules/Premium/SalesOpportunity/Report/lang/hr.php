<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hr
 */
global $translations;
$translations['Contracts Sold']='Sklopljeno ugovora';
$translations['Salesman']='Trgovac';
$translations['Total']='Ukupno';
$translations['Sales Opportunity']='Natječaj';
$translations['Projects - Report, %s']='Projektno izvješće %s';
$translations['Projects_Report_%s']='Projektno izvješće %s';
$translations['Sales Opportunities by Salesman']='Mogućnosti prodaje po trgovcu';
$translations['View Sales Report']='Izvješće o prodaji';
$translations['No. of bids']='Broj ponuda';
$translations['Est. bids']='Procijenjena vrijednost';
$translations['Contracts Value']='Vrijednost ugovora';
$translations['%% Bids (qty)']='%% Ponuda';
$translations['%% Bids ($ value)']='%% Ponuda ($ vrijednost)';
$translations['Sales Opportunity Report']='Izvješće o natječajima';
