<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage tr
 */
global $translations;
$translations['Contracts Sold']='Satılan Kontratlar';
$translations['Salesman']='Satıcı';
$translations['Total']='Toplam';
$translations['Sales Opportunity']='Satış Teklifi';
$translations['Projects - Report, %s']='Proje - Raporları, %s';
$translations['Projects_Report_%s']='Proje_Raporları_&%s';
$translations['Sales Opportunities by Salesman']='Satış listeleri Satıcıya göre';
$translations['View Sales Report']='Satış Raporlarını Görüntüle';
$translations['No. of bids']='Hiçbir teklif';
$translations['Est. bids']='Teklif';
$translations['Contracts Value']='Kontrat Değeri';
$translations['%% Bids (qty)']='%% Adet (değer)';
$translations['%% Bids ($ value)']='%% Adet ($ değer)';
$translations['Sales Opportunity Report']='Satış Fırsat Raporları';
