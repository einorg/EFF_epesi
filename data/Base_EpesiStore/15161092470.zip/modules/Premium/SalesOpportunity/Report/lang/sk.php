<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sk
 */
global $translations;
$translations['Contracts Sold']='Predané kontrakty';
$translations['Salesman']='Obchodník';
$translations['Total']='Celkom';
$translations['Sales Opportunity']='Obchodné príležitosti';
$translations['Projects - Report, %s']='Projekty - Správa, %s';
$translations['Projects_Report_%s']='Projekty_Správa_%s';
$translations['Sales Opportunities by Salesman']='Obchodné príležitosti podľa obchodníka';
$translations['View Sales Report']='Zobraziť výkaz predaja';
$translations['No. of bids']='Počet ponúk';
$translations['Est. bids']='Odhad ponúk';
$translations['Contracts Value']='Hodnota kontraktov';
$translations['%% Bids (qty)']='%% ponuky (ks)';
$translations['%% Bids ($ value)']='%% Ponuky (EUR hodnota)';
$translations['Sales Opportunity Report']='Výkaz predajných príležitosti';
