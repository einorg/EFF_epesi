<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage es
 */
global $translations;
$translations['Contracts Sold']='Nº ofertas ganadas';
$translations['Salesman']='Comercial';
$translations['Total']='Total';
$translations['Sales Opportunity']='Oportunidades';
$translations['Projects - Report, %s']='Proyectos - Informe, %s';
$translations['Projects_Report_%s']='Proyectos_Informe_%s';
$translations['Sales Opportunities by Salesman']='Lista de Oportunidades por Comercial';
$translations['View Sales Report']='Ver Informe de Ventas';
$translations['No. of bids']='Nº ofertas presentadas';
$translations['Est. bids']='Valor ofertas presentadas';
$translations['Contracts Value']='Valor ofertas ganadas';
$translations['%% Bids (qty)']='%% Ganadas (sobre el nº total)';
$translations['%% Bids ($ value)']='%% Ganadas (Sobre el valor total)';
$translations['Sales Opportunity Report']='Informe de Oportunidades de Venta';
