<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='Obchodník';
$translations['Total']='Celkem';
$translations['Sales Opportunity']='Zakázka';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='Zobrazit zakázky podle obchodníka';
$translations['View Sales Report']='Zobrazit report zakázek';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Report zakázek';
