<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='فروشنده';
$translations['Total']='';
$translations['Sales Opportunity']='فرصت فروش';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='فرصت های فروش توسط فروشنده';
$translations['View Sales Report']='نمایش گزارش فروش';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='گزارش فرصت فروش';
