<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage he
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='איש מכירות';
$translations['Total']='';
$translations['Sales Opportunity']='הזדמנויות מכירה';
$translations['Projects - Report, %s']='%s ,פרוייקטים - דוחות';
$translations['Projects_Report_%s']='פרוייקטים_דוחות_%s';
$translations['Sales Opportunities by Salesman']='הזדמניות מכירה לפי איש מכירות';
$translations['View Sales Report']='צפיה בדוחות מכירה';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='דוח הזדמנויות מכירה';
