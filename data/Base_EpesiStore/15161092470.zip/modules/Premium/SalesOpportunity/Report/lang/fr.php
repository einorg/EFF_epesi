<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fr
 */
global $translations;
$translations['Contracts Sold']='Contrats vendus';
$translations['Salesman']='';
$translations['Total']='Total';
$translations['Sales Opportunity']='Devis et contrats';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='';
$translations['View Sales Report']='Voir le Rapport des Ventes';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='valeur des contrats';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Rapport sur les devis et contrats';
