<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hu
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='Értékesítő';
$translations['Total']='';
$translations['Sales Opportunity']='Értékesítési lehetőség';
$translations['Projects - Report, %s']='Projektek-jelentés, %s';
$translations['Projects_Report_%s']='Projektek_jelentés_ %s';
$translations['Sales Opportunities by Salesman']='Értékesítési lehetőségek értékesítőnként';
$translations['View Sales Report']='';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Értékesítési lehetőségek jelentés';
