<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Contracts Sold']='Abgeschlossen';
$translations['Salesman']='Verkäufer';
$translations['Total']='Gesamt';
$translations['Sales Opportunity']='Verkaufsgelegenheit';
$translations['Projects - Report, %s']='Projektbericht, %s';
$translations['Projects_Report_%s']='Projekt_Bericht_%s';
$translations['Sales Opportunities by Salesman']='Verkaufsgelegenheite pro Verkäufer';
$translations['View Sales Report']='Zeige Verkaufsreport';
$translations['No. of bids']='Anzahl Angebote';
$translations['Est. bids']='Angebote';
$translations['Contracts Value']='Auftragswert';
$translations['%% Bids (qty)']='%% Angebote (Anzahl)';
$translations['%% Bids ($ value)']='%% Angebote (in Euro)';
$translations['Sales Opportunity Report']='Verkaufsgelegenheit Report';
