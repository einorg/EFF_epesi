<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage lt
 */
global $translations;
$translations['Contracts Sold']='Parduota';
$translations['Salesman']='Pardavėjas';
$translations['Total']='';
$translations['Sales Opportunity']='Objektai';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='Objektai pagal pardavėjus';
$translations['View Sales Report']='Rodyti objektų ataskaitą';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='Sutarties vertė';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Objektų ataskaita';
