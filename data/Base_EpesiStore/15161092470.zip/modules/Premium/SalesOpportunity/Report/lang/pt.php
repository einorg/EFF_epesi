<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt
 */
global $translations;
$translations['Contracts Sold']='';
$translations['Salesman']='Vendedor';
$translations['Total']='';
$translations['Sales Opportunity']='Oportunidade de Venda';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='Oportunidades de Venda por vendedor';
$translations['View Sales Report']='Ver Oportunidades';
$translations['No. of bids']='';
$translations['Est. bids']='';
$translations['Contracts Value']='';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='';
