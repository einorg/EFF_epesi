<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage nl
 */
global $translations;
$translations['Contracts Sold']='Contracten verkocht';
$translations['Salesman']='Begeleider';
$translations['Total']='Totaal';
$translations['Sales Opportunity']='Verkoop mogelijkheid';
$translations['Projects - Report, %s']='';
$translations['Projects_Report_%s']='';
$translations['Sales Opportunities by Salesman']='Potentiele Clienten per begeleider';
$translations['View Sales Report']='';
$translations['No. of bids']='Aantal biedingen';
$translations['Est. bids']='';
$translations['Contracts Value']='Contracten waarde';
$translations['%% Bids (qty)']='';
$translations['%% Bids ($ value)']='';
$translations['Sales Opportunity Report']='Rapportage potentiele clienten';
