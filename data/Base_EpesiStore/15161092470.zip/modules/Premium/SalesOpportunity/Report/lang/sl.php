<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sl
 */
global $translations;
$translations['Contracts Sold']='Realizirano';
$translations['Salesman']='Prodajnik';
$translations['Total']='Vse skupaj';
$translations['Sales Opportunity']='Ponudba';
$translations['Projects - Report, %s']='Projekti - Poročilo, %s';
$translations['Projects_Report_%s']='Projekti_Poročilo_%s';
$translations['Sales Opportunities by Salesman']='Ponudbe - referenti';
$translations['View Sales Report']='Poglej ponudbe';
$translations['No. of bids']='Št. ponudb';
$translations['Est. bids']='Moje ponudbe';
$translations['Contracts Value']='Vrednost ponudb';
$translations['%% Bids (qty)']='%% Ponudb (kol)';
$translations['%% Bids ($ value)']='%% Ponudb (vrednost €)';
$translations['Sales Opportunity Report']='Ponudbe - poročilo';
