<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ja
 */
global $translations;
$translations['Contracts Sold']='売却済契約';
$translations['Salesman']='営業マン';
$translations['Total']='総計';
$translations['Sales Opportunity']='販売機会';
$translations['Projects - Report, %s']='プロジェクト - レポート, %s';
$translations['Projects_Report_%s']='プロジェクト_レポート_%s';
$translations['Sales Opportunities by Salesman']='営業マンの販売機会';
$translations['View Sales Report']='営業（販売）報告書の表示';
$translations['No. of bids']='入札数';
$translations['Est. bids']='入札成立';
$translations['Contracts Value']='契約価値';
$translations['%% Bids (qty)']='%% 入札（量）';
$translations['%% Bids ($ value)']='%% 入札（価格）';
$translations['Sales Opportunity Report']='販売機会報告書';
