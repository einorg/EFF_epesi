<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity-report
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunity_ReportInstall extends ModuleInstall {

	public function install() {
		Base_AclCommon::add_permission(_M('View Sales Report'),array('ACCESS:employee','ACCESS:manager'));
		return true;
	}
	
	public function uninstall() {
		Base_AclCommon::delete_permission('View Sales Report');
		return true;
	}
	
	public function version() {
		return array("1.0");
	}
	
	public function requires($v) {
		return array(
			array('name'=>'Utils/RecordBrowser/Reports','version'=>0),
			array('name'=>'Premium/SalesOpportunity','version'=>0));
	}
	
	public static function info() {
		return array(
			'Description'=>'',
			'Author'=>'Arkadiusz Bisaga <abisaga@telaxus.com>',
			'License'=>'<a href="modules/Custom/Projects/license.html" TARGET="_blank">Commercial</a>');
	}
	
	public static function simple_setup() {
		return array('package' => __('Sales Opportunity'));
	}
	
}

?>