<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity-report
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunity_ReportCommon extends ModuleCommon {
	public static function menu() {
		if (Base_AclCommon::check_permission('View Sales Report'))
			return array(_M('Reports')=>array('__submenu__'=>1, 
				_M('Sales Opportunities by Salesman')=>array()));
		return array();
	}
}

?>