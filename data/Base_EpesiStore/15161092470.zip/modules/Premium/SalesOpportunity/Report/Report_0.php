<?php
/**
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity-report
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunity_Report extends Module {
	private static $cats = null;
	private static $format = '';
	private static $dates = array();
	private static $range_type = '';
	private static $emp_type = '';
	private $rbr = null;

	public function construct() {
		$this->rbr = $this->init_module('Utils/RecordBrowser/Reports');
		self::$cats = array(__('No. of bids'), __('Est. bids'), __('Contracts Sold'), __('Contracts Value'), __('%% Bids (qty)'), __('%% Bids ($ value)'));
	}

	public function body() {
		$this->projects_report();
	}

	public function projects_report() {
		$this->rbr->set_reference_record_display_callback(array('CRM_ContactsCommon','contact_format_no_company'));
		$limit = array();
		$query = Utils_RecordBrowserCommon::build_query('premium_salesopportunity');
        $ids = DB::GetCol('SELECT DISTINCT(f_opportunity_manager) FROM '.$query['sql'], $query['vals']);
		$crits['id'] = $ids;
		$allContacts = Utils_RecordBrowserCommon::get_records('contact',$crits,array(),array('last_name'=>'ASC','first_name'=>'ASC'),$limit);
		$companies_ids = array();
		$js = array();
		foreach ($allContacts as $k=>$v) {
			$companies_ids[$v['company_name']] = $v['company_name'];
			$js[$v['company_name']][$k] = CRM_ContactsCommon::contact_format_no_company($v, true);
		}

		$companies = array('__NULL__'=>'---');
		ksort($companies_ids);
		foreach ($companies_ids as $id)
			$companies[$id] = $id?CRM_ContactsCommon::display_company($id, true):'['.__('w/o company').']';

		$form = $this->init_module('Libs/QuickForm');
		
		eval_js('var salesrep_options = '.json_encode($js).';');
		eval_js_once('update_salesmen=function(){
			jq("#salesrep_salesman").find("option").remove().end().append("<option value=\'\'>---</option>");
			jq.each(salesrep_options,function(i) {
				if(!jq("#salesrep_company").length || jq("#salesrep_company").val()==i) {
					var opts = salesrep_options[i];
					jq.each(opts,function(j) {
						opt = new Option();
						opt.text = salesrep_options[i][j];
						opt.value = j;
						jq("#salesrep_salesman").append(opt);
					});
				}
			});
		}');
		eval_js('update_salesmen();');

		if (count($companies_ids)>1) $form->addElement('select', 'company', __('Company'), $companies, array('id'=>'salesrep_company','onchange'=>'update_salesmen();'));
		$form->addElement('select', 'salesman', __('Salesman'), array(), array('id'=>'salesrep_salesman'));

		$this->rbr->set_categories(self::$cats);
		$this->rbr->set_summary('col', array('label'=>__('Total')));
		$this->rbr->set_summary('row', array('label'=>__('Total')));

		$date_range = $this->rbr->display_date_picker(array('from_month'=>date('Y-m-d',strtotime('-2 months'))), $form);
		if (isset($date_range['other']['salesman']) && $date_range['other']['salesman']) {
			eval_js('$("salesrep_salesman").value = '.$date_range['other']['salesman'].';');
			$crits['id'] = $date_range['other']['salesman'];
		} else {
			if (isset($date_range['other']['company']) && $date_range['other']['company']!=='__NULL__' && isset($js[$date_range['other']['company']]))
				$crits['id'] = array_keys($js[$date_range['other']['company']]);
		}
		$recs = Utils_RecordBrowserCommon::get_records('contact',$crits,array(),array('last_name'=>'ASC','first_name'=>'ASC'),$limit);

		$this->rbr->set_reference_records($recs);

		$this->rbr->set_format(array(	self::$cats[0]=>'numeric', 
											self::$cats[1]=>'currency', 
											self::$cats[2]=>'numeric', 
											self::$cats[3]=>'currency',
											self::$cats[4]=>'percent', 
											self::$cats[5]=>'percent'));
		$header = array(__('Employee'));
		$this->dates = $date_range['dates'];
		$this->range_type = $date_range['type'];
		switch ($date_range['type']) {
			case 'day': $this->format ='d M Y'; break;
			case 'week': $this->format ='W Y'; break;
			case 'month': $this->format ='M Y'; break;
			case 'year': $this->format ='Y'; break;
		} 
		foreach ($this->dates as $v)
			$header[] = date($this->format, $v);
		$this->rbr->set_table_header($header);
		$this->rbr->set_display_cell_callback(array($this, 'display_cells'));
		$this->rbr->set_pdf_title(__('Projects - Report, %s',array(date('Y-m-d H:i:s'))));
		$this->rbr->set_pdf_subject($this->rbr->pdf_subject_date_range());
		$this->rbr->set_pdf_filename(__('Projects_Report_%s',array(date('Y_m_d__H_i_s'))));
		$this->display_module($this->rbr);
	}

	public function display_cells($ref_rec){
		$result = array();
		$hash = array();
		$i = 0;
		foreach ($this->dates as $v) {
			$result[$i] = array(	self::$cats[0]=>0,
									self::$cats[1]=>0,
									self::$cats[2]=>0,
									self::$cats[3]=>0,
									self::$cats[4]=>0,
									self::$cats[5]=>0);
			$hash[date($this->format, $v)] = $i;
			$i++;
		}
		$won = 0; 
		$est = 0;
		$sold = 0;
		$earned = 0;
		$records = Utils_RecordBrowserCommon::get_records('premium_salesopportunity', array('opportunity_manager'=>$ref_rec['id']));
		$ids = array();
		foreach ($records as $v) {
			$update_percent = array();
			$ids[$v['id']] = $v['id'];
			$d = date($this->format,strtotime($v['start_date']));
			if (isset($hash[$d])) {
				$result[$hash[$d]][self::$cats[0]]++;
				$result[$hash[$d]][self::$cats[1]] += $v['contract_amount'];
				if ($v['status']==20) {
					$result[$hash[$d]][self::$cats[2]]++;
					$result[$hash[$d]][self::$cats[3]] += $v['contract_amount'];
				}
				$update_percent[] = $hash[$d];
			}
			foreach ($update_percent as $d) {
				if ($result[$d][self::$cats[0]]!=0)
					$result[$d][self::$cats[4]] = 
						number_format($result[$d][self::$cats[2]]/$result[$d][self::$cats[0]]*100,2);
				if ($result[$d][self::$cats[1]]!=0)
					$result[$d][self::$cats[5]] = 
						number_format($result[$d][self::$cats[3]]/$result[$d][self::$cats[1]]*100,2);
			}
		}
		$i = 0;
		foreach ($this->dates as $v) {
			switch ($this->range_type) {
				case 'day':		$start = date('Y-m-d',$v);
								$end = date('Y-m-d',$v);
								break;
				case 'week':	$m = date('N',$v)-1;
								$start = date('Y-m-d',$v-$m*86400);
								$end = date('Y-m-d',$v+(6-$m)*86400);
								break;
				case 'month':	$start = date('Y-m-01',$v);
								$end = date('Y-m-t',$v);
								break;
				case 'year':	$start = date('Y-01-01',$v);
								$end = date('Y-12-31',$v);
								break;
			}
			$end = date('Y-m-d',strtotime($end)+1);
			if ($result[$i][self::$cats[0]]<>0) {
				$date_type = 'start_date';
				$result[$i][self::$cats[0]] = '<a '.$this->create_callback_href(array($this,'display_salesopportunities'), array(array('opportunity_manager' => $ref_rec['id']), $date_type, $start, $end)).'>'.$result[$i][self::$cats[0]].'</a>';
			}
			if ($result[$i][self::$cats[2]]<>0) {
				$date_type = 'start_date';
				$result[$i][self::$cats[2]] = '<a '.$this->create_callback_href(array($this,'display_salesopportunities'), array(array('opportunity_manager' => $ref_rec['id'], 'status' => 20), $date_type, $start, $end)).'>'.$result[$i][self::$cats[2]].'</a>';
			}
			$i++;
		}
		return $result;
	}
	
	public function display_salesopportunities($crits, $date_type, $start, $end) {
		if ($this->is_back()) return false;
		$rb = $this->init_module('Utils/RecordBrowser','premium_salesopportunity','sales_report_salesopps');
		$proj = array(array_merge($crits, array('>='.$date_type=>$start, '<='.$date_type=>$end)), array($date_type=>true), array($date_type=>'ASC'));
		$this->display_module($rb,$proj,'show_data');
		Base_ActionBarCommon::add('back', __('Back'), $this->create_back_href());
		return true;
	}
		
	public function caption() {
		return __('Sales Opportunity Report');
	}
}

?>