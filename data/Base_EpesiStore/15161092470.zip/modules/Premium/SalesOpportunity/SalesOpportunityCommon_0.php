<?php
/**
 * Sales Opportunity Tracker
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunityCommon extends ModuleCommon {
	public static $leightbox_ready = array();
	public static $last_location = null;
	
	public static function applet_caption() {
		if (Utils_RecordBrowserCommon::get_access('premium_salesopportunity','browse'))
			return __('Sales Opportunities');
	}
	public static function contact_addon_access() {
		return Utils_RecordBrowserCommon::get_access('premium_salesopportunity', 'browse');
	}

	public static function applet_info() {
		return __('Lists Sales opportunities');
	}
	
	public static function activities_addon_label() {
		switch (true) {
			case (ModuleManager::is_installed('CRM_Tasks')>=0): return array('show'=>true, 'label'=>__('Events'));
			case (ModuleManager::is_installed('CRM_Meeting')>=0): return array('show'=>true, 'label'=>__('Events'));
			case (ModuleManager::is_installed('CRM_PhoneCall')>=0): return array('show'=>true, 'label'=>__('Events'));
			default: return array('show'=>false);
		}
	}

	public static function applet_info_format($r){
		$status = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status');
		$customers = '';
		if (!is_array($r['customers'])) $r['customers'] = array('C:'.$r['customers']);
		foreach($r['customers'] as $arg) {
			if ($customers) $customers .='<br>';
			$customers .= CRM_ContactsCommon::autoselect_company_contact_format($arg);
		}

		$args=array(
					__('Opportunity Name')=>'<b>'.$r['opportunity_name'].'</b>',
					__('Description')=>$r['description'],
					__('Employees')=>CRM_ContactsCommon::display_contact(array('id'=>$r['employees']),true,array('id'=>'id', 'param'=>'::;CRM_ContactsCommon::contact_format_no_company')),
					__('Customers')=> $customers,
					__('Status')=>$status[$r['status']],
					__('Contract Amount')=>Utils_CurrencyFieldCommon::format($r['contract_amount']),
					__('Probability (%%)')=>$r['probability____']
					);

		$ret = array('notes'=>Utils_TooltipCommon::format_info_tooltip($args));
		return $ret;
	}

	public static function applet_settings() {
		$status = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status',true);
		$ret = array();
		$ret[] = array('label'=>__('Follow-up Date'),'name'=>'follow_up_date','type'=>'select','default'=>0,'values'=>array(0=>__('Today'), 1=>__('Tomorrow'), 2=>__('2 days forward'), 7=>__('1 week forward'), -1=>__('All')));
		foreach ($status as $k=>$v)
			$ret[] = array('label'=>$v,'name'=>'status_'.$k,'type'=>'checkbox','default'=>($k<20));
		return Utils_RecordBrowserCommon::applet_settings($ret);
	}


    public static function display_opportunity_name($v, $nolink=false) {
		return Utils_RecordBrowserCommon::create_linked_label_r('premium_salesopportunity', 'Opportunity Name', $v, $nolink);
	}

	public static function display_notes($v, $nolink=false) {
		if (!$v['id']) return '---';
		return Utils_AttachmentCommon::count('premium_salesopportunity'.'/'.$v['id']);;
	}

	public static function submit_contact($r, $ac) {
		if ($ac!='display') return $r;
		if (!Utils_RecordBrowserCommon::get_access('premium_salesopportunity', 'add')) return array();
		$me = CRM_ContactsCommon::get_my_record();
		return array('new'=>array('sales_opp'=>'<a '.Utils_TooltipCommon::open_tag_attrs(__('New Sales Opportunity')).' '.Utils_RecordBrowserCommon::create_new_record_href('premium_salesopportunity', array('opportunity_manager'=>$me['id'],'customers'=>'P:'.$r['id'], 'start_date'=>date('Y-m-d'), 'status'=>0, 'employees'=>$me['id'])).'><img border="0" src="'.Base_ThemeCommon::get_template_file('Premium_SalesOpportunity','icon-small.png').'"></a>'));
	}

	public static function submit_company($r, $ac) {
		if ($ac!='display') return $r;
		$me = CRM_ContactsCommon::get_my_record();
		return array('new'=>array('sales_opp'=>'<a '.Utils_TooltipCommon::open_tag_attrs(__('New Sales Opportunity')).' '.Utils_RecordBrowserCommon::create_new_record_href('premium_salesopportunity', array('opportunity_manager'=>$me['id'],'customers'=>'C:'.$r['id'], 'start_date'=>date('Y-m-d'), 'status'=>0, 'employees'=>$me['id'])).'><img border="0" src="'.Base_ThemeCommon::get_template_file('Premium_SalesOpportunity','icon-small.png').'"></a>'));
	}

	public static function submit_salesopportunity($values, $mode) {
		switch($mode) {
			case 'display':
				$me = CRM_ContactsCommon::get_my_record();
				$ret = array();
				$cus = is_array($values['customers'])?reset($values['customers']):$values['customers'];
				if (!is_array($values['customers'])) $values['customers'] = 'C:'.$values['customers']; // in case field type is changed to company
                $rec_id = 'premium_salesopportunity/' . $values['id'];
				if (ModuleManager::is_installed('CRM/Meeting')!==-1) $ret['new']['meeting'] = '<a '.Utils_TooltipCommon::open_tag_attrs(__('New Meeting')).' '.Utils_RecordBrowserCommon::create_new_record_href('crm_meeting', array('title'=>$values['opportunity_name'],'employees'=>$me['id'],'customers'=>$values['customers'],'status'=>0, 'priority'=>CRM_CommonCommon::get_default_priority(), 'permission'=>0, 'related'=>$rec_id)).'><img border="0" src="'.Base_ThemeCommon::get_template_file('CRM_Calendar','icon-small.png').'"></a>';
				if (ModuleManager::is_installed('CRM/Tasks')!==-1) $ret['new']['task'] = '<a '.Utils_TooltipCommon::open_tag_attrs(__('New Task')).' '.Utils_RecordBrowserCommon::create_new_record_href('task', array('title'=>$values['opportunity_name'],'employees'=>$me['id'],'customers'=>$values['customers'],'status'=>0, 'priority'=>CRM_CommonCommon::get_default_priority(), 'permission'=>0, 'related'=>$rec_id)).'><img border="0" src="'.Base_ThemeCommon::get_template_file('CRM_Tasks','icon-small.png').'"></a>';
				if (ModuleManager::is_installed('CRM/PhoneCall')!==-1) $ret['new']['phonecall'] = '<a '.Utils_TooltipCommon::open_tag_attrs(__('New Phonecall')).' '.Utils_RecordBrowserCommon::create_new_record_href('phonecall', array('subject'=>$values['opportunity_name'],'date_and_time'=>date('Y-m-d H:i:s'),'customer'=>$cus,'employees'=>$me['id'],'status'=>0, 'permission'=>0, 'priority'=>CRM_CommonCommon::get_default_priority(), 'related'=>$rec_id),'none',false).'><img border="0" src="'.Base_ThemeCommon::get_template_file('CRM_PhoneCall','icon-small.png').'"></a>';
				return $ret;
			case 'edit':
			case 'added':
				self::subscribed_employees($values);
		}
		return $values;
	}

	public static function subscribed_employees($v) {
		if (!is_array($v)) return;
		if ($v['opportunity_manager']) {
			$v['employees'][] = $v['opportunity_manager'];
		}
		foreach ($v['employees'] as $k) {
			$user = Utils_RecordBrowserCommon::get_value('contact',$k,'Login');
			if ($user!==false && $user!==null) Utils_WatchdogCommon::user_subscribe($user, 'premium_salesopportunity', $v['id']);
		}
	}

    public static function menu() {
		if (Utils_RecordBrowserCommon::get_access('premium_salesopportunity','browse'))
			return array(_M('CRM')=>array('__submenu__'=>1,_M('Sales Opportunity')=>array()));
		else
			return array();
	}

// Filter criteria for Employees
	public static function salesopportunity_employees_crits(){
		return array('(company_name'=>CRM_ContactsCommon::get_main_company(),'|related_companies'=>array(CRM_ContactsCommon::get_main_company()));
   }

	public static function salesopportunity_customer_crits(){
		return array();
	}
	
	public static function watchdog_label($rid = null, $events = array(), $details = true) {
		return Utils_RecordBrowserCommon::watchdog_label(
				'premium_salesopportunity',
				__('Opportunity'),
				$rid,
				$events,
				'opportunity_name',
				$details
			);
	}	
	
	public static function display_status($record, $nolink, $desc) {
		$prefix = 'crm_salesop_leightbox';
		$v = $record[$desc['id']];
		if (!$v) $v = 0;
		$status = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status');
		if ($v>=20 || $nolink) return isset($status[$v])?$status[$v]:$v;
		if (!Utils_RecordBrowserCommon::get_access('premium_salesopportunity', 'edit', $record) && !Base_AclCommon::i_am_admin()) return $status[$v];
		self::drawLeightbox($prefix);
		if (isset($_REQUEST['form_name']) && $_REQUEST['form_name']==$prefix.'_follow_up_form' && $_REQUEST['id']==$record['id']) {
			unset($_REQUEST['form_name']);
			$v = $_REQUEST['closecancel'];
			$action  = $_REQUEST['action'];
			$new_values = array('status'=>$v);
			$new_values['probability____'] = intval($_REQUEST['probability']);
			$new_values['follow_up_date'] = date('Y-m-d',Base_RegionalSettingsCommon::reg2time($_REQUEST['follow_up_date'],false));
			

			$note = $_REQUEST['note'];
			if ($note) {
				if (get_magic_quotes_gpc())
					$note = stripslashes($note);
				$note = str_replace("\n",'<br />',$note);
				Utils_AttachmentCommon::add('premium_salesopportunity/'.$record['id'],0,Acl::get_user(),$note);
			}

			Utils_RecordBrowserCommon::update_record('premium_salesopportunity', $record['id'], $new_values);

			$values = $record;
			$values['date_and_time'] = date('Y-m-d H:i:s');
			$values['title'] = __('Follow-up').': '.$values['opportunity_name'];
			$values['status'] = 0;

			if ($action != 'none') {		
				$x = ModuleManager::get_instance('/Base_Box|0');
				$values['permission'] = 0;
				$values['priority'] = CRM_CommonCommon::get_default_priority();
                $rec_id = 'premium_salesopportunity/' . $record['id'];
                $values['related'] = $record['id'];
				if ($action == 'new_task') $x->push_main('Utils/RecordBrowser','view_entry',array('add', null, $values), array('task'));
				if ($action == 'new_meeting') $x->push_main('Utils/RecordBrowser','view_entry',array('add', null, array('related'=>$rec_id,'title'=>$values['title'],'permission'=>0,'priority'=>CRM_CommonCommon::get_default_priority(),'description'=>$values['description'],'date'=>date('Y-m-d'),'time'=>date('H:i:s'),'duration'=>3600,'status'=>0,'employees'=>$values['employees'], 'customers'=>$values['customers'])), array('crm_meeting'));
				if ($action == 'new_phonecall') $x->push_main('Utils/RecordBrowser','view_entry',array('add', null, array('related'=>$rec_id,'subject'=>$values['title'],'permission'=>0,'priority'=>CRM_CommonCommon::get_default_priority(),'description'=>$values['description'],'date_and_time'=>date('Y-m-d H:i:s'),'employees'=>$values['employees'],'status'=>0, 'customer'=>!empty($values['customers'])?reset($values['customers']):'')), array('phonecall'));
				return false;
			}

			location(array());
		}
		$follow_up_set_defaults = 'var cur_f=document.forms[\''.$prefix.'_follow_up_form\'];cur_f.probability.value='.$record['probability____'].';';
		if ($record['follow_up_date']) $date = Base_RegionalSettingsCommon::time2reg($record['follow_up_date'], false);
		else $date = '';
		$follow_up_set_defaults .= 'cur_f.follow_up_date.value=\''.$date.'\';';
		$follow_up_set_defaults .= 'cur_f.note.value=\'\';';
		$follow_up_set_defaults .= 'cur_f.closecancel.value=\''.$record['status'].'\';';
		return '<a href="javascript:void(0)" class="lbOn" rel="'.$prefix.'_followups_leightbox" onMouseDown="'.$prefix.'_set_id('.$record['id'].');'.$follow_up_set_defaults.'">'.(isset($status[$v])?$status[$v]:$v).'</a>';
	} 

	public static function check_location() {
		if (isset($_REQUEST['__location']) && self::$last_location!=$_REQUEST['__location']) {
			self::$last_location = $_REQUEST['__location'];
			self::$leightbox_ready = array();	
		}
	}
	public static function drawLeightbox($prefix) {
		if(MOBILE_DEVICE) return;
		$meetings = (ModuleManager::is_installed('CRM/Meeting')>=0);
		$tasks = (ModuleManager::is_installed('CRM/Tasks')>=0);
		$phonecall = (ModuleManager::is_installed('CRM/PhoneCall')>=0);
		self::check_location();
		$status = Utils_CommonDataCommon::get_translated_array('Premium/SalesOpportunity/Status', true);
		if (!isset(self::$leightbox_ready[$prefix])) {
			self::$leightbox_ready[$prefix] = true;

			$theme = Base_ThemeCommon::init_smarty();
			eval_js_once($prefix.'_followups_deactivate = function(){leightbox_deactivate(\''.$prefix.'_followups_leightbox\');}');
	
			if ($meetings) {
				$theme->assign('new_meeting',array('open'=>'<a id="'.$prefix.'_new_meeting_button" onclick="'.$prefix.'_set_action(\'new_meeting\');'.$prefix.'_submit_form();">','text'=>__( 'New Meeting'),'close'=>'</a>'));
				eval_js('Event.observe(\''.$prefix.'_new_meeting_button\',\'click\', '.$prefix.'_followups_deactivate)');
			}

			if ($tasks) {
				$theme->assign('new_task',array('open'=>'<a id="'.$prefix.'_new_task_button" onclick="'.$prefix.'_set_action(\'new_task\');'.$prefix.'_submit_form();">','text'=>__( 'New Task'),'close'=>'</a>'));
				eval_js('Event.observe(\''.$prefix.'_new_task_button\',\'click\', '.$prefix.'_followups_deactivate)');
			}

			if ($phonecall) {
				$theme->assign('new_phonecall',array('open'=>'<a id="'.$prefix.'_new_phonecall_button" onclick="'.$prefix.'_set_action(\'new_phonecall\');'.$prefix.'_submit_form();">','text'=>__( 'New Phonecall'),'close'=>'</a>'));
				eval_js('Event.observe(\''.$prefix.'_new_phonecall_button\',\'click\', '.$prefix.'_followups_deactivate)');
			}

			$theme->assign('just_close',array('open'=>'<a id="'.$prefix.'_just_close_button" onclick="'.$prefix.'_set_action(\'none\');'.$prefix.'_submit_form();">','text'=>__( 'Save'),'close'=>'</a>'));
			eval_js('Event.observe(\''.$prefix.'_just_close_button\',\'click\', '.$prefix.'_followups_deactivate)');

			eval_js($prefix.'_submit_form = function () {'.
						'$(\''.$prefix.'_follow_up_form\').submited.value=1;Epesi.href($(\''.$prefix.'_follow_up_form\').serialize(), \'processing...\');$(\''.$prefix.'_follow_up_form\').submited.value=0;'.
					'}');
			eval_js($prefix.'_set_action = function (arg) {'.
						'document.forms["'.$prefix.'_follow_up_form"].action.value = arg;'.
					'}');
			eval_js($prefix.'_set_id = function (id) {'.
						'document.forms["'.$prefix.'_follow_up_form"].id.value = id;'.
					'}');
			$theme->assign('form_open','<form id="'.$prefix.'_follow_up_form" name="'.$prefix.'_follow_up_form" method="POST">'.
							'<input type="hidden" name="submited" value="0" />'.
							'<input type="hidden" name="form_name" value="'.$prefix.'_follow_up_form" />'.
							'<input type="hidden" name="id" value="" />'.
							'<input type="hidden" name="action" value="" />');
			$status_opts_html = '<select name="closecancel" value="0">';
			foreach ($status as $k=>$v) {
				$status_opts_html .= '<option value="'.$k.'">'.$v.'</option>';
			}
			$status_opts_html .= '</select>';
			$theme->assign('form_closecancel',	array(
							'label'=>__('Status'),
							'html'=>$status_opts_html
							));
			include_once('modules/Utils/PopupCalendar/datepicker.php');
			$dp = new HTML_QuickForm_datepicker('follow_up_date', '', array());
			ob_start();
			$theme->assign('form_followup_date', array(
							'label'=>__('Follow-up Date'),
							'html'=>$dp->toHtml()));
			$html = ob_get_clean();
			$theme->assign('form_probabilty',			array(
							'label'=>__('Probability (%%)'),
							'html'=>'<input type="text" name="probability" />'));
			$theme->assign('form_note',			array(
							'label'=>__('Note'),
							'html'=>'<textarea name="note"></textarea>'));
			$theme->assign('form_close','</form>');
			ob_start();
			Base_ThemeCommon::display_smarty($theme,'Premium_SalesOpportunity','leightbox');
			$profiles_out = ob_get_clean();

			Libs_LeightboxCommon::display($prefix.'_followups_leightbox',$html.$profiles_out,__( 'Follow-up'));
		}
	}

	public static function display_employees($record, $nolink, $desc) {
		return CRM_ContactsCommon::display_contacts_with_notification('premium_salesopportunity', $record, $nolink, $desc);
	}

	public static function mobile_menu() {
		if(!Acl::is_user())
			return array();
		return array(__('Sales Opportunities')=>'mobile_salesopp');
	}
	
	public static function mobile_salesopp() {
		$me = CRM_ContactsCommon::get_my_record();
		$defaults = array('employees'=>$me['id'], 'opportunity_manager'=>$me['id'], 'start_date'=>date('Y-m-d'), 'status'=>0);
		Utils_RecordBrowserCommon::mobile_rb('premium_salesopportunity',array('employees'=>array($me['id']), 'status'=>array(0,1,2,3)),array('status'=>'ASC', 'opportunity_name'=>'ASC'),array('status'=>1,'probablity (%)'=>false),$defaults);
	}

    public static function crm_opportunity_reference_crits()
    {
        return array('!status' => 21, '(>=close_date' => date('Y-m-d'), '|close_date' => '');
    }
}
?>
