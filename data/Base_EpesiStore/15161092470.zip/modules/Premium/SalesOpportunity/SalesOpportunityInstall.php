<?php
/**
 * Sales Opportunity Tracker
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage salesopportunity
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_SalesOpportunityInstall extends ModuleInstall {
    const version = '1.8.0';

	public function install() {
		Base_LangCommon::install_translations($this->get_type());		
		Base_ThemeCommon::install_default_theme($this->get_type());
		$fields = array(
			array('name' => _M('Opportunity Name'),	'type'=>'text', 'required'=>true, 'param'=>'64', 'extra'=>false, 'visible'=>true,'display_callback'=>array('Premium_SalesOpportunityCommon', 'display_opportunity_name')),
			array('name' => _M('Opportunity Manager'), 'type'=>'crm_contact', 'param'=>array('field_type'=>'select', 'crits'=>array('Premium_SalesOpportunityCommon','salesopportunity_employees_crits'), 'format'=>array('CRM_ContactsCommon','contact_format_no_company')), 'display_callback'=>array('Premium_SalesOpportunityCommon','display_employees'), 'required'=>true, 'visible'=>true, 'extra'=>false),
			array('name' => _M('Employees'),			'type'=>'crm_contact', 'param'=>array('field_type'=>'multiselect', 'crits'=>array('Premium_SalesOpportunityCommon','salesopportunity_employees_crits'), 'format'=>array('CRM_ContactsCommon','contact_format_no_company')), 'display_callback'=>array('Premium_SalesOpportunityCommon','display_employees'), 'required'=>true, 'visible'=>true, 'extra'=>false),
			array('name' => _M('Customers'), 			'type'=>'crm_company_contact', 'param'=>array('field_type'=>'multiselect','crits'=>array('Premium_SalesOpportunityCommon','salesopportunity_customer_crits')), 'filter'=>true, 'required'=>true, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Type'), 				'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium/SalesOpportunity/Type'), 'extra'=>false),
			array('name' => _M('Lead Source'), 		'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium/SalesOpportunity/Source'), 'extra'=>false),
			array('name' => _M('Probability (%%)'), 	'type'=>'integer', 'required'=>true, 'visible'=>true, 'extra'=>false),
			array('name' => _M('Status'), 			'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium/SalesOpportunity/Status'), 'extra'=>false, 'display_callback'=>array('Premium_SalesOpportunityCommon','display_status')),
			array('name' => _M('Start Date'), 		'type'=>'date', 'required'=>true, 'param'=>64, 'extra'=>false),
			array('name' => _M('Follow-up Date'), 	'type'=>'date', 'required'=>false, 'param'=>64, 'extra'=>false),
			array('name' => _M('Close Date'), 		'type'=>'date', 'required'=>false, 'param'=>64, 'extra'=>false),
			array('name' => _M('Contract Amount'), 	'type'=>'currency', 'required'=>false, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Notes'), 				'type'=>'calculated', 'required'=>false, 'visible'=>true, 'extra'=>false, 'style'=>'integer', 'display_callback'=>array('Premium_SalesOpportunityCommon','display_notes')),
			array('name' => _M('Description'), 		'type'=>'long text', 'required'=>false, 'param'=>'250', 'extra'=>false)
		);

		Utils_RecordBrowserCommon::install_new_recordset('premium_salesopportunity', $fields);
		
		Utils_RecordBrowserCommon::set_quickjump('premium_salesopportunity', 'Opportunity Name');
		Utils_RecordBrowserCommon::set_favorites('premium_salesopportunity', true);
		Utils_RecordBrowserCommon::set_recent('premium_salesopportunity', 15);
		Utils_RecordBrowserCommon::set_caption('premium_salesopportunity', _M('Opportunity'));
		Utils_RecordBrowserCommon::set_icon('premium_salesopportunity', Base_ThemeCommon::get_template_filename('Premium/SalesOpportunity', 'icon.png'));
		Utils_RecordBrowserCommon::register_processing_callback('premium_salesopportunity', array('Premium_SalesOpportunityCommon', 'submit_salesopportunity'));
		Utils_RecordBrowserCommon::enable_watchdog('premium_salesopportunity', array('Premium_SalesOpportunityCommon','watchdog_label'));
        Utils_RecordBrowserCommon::set_search('premium_salesopportunity',2,0);

// ************ addons ************** //
		Utils_RecordBrowserCommon::new_addon('premium_salesopportunity', 'Premium/SalesOpportunity', 'activities_addon', array('Premium_SalesOpportunityCommon','activities_addon_label'));
		Utils_AttachmentCommon::new_addon('premium_salesopportunity');

		Utils_RecordBrowserCommon::new_addon('company', 'Premium/SalesOpportunity', 'company_addon', _M('Sales Opportunities'));
		Utils_RecordBrowserCommon::new_addon('contact', 'Premium/SalesOpportunity', 'contact_addon', _M('Sales Opportunities'));

// ************ other ************** //	
		Utils_CommonDataCommon::new_array('Premium/SalesOpportunity/Status',array(
			0=>_M('New'),
			1=>_M('Prospecting'),
			2=>_M('Evaluation'),
			3=>_M('Negotiations'),
			20=>_M('Contract Won'),
			21=>_M('Contract Lost')
		),true,true);

		Utils_CommonDataCommon::new_array('Premium/SalesOpportunity/Type',array(
			0=>_M('New Customer'),
			1=>_M('Existing Customer')	
		),true,true);

		Utils_CommonDataCommon::new_array('Premium/SalesOpportunity/Source',array(
			0=>_M('Web Site'),
			1=>_M('E-mail'),
			2=>_M('Referral'),
			3=>_M('Advert'),
			20=>_M('Other')
		),true,true);

		if (ModuleManager::is_installed('CRM_Tasks')>=0)
			self::new_related('task');
		if (ModuleManager::is_installed('CRM_PhoneCall')>=0)
            self::new_related('phonecall');
		if (ModuleManager::is_installed('CRM_Meeting')>=0)
            self::new_related('crm_meeting');

		Utils_RecordBrowserCommon::register_processing_callback('contact', array('Premium_SalesOpportunityCommon', 'submit_contact'));
		Utils_RecordBrowserCommon::register_processing_callback('company', array('Premium_SalesOpportunityCommon', 'submit_company'));

		Utils_RecordBrowserCommon::add_default_access('premium_salesopportunity');

		CRM_CalendarCommon::new_event_handler(_M('Sales Opportunities'), array('Premium_SalesOpportunity_CalendarIntegration', 'handler'));

		return true;
	}

    protected static function new_related($rs)
    {
        $related_tab = $rs . '_related';
        $arr = array('recordset' => 'premium_salesopportunity');
        if (Utils_RecordBrowserCommon::check_table_name($related_tab, true, false)) {
            $records = Utils_RecordBrowserCommon::get_records_count($related_tab, $arr);
            if (!$records) {
                Utils_RecordBrowserCommon::new_record($related_tab, $arr);
            }
        }
    }

    protected static function delete_related($rs)
    {
        $related_tab = $rs . '_related';
        $arr = array('recordset' => 'premium_salesopportunity');
        if (Utils_RecordBrowserCommon::check_table_name($related_tab, false, false)) {
            $records = Utils_RecordBrowserCommon::get_records($related_tab, $arr);
            foreach ($records as $r) {
                Utils_RecordBrowserCommon::delete_record($related_tab, $r['id']);
            }
        }
    }
	
	public function uninstall() {
		Utils_RecordBrowserCommon::unregister_processing_callback('contact', array('Premium_SalesOpportunityCommon', 'submit_contact'));
		Utils_RecordBrowserCommon::unregister_processing_callback('company', array('Premium_SalesOpportunityCommon', 'submit_company'));
		Utils_RecordBrowserCommon::unregister_processing_callback('premium_salesopportunity', array('Premium_SalesOpportunityCommon', 'submit_salesopportunity'));
        self::delete_related('task');
        self::delete_related('phonecall');
        self::delete_related('crm_meeting');
		Base_ThemeCommon::uninstall_default_theme($this->get_type());
		Utils_AttachmentCommon::delete_addon('premium_salesopportunity');
		Utils_AttachmentCommon::persistent_mass_delete('premium_salesopportunity');
		Utils_RecordBrowserCommon::uninstall_recordset('premium_salesopportunity');
		Utils_CommonDataCommon::remove('Premium/SalesOpportunity/Status');
		Utils_CommonDataCommon::remove('Premium/SalesOpportunity/Source');
		Utils_CommonDataCommon::remove('Premium/SalesOpportunity/Type');
		CRM_CalendarCommon::delete_event_handler('Sales Opportunities');
		return true;
	}
	
	public function version() {
		return array(self::version);
	}
	
	public function requires($v) {
		return array(
			array('name'=>'Base','version'=>0),
			array('name'=>'Utils/ChainedSelect', 'version'=>0), 
			array('name'=>'CRM/Contacts','version'=>0));
	}
	
	public static function info() {
		return array(
			'Description'=>'SalesOpportunity Tracker - Premium Module',
			'Author'=>'abisaga@telaxus.com',
			'License'=>'MIT');
	}
	
	public static function simple_setup() {
		return array('package'=>__('Sales Opportunity'), 'version' => self::version);
	}
}

?>
