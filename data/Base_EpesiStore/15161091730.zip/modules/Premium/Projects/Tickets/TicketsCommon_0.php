<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_TicketsCommon extends ModuleCommon {
	
	public static function active_tickets_crits() {
//		return array('!status'=>array(2,4));
		return array('status'=>array(1,2,3));
	}

	public static function menu() {
		if (Utils_RecordBrowserCommon::get_access('premium_tickets','browse'))
			return array(_M('Bug tracker')=>array('__submenu__'=>1,_M('Tickets')=>array()));
		else
			return array();
	}

	public static function applet_caption() {
		if (Utils_RecordBrowserCommon::get_access('premium_tickets','browse'))
			return __('Tickets');
	}

	public static function applet_info() {
		return __('Tickets for Projects');
	}
	public static function ticket_bbcode($text, $param, $opt) {
		return Utils_RecordBrowserCommon::record_bbcode('premium_tickets', array('ticket_id','title'), $text, $param, $opt);
	}
	public static function watchdog_label($rid = null, $events = array(), $details = true) {
		return Utils_RecordBrowserCommon::watchdog_label(
				'premium_tickets',
				__('Tickets'),
				$rid,
				$events,
				array('Premium_Projects_TicketsCommon','watchdog_label_format'),
				$details
			);
	}
	public static function watchdog_label_format($r) {
		return $r['ticket_id'].': '.$r['title'];
	}
	public static function generate_id($id) {
		if (is_array($id)) $id = $id['id'];
		return '#'.str_pad($id, 4, '0', STR_PAD_LEFT);
	}

	public static function display_status($record, $nolink, $desc, $tab, $status = array()) {
		$v = $record['status'];
		if (!$v) $v = 0;
		if (empty($status)) $status = Utils_CommonDataCommon::get_translated_array('Premium_Ticket_Status');
		if ($nolink) return $status[$v];
		$me = CRM_ContactsCommon::get_my_record();
		$leightbox_ready = & CRM_FollowupCommon::$leightbox_ready;
		$prefix = 'premium_ticket_status';
		CRM_FollowupCommon::check_location();
		if (!isset($leightbox_ready[$prefix])) {
			$leightbox_ready[$prefix] = true;

			$theme = Base_ThemeCommon::init_smarty();
			eval_js_once($prefix.'_followups_deactivate = function(){leightbox_deactivate(\''.$prefix.'_followups_leightbox\');}');
	
			$error = __('Resolution is required when marking ticket as closed or resolved.');
			$error .= Libs_QuickFormCommon::get_error_closing_button();
			eval_js('check_if_'.$prefix.'_set_resolution = function() {not_resolved=$(\''.$prefix.'_resolution_select\').options[0].selected;if(not_resolved)$(\''.$prefix.'_resolution_required\').innerHTML=\''.Epesi::escapeJS($error).'\';return !not_resolved;}');
			$theme->assign('resolution_required_error','<div id="'.$prefix.'_resolution_required" class="form_error"></div>');
			$theme->assign('mark_new',array('open'=>'<a id="'.$prefix.'_new" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'new\');'.$prefix.'_submit_form();">','text'=>__( 'Mark as New'),'close'=>'</a>'));
			$theme->assign('reopen',array('open'=>'<a id="'.$prefix.'_open" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'reopen\');'.$prefix.'_submit_form();">','text'=>__( 'Reopen'),'close'=>'</a>'));
			$theme->assign('in_progress',array('open'=>'<a id="'.$prefix.'_inprogress" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'inprogress\');'.$prefix.'_submit_form();">','text'=>__( 'In Progress'),'close'=>'</a>'));
			$theme->assign('on_hold',array('open'=>'<a id="'.$prefix.'_onhold" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'onhold\');'.$prefix.'_submit_form();">','text'=>__( 'On Hold'),'close'=>'</a>'));
			$theme->assign('feedback',array('open'=>'<a id="'.$prefix.'_feedback" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'feedback\');'.$prefix.'_submit_form();">','text'=>__( 'Need Feedback'),'close'=>'</a>'));
			$theme->assign('close',array('open'=>'<a id="'.$prefix.'_close" onclick="if(check_if_'.$prefix.'_set_resolution()){'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'close\');'.$prefix.'_submit_form();}">','text'=>__( 'Close'),'close'=>'</a>'));			
			$theme->assign('resolve',array('open'=>'<a id="'.$prefix.'_resolve" onclick="if(check_if_'.$prefix.'_set_resolution()){'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'resolve\');'.$prefix.'_submit_form();}">','text'=>__( 'Resolved'),'close'=>'</a>'));

			eval_js($prefix.'_submit_form = function () {'.
						'$(\''.$prefix.'_follow_up_form\').submited.value=1;Epesi.href($(\''.$prefix.'_follow_up_form\').serialize(), \'processing...\');$(\''.$prefix.'_follow_up_form\').submited.value=0;'.
					'}');
			eval_js($prefix.'_set_action = function (arg) {'.
						'document.forms["'.$prefix.'_follow_up_form"].action.value = arg;'.
					'}');
			eval_js($prefix.'_set_id = function (id) {'.
						'document.forms["'.$prefix.'_follow_up_form"].id.value = id;'.
						'document.forms["'.$prefix.'_follow_up_form"].note.value = "";'.
						'document.forms["'.$prefix.'_follow_up_form"].resolution.selectedIndex = 0;'.
					'}');
			eval_js($prefix.'_ticket_enable_close = function(arg) {'.
						'if (arg) arg=""; else arg="none";'.
						'$("ticket_status_close_button").style.display=arg;'.
					'}');
			$theme->assign('form_open','<form id="'.$prefix.'_follow_up_form" name="'.$prefix.'_follow_up_form" method="POST">'.
							'<input type="hidden" name="submited" value="0" />'.
							'<input type="hidden" name="form_name" value="'.$prefix.'_follow_up_form" />'.
							'<input type="hidden" name="id" value="" />'.
							'<input type="hidden" name="action" value="" />');
			$theme->assign('form_note',	array('label'=>__('Note'), 'html'=>'<textarea name="note" value=""></textarea>'));
			$resolution_html = '<select name="resolution" value="0" id="'.$prefix.'_resolution_select">';
			$resolution_html .= '<option value="">---</option>';
			$ress = Utils_CommonDataCommon::get_translated_array('Premium_Ticket_Resolution', true);
			foreach ($ress as $k=>$w)
				$resolution_html .= '<option value="'.$k.'">'.$w.'</option>';
			$resolution_html .= '</select>';
			$theme->assign('form_resolution', array('label'=>__('Resolution'), 'html'=>$resolution_html));
			$theme->assign('form_close','</form>');
			ob_start();
			Base_ThemeCommon::display_smarty($theme,'Premium_Projects_Tickets','status_leightbox');
			$profiles_out = ob_get_clean();

			Libs_LeightboxCommon::display($prefix.'_followups_leightbox',$profiles_out,__( 'Change Status'),1);
		}
		$acc = Utils_RecordBrowserCommon::get_access('premium_tickets', 'edit', $record);
		if (is_array($acc)) {
			if (isset($acc['status']))
				$acc = $acc['status'];
			else
				$acc = true;
		}
		$im_assigned = in_array($me['id'],$record['assigned_to']);
		if ($im_assigned) $acc = true;
		if (empty($record['assigned_to']))
			$acc = false;
		if ($acc==false) return $status[$v];
		$v = $record['status'];
		if (!isset($status[$v])) return '';
		if ($v==6) return $status[$v];
		if (isset($_REQUEST['form_name']) && $_REQUEST['form_name']==$prefix.'_follow_up_form' && $_REQUEST['id']==$record['id']) {
			unset($_REQUEST['form_name']);
			$note = $_REQUEST['note'];
			$resolution = $_REQUEST['resolution'];
			$action  = $_REQUEST['action'];
			switch ($action) {
				case 'new': 	$v=0;
								$resolution = '';
								break;
				case 'reopen': 	$v=1;
								$resolution = '';
								break;
				case 'set_next_stage': $v++; break;
				case 'inprogress': $v=2; break;
				case 'onhold': $v=3; break;
				case 'resolve': $v=4; break;
				case 'feedback': $v=5; break;
				case 'close': $v=6; break;
			}
			if ($note) {
				if (get_magic_quotes_gpc())
					$note = stripslashes($note);
				$note = str_replace("\n",'<br />',$note);
				Utils_AttachmentCommon::add('premium_tickets/'.$record['id'],0,Acl::get_user(),$note);
			}
			Utils_RecordBrowserCommon::update_record('premium_tickets', $record['id'], array('status'=>$v,'resolution'=>$resolution));
			location(array());
		}
		if ($v<=0) {
			return '<a href="javascript:void(0)" onclick="'.$prefix.'_set_action(\'set_next_stage\');'.$prefix.'_set_id(\''.$record['id'].'\');'.$prefix.'_submit_form();">'.$status[$v].'</a>';
		}
		return '<a href="javascript:void(0)" class="lbOn" rel="'.$prefix.'_followups_leightbox" onMouseDown="'.$prefix.'_set_id('.$record['id'].');'.$prefix.'_ticket_enable_close('.($record['ticket_owner']==$me['id']?1:0).');$(\''.$prefix.'_resolution_select\').value=\''.$record['resolution'].'\';">'.$status[$v].'</a>';
	}

	public static function display_ticket_id($r, $nolink) {
		return Utils_RecordBrowserCommon::create_linked_label_r('premium_tickets', 'ticket_id', $r, $nolink);	
	}

	public static function display_status_applet($record, $nolink=false, $desc=array(),$tab) {
		$status = Utils_CommonDataCommon::get_translated_array('Premium_Ticket_Status');
		$status[5] = __('Feedback');
		return self::display_status($record, $nolink, $desc, $tab, $status);
	}

	public static function display_title($record, $nolink) {
		$ret = array();
		$blocked = array();
		sort($record['required_tickets']);
		$icon = null;
		foreach ($record['required_tickets'] as $v) {
			if (!$v) continue;
			$status = Utils_RecordBrowserCommon::get_value('premium_tickets',$v,'status');
			if (!$icon) $icon = 'unblocked';
			if ($status!=6 && Utils_RecordBrowserCommon::is_active('premium_tickets',$v)) {
				if ((!$icon || $icon=='unblocked') && $status==4) $icon = 'blocked-free';
				if ((!$icon || $icon=='unblocked' || $icon=='blocked-free') && $status!=4) $icon = 'blocked';
				$blocked[] = ($status==4?'<b>['.__('Resolved').']</b> ':'').self::generate_id($v).': '.Utils_RecordBrowserCommon::get_value('premium_tickets',$v,'title');
			}
		}
		asort($blocked);
		if (!empty($blocked))
			array_unshift($blocked, '<b>'.__('Blocked due to following tickets:').'</b>');
		$blocking_id = '';
		if ((!$icon || $icon=='unblocked') && $record['status']!=6) {
			$blocking_id = Utils_RecordBrowserCommon::get_id('premium_tickets','required_tickets',$record['id']);
			if ($blocking_id) {
				$icon = 'blocking';
				array_unshift($blocked, '<b>'.__('Blocks ticket ').'</b>'.self::generate_id($blocking_id));
			}
		}
		$ret = Utils_RecordBrowserCommon::create_linked_label_r('premium_tickets', 'title', $record, $nolink);
		if (!$nolink && isset($record['description']) && $record['description']!='') $ret = '<span '.Utils_TooltipCommon::open_tag_attrs(Utils_RecordBrowserCommon::format_long_text($record['description']), false).'>'.$ret.'</span>';
		if ($icon) {
			$icon = '<img src="'.Base_ThemeCommon::get_template_file('Premium_Projects_Tickets',$icon.'.png').'" />';
			if (!empty($blocked) && !$nolink)
        			$icon = '<span '.Utils_TooltipCommon::open_tag_attrs(implode('<br>',$blocked), false).'>'.
					$icon.
					'</span>';
			$ret = $icon.$ret;
		}
		return $ret;
	}

	public static function display_required_tickets($r, $nolink){
		$ret = array();
		sort($r['required_tickets']);
		foreach ($r['required_tickets'] as $v) {
			$rr = Utils_RecordBrowserCommon::get_record('premium_tickets',$v);
			if ($rr[':active']) {
				$str = Utils_RecordBrowserCommon::create_linked_label('premium_tickets','ticket_id',$v, $nolink);
				if(!$nolink) {
    				$note = self::applet_info_format($rr);
	    			$str = '<span '.Utils_TooltipCommon::open_tag_attrs($note['notes'], false).'>'.$str.'</span>';
	    	    }
				if ($rr['status']==6) $str = '<del>'.$str.'</del>'; 
				$ret[] = $str;
			}
		}
		return implode(', ',$ret);
	}

	public static function proj_name_callback($v, $nolink) {
		return Utils_RecordBrowserCommon::create_linked_label('premium_projects', 'Project Name', $v['project_name'], $nolink);
	}

	public static function employees_crits(){
		return array('group'=>'Developer');
	}
	
	public static function users_crits() {
        $crits = array('!login'=>'');
        $ret = Utils_RecordBrowserCommon::merge_crits(CRM_ContactsCommon::employee_crits(), $crits);
        return $ret;
	}
   
	public static function assigned_to_format($record, $nolink=false){
		if (is_numeric($record)) $record = CRM_ContactsCommon::get_contact($record);
		$ret = '';
		if (!$nolink) $ret .= Utils_RecordBrowserCommon::record_link_open_tag('contact', $record['id']);
		$ret .= $record['last_name'].(($record['first_name']!=='')?' '.$record['first_name']:'');
		if (!$nolink) $ret .= Utils_RecordBrowserCommon::record_link_close_tag();
		return $ret;
	}

	public static function display_assigned_contacts($record,$nolink,$desc) {
		return CRM_ContactsCommon::display_contacts_with_notification('premium_tickets', $record, $nolink, $desc);
	}
	
	public static function applet_info_format($r){

		$project=Utils_RecordBrowserCommon::get_value('premium_projects',$r['project_name'],'project_name');

		$args=array(
					__('Ticket ID') => '<b>'.$r['ticket_id'].'</b>',
					__('Project') => '<b>'.$project.'</b>',
					__('Title') => '<b>'.$r['title'].'</b>',
					__('Ticket Owner') => CRM_ContactsCommon::display_contact(array('id'=>$r['ticket_owner']),true,array('id'=>'id', 'param'=>'::;CRM_ContactsCommon::contact_format_no_company')),
					__('Description') => $r['description'],
					__('No. of Notes') => '<b>'.Utils_AttachmentCommon::count('premium_tickets/'.$r['id']).'</b>',
					__('Assigned to') => CRM_ContactsCommon::display_contact(array('id'=>$r['assigned_to']),true,array('id'=>'id', 'param'=>'::;CRM_ContactsCommon::contact_format_no_company')),
					__('Ticket Type') => Utils_CommonDataCommon::get_value('Premium_Ticket_Type/'.$r['type'],true),
					__('Priority') => Utils_CommonDataCommon::get_value('Premium_Ticket_Priorities/'.$r['priority'],true),
					__('Status') => Utils_CommonDataCommon::get_value('Premium_Ticket_Status/'.$r['status'],true),
					__('Resolution') => Utils_CommonDataCommon::get_value('Premium_Ticket_Resolution/'.$r['resolution'],true),
					__('Due Date') => $r['due_date']!=''?Base_RegionalSettingsCommon::time2reg($r['due_date'],false):__('Not set')
					);

		$bg_color = '';
		switch ($r['priority']) {
			case 3: $bg_color = '#E5E5FF'; break; // trivial
			case 2: $bg_color = '#D5FFD5'; break; // minor
			case 1: $bg_color = '#FFFFD5'; break; // major
			case 0: $bg_color = '#FFD5D5'; break; // critical
		}
		$ret = array('notes'=>Utils_TooltipCommon::format_info_tooltip($args));
		if ($bg_color) $ret['row_attrs'] = 'style="background:'.$bg_color.';"';
		return $ret;
	}
	
	public static function projects_crits(){
		return array('!status'=>array(2,4));
	}
	
	public static function claiming_ticket($values) {
		$me = CRM_ContactsCommon::get_my_record();
		$acc = Utils_RecordBrowserCommon::get_access('premium_tickets', 'edit', $values);
		if (is_array($acc)) {
			if (isset($acc['assigned_to']))
				$acc = $acc['assigned_to'];
			else
				$acc = true;
		}
		if ($acc &&
			$me['id']!=-1) {
			$already_assigned = array_search($me['id'],$values['assigned_to']);
			Base_ActionBarCommon::add(($already_assigned!==false)?'delete':'add',($already_assigned!==false)?__('Abandon ticket'):__('Claim ticket'),Module::create_href(array('_claim_ticket'=>$values['id'])));
			if (isset($_REQUEST['_claim_ticket']) &&
				is_numeric($_REQUEST['_claim_ticket']) &&
				$_REQUEST['_claim_ticket']==$values['id']) {
					if ($already_assigned===false) {
						$values['assigned_to'][] = $me['id'];
						Utils_WatchdogCommon::subscribe('premium_tickets',$values['id']);
					} else unset($values['assigned_to'][$already_assigned]);
					Utils_RecordBrowserCommon::update_record('premium_tickets',$values['id'],array('assigned_to'=>$values['assigned_to']));
					unset($_REQUEST['_claim_ticket']);
					location(array());
				}
		}
	}
	
	public static function subscribed_assigned($v) {
		if (!is_array($v)) return;
		$list = $v['assigned_to'];
		$list[] = $v['ticket_owner'];
		foreach ($list as $k) {
			$user = Utils_RecordBrowserCommon::get_value('contact',$k,'Login');
			if ($user!==false && $user!==null) Utils_WatchdogCommon::user_subscribe($user, 'premium_tickets', $v['id']);
		}
	}

	public static function submit_ticket($values, $mode) {
		switch ($mode) {
		case 'add':
			if (empty($values['assigned_to'])) $values['status'] = 0;
			if (!$values['due_date'] && $values['project_name'])
				$values['due_date'] = Utils_RecordBrowserCommon::get_value('premium_projects',$values['project_name'],'due_date');
			return $values;
		case 'display':
			self::claiming_ticket($values);
			return $values;
		case 'edit':
			if (empty($values['assigned_to'])) $values['status'] = 0;
			$values['ticket_id'] = self::generate_id($values['id']);
			$k = array_search($values['id'],$values['required_tickets']);
			if ($k!==false) unset($values['required_tickets'][$k]);
			$old_project = Utils_RecordBrowserCommon::get_value('premium_tickets',$values['id'],'project_name');
		case 'added':
			self::subscribed_assigned($values);
			if ($mode==='edit' && $old_project==$values['project_name']) break;
			Utils_RecordBrowserCommon::update_record('premium_tickets',$values['id'],array('ticket_id'=>self::generate_id($values['id'])), false, null, true);
			$subs = Utils_WatchdogCommon::get_subscribers('premium_projects',$values['project_name']);
			foreach($subs as $s)
				Utils_WatchdogCommon::user_subscribe($s, 'premium_tickets',$values['id']);
		}
		return $values;
	}
	
	public static function required_tickets_crits($arg, $r){
		if (isset($r['id'])) $crits = array('!id'=>$r['id']); 
		else $crits = array();
		//if ($arg) return $crits;
		return Utils_RecordBrowserCommon::merge_crits(array('!status'=>6), $crits);
	}
	
	public static function display_ticket_short($r) {
		if (is_numeric($r)) $r = Utils_RecordBrowserCommon::get_record('premium_tickets', $r);
		elseif(is_string($r) && preg_match('/^premium_tickets\/([0-9]+)$/',$r,$match)) $r = Utils_RecordBrowserCommon::get_record('premium_tickets', $match[1]);
		return $r['ticket_id'].': '.$r['title'];	
	}
	
	public static function adv_required_tickets_params($r){
		return array(	'cols'=>array('project_name'=>false,'priority'=>false),
						'format_callback'=>array('Premium_Projects_TicketsCommon','display_ticket_short'),
						'filters_defaults'=>array('project_name'=>$r['project_name']));
	}
	
	public static function applet_settings() {
		$conts = CRM_ContactsCommon::get_contacts(self::employees_crits(), array(), array('last_name'=>'ASC', 'first_name'=>'ASC'));
		$employees = array('USER' => __('Me'));
		foreach ($conts as $v) {
			$employees[$v['id']] = CRM_ContactsCommon::contact_format_no_company($v, true);
		}
		$tickets_types = array(''=>'['.__('All').']')+Utils_CommonDataCommon::get_translated_array('Premium_Ticket_Type');
		$applet_type = array(
			'unassigned'=>__('Unassigned tickets'), 
			'all_new'=>__('New tickets assigned to employee'), 
			'active'=>__('Active tickets assigned to employee'),  
			'all_assigned'=>__('All tickets assigned to employee'));
		if (self::testing_enabled())
			$applet_type['to_test'] = __('Employee\'s tickets - Awaiting tests');
		$applet_type['review'] = __('Employee\'s tickets - Awaiting review');
		$applet_type['all_owned'] = __('Employee\'s tickets - All');
		$applet_type['favs'] = __('Your favorites (ignores employee)');
        $applet_type['recent'] = __('Recently visited tickets');
		return Utils_RecordBrowserCommon::applet_settings(array(
			array('label'=>__('Title'),'name'=>'title','type'=>'text','default'=>__('Tickets')),
			array('label'=>__('Applet type'),'name'=>'applet_type','type'=>'select','default'=>'active','values'=>$applet_type),
			array('label'=>__('Tickets type'),'name'=>'tickets_type','type'=>'select','default'=>'','values'=>$tickets_types),
			array('label'=>__('Employee'),'name'=>'employee','type'=>'select','default'=>'USER','values'=>$employees),
		));
	}

	public static function testing_enabled() {
		return ModuleManager::is_installed('Premium_Projects_Tickets_Testing')>=0;
	}

	public static function search_format($id) {
		if(!Utils_RecordBrowserCommon::get_access('premium_tickets','browse')) return false;
		$row = Utils_RecordBrowserCommon::get_records('premium_tickets',array('id'=>$id));
		if(!$row) return false;
		$row = array_pop($row);
		return Utils_RecordBrowserCommon::record_link_open_tag('premium_tickets', $row['id']).__( 'Ticket (attachment) #%d, %s', array($row['ticket_id'], $row['project_name'])).Utils_RecordBrowserCommon::record_link_close_tag();
	}

	///////////////////////////////////
	// mobile devices

	public static function mobile_menu() {
		if(!Acl::is_user())
			return array();
		return array(__('Tickets')=>'mobile_tickets');
	}
	
	public static function mobile_tickets() {
		$me = CRM_ContactsCommon::get_my_record();
		$defaults = array('assigned_to'=>$me['id'], 'date'=>date('Y-m-d'), 'status'=>0, 'permission'=>0);
		Utils_RecordBrowserCommon::mobile_rb('premium_tickets',array_merge(array('assigned_to'=>array($me['id'])),Premium_Projects_TicketsCommon::active_tickets_crits()),array('status'=>'ASC', 'priority'=>'ASC', 'title'=>'ASC'),array('status'=>1,'priority'=>1),$defaults);
	}
	public static function crm_calendar_handler($action) {
		$args = func_get_args();
		array_shift($args);
		$ret = null;
		switch ($action) {
			case 'get_all': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_event_get_all'), $args);
							break;
			case 'update': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_event_update'), $args);
							break;
			case 'get': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_event_get'), $args);
							break;
			case 'delete': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_event_delete'), $args);
							break;
			case 'new_event_types': $ret = array(array('label'=>__('Ticket'),'icon'=>Base_ThemeCommon::get_template_file('Premium_Projects_Tickets','icon.png')));
							break;
			case 'new_event': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_new_event'), $args);
							break;
			case 'view_event': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_view_event'), $args);
							break;
			case 'edit_event': $ret = call_user_func_array(array('Premium_Projects_TicketsCommon','crm_edit_event'), $args);
							break;
			case 'recordset': $ret = 'premium_tickets';
		}
		return $ret;
	}
	
	public static function crm_view_event($id, $cal_obj) {
		$rb = $cal_obj->init_module('Utils_RecordBrowser', 'premium_tickets');
		$rb->view_entry('view', $id);
		return true;
	}
	public static function crm_edit_event($id, $cal_obj) {
		$rb = $cal_obj->init_module('Utils_RecordBrowser', 'premium_tickets');
		$rb->view_entry('edit', $id);
		return true;
	}
	public static function crm_new_event($timestamp, $timeless, $id, $object, $cal_obj) {
		$x = ModuleManager::get_instance('/Base_Box|0');
		if(!$x) trigger_error('There is no base box module instance',E_USER_ERROR);
		$me = CRM_ContactsCommon::get_my_record();
		$defaults = array('assigned_to'=>$me['id'], 'priority'=>1, 'permission'=>0, 'status'=>0, 'date'=>date('Y-m-d'));
		$defaults['due_date'] = date('Y-m-d', $timestamp);
		if($object) $defaults['assigned_to'] = $object;
		$x->push_main('Utils_RecordBrowser','view_entry',array('add', null, $defaults), 'premium_tickets');
	}

	public static function crm_event_delete($id) {
		Utils_RecordBrowserCommon::delete_record('premium_tickets',$id);
		return true;
	}
	public static function crm_event_update($id, $start, $duration, $timeless) {
		if (!$timeless) return false;
		$values = array('due_date'=>date('Y-m-d', $start));
		Utils_RecordBrowserCommon::update_record('premium_tickets', $id, $values);
		return true;
	}
	public static function crm_event_get_all($start, $end, $filter=null) {
		$start = date('Y-m-d',Base_RegionalSettingsCommon::reg2time($start));
		$crits = array();
		if ($filter===null) $filter = CRM_FiltersCommon::get();
		$f_array = explode(',',trim($filter,'()'));
		if($filter!='()' && $filter)
			$crits['('.'assigned_to'] = $f_array;
		$crits['<=due_date'] = $end;
		$crits['>=due_date'] = $start;
		
		$ret = Utils_RecordBrowserCommon::get_records('premium_tickets', $crits, array(), array(), CRM_CalendarCommon::$events_limit);

		$result = array();
		foreach ($ret as $r)
			$result[] = self::crm_event_get($r);

		return $result;
	}

	public static function crm_event_get($id) {
		if (!is_array($id)) {
			$r = Utils_RecordBrowserCommon::get_record('premium_tickets', $id);
		} else {
			$r = $id;
			$id = $r['id'];
		}

		$next = array('type'=>__('Ticket'));
		
		$day = $r['due_date'];
		$iday = strtotime($day);
		$next['id'] = $r['id'];

		$base_unix_time = strtotime(date('1970-01-01 00:00:00'));
		$next['start'] = $iday;
		$next['timeless'] = $day;

		$next['duration'] = -1;
		$next['title'] = (string)$r['title'];
		$next['description'] = (string)$r['description'];
		if ($r['status']!=6 && $r['status']!=4) {
			switch ($r['priority']) {
				case 0: $next['color'] = 'red'; break;
				case 1: $next['color'] = 'yellow'; break;
				case 2: $next['color'] = 'green'; break;
				case 3: $next['color'] = 'blue'; break;
			}
		} else {
			$next['color'] = 'gray';
		}

		$next['view_action'] = Utils_RecordBrowserCommon::create_record_href('premium_tickets', $r['id'], 'view');
		$next['edit_action'] = Utils_RecordBrowserCommon::create_record_href('premium_tickets', $r['id'], 'edit');

/*		$r_new = $r;
		if ($r['status']==0) $r_new['status'] = 1;
		if ($r['status']<=1) $next['actions'] = array(
			array('icon'=>Base_ThemeCommon::get_template_file('CRM/Meeting', 'close_event.png'), 'href'=>self::get_status_change_leightbox_href($r_new, false, array('id'=>'status')))
		);*/

        $start_time = Base_RegionalSettingsCommon::time2reg($next['start'],2,false,false);
        $event_date = Base_RegionalSettingsCommon::time2reg($next['start'],false,3,false);

        $inf2 = array(
            __('Date')=>'<b>'.$event_date.'</b>');

		$emps = array();
		foreach ($r['assigned_to'] as $e) {
			$e = CRM_ContactsCommon::contact_format_no_company($e, true);
			$e = str_replace('&nbsp;',' ',$e);
			if (mb_strlen($e,'UTF-8')>33) $e = mb_substr($e , 0, 30, 'UTF-8').'...';
			$emps[] = $e;
		}
		$next['busy_label'] = $r['assigned_to'];
		$inf2 += array(	__('Ticket') => '<b>'.$next['title'].'</b>',
						__('Description') => $next['description'],
						__('Assigned to') => implode('<br>',$emps),
						__('Status') => Utils_CommonDataCommon::get_value('Premium_Ticket_Status/'.$r['status'],true),
						__('Access') => Utils_CommonDataCommon::get_value('CRM/Access/'.$r['permission'],true),
						__('Priority') => Utils_CommonDataCommon::get_value('Premium_Ticket_Priorities/'.$r['priority'],true),
						__('Notes') => Utils_AttachmentCommon::count('premium_tickets/'.$r['id'])
					);

		$next['employees'] = $r['assigned_to'];
		$next['status'] = ($r['status']<4 || $r['status']==5)?'active':'closed';
		$next['custom_tooltip'] = 
									'<center><b>'.
										__('Ticket').
									'</b></center><br>'.
									Utils_TooltipCommon::format_info_tooltip($inf2).'<hr>'.
									CRM_ContactsCommon::get_html_record_info($r['created_by'],$r['created_on'],null,null);
		return $next;
	}

    public static function tray()
    {
        $slots = array();
        $statuses = Utils_CommonDataCommon::get_array('Premium_Ticket_Status', true);
        foreach ($statuses as $status => $status_label) {
            $slots[] = array(
                '__name__'    => $status_label,
                '__filters__' => array('status' => $status)
            );
        }
        return array(
            'premium_tickets' => array(
                '__title__'  => _M('Tickets'),
                '__slots__'  => $slots,
                '__weight__' => 2,
            )
        );
    }

}

?>