<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sr
 */
global $translations;
$translations['Change Status']='';
$translations['Mark as New']='';
$translations['Reopen']='';
$translations['Need Feedback']='';
$translations['Resolved']='';
$translations['Awaiting Feedback']='';
$translations['Assigned To']='';
$translations['Tickets']='';
$translations['No. of Notes']='';
$translations['Due Date']='';
$translations['Project']='';
$translations['Project Name']='';
$translations['Resolution']='';
$translations['Feedback']='';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='';
$translations['Required tickets']='';
$translations['Critical']='';
$translations['Major']='';
$translations['Minor']='';
$translations['Trivial']='';
$translations['Fixed']='';
$translations['Invalid']='';
$translations['Duplicate']='';
$translations['Will Not Fix']='';
$translations['Works For Me']='';
$translations['Ticket status']='';
$translations['Resolution is required when marking ticket as closed or resolved.']='';
$translations['Abandon ticket']='';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='';
$translations['Ticket Owner']='';
$translations['Ticket Type']='';
$translations['Ticket']='';
$translations['Assigned']='';
$translations['Search by ticket ID']='';
$translations['Bug tracker']='';
$translations['Projects & Tickets']='';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='';
$translations['Bug']='';
$translations['Feature Request']='';
