<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage et
 */
global $translations;
$translations['Change Status']='Muuda olekut';
$translations['Mark as New']='';
$translations['Reopen']='Taasava';
$translations['Need Feedback']='vajab tagasisidet';
$translations['Resolved']='Lahendatud';
$translations['Awaiting Feedback']='Tagasisidet ootamas';
$translations['Assigned To']='Suunatud';
$translations['Tickets']='Piletid';
$translations['No. of Notes']='Märgete arv';
$translations['Due Date']='Tähtaeg';
$translations['Project']='';
$translations['Project Name']='Projekti nimi';
$translations['Resolution']='Resolutsioon';
$translations['Feedback']='Tagasiside';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='Pileti ID';
$translations['Required tickets']='Nõutud piletid';
$translations['Critical']='Kriitiline';
$translations['Major']='Tähtis';
$translations['Minor']='Vähetähtis';
$translations['Trivial']='Tavaline';
$translations['Fixed']='Püsiv';
$translations['Invalid']='Vigane';
$translations['Duplicate']='Klooni';
$translations['Will Not Fix']='Ei paranda';
$translations['Works For Me']='Mulle sobib';
$translations['Ticket status']='Pileti olek';
$translations['Resolution is required when marking ticket as closed or resolved.']='Resolutsioon on nõutud, kui märgitud pilet on suletud või lahendatud';
$translations['Abandon ticket']='Hülga pilet';
$translations['Claim ticket']='Taotle piletit';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='Piletite liigid';
$translations['Ticket Owner']='';
$translations['Ticket Type']='';
$translations['Ticket']='Pilet';
$translations['Assigned']='';
$translations['Search by ticket ID']='Otsi pileti ID järgi';
$translations['Bug tracker']='Bugijälitaja';
$translations['Projects & Tickets']='';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='Blokeeritud tänu järgnevatele piletitele';
$translations['Blocks ticket ']='Blokeerib piletid ';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='';
$translations['Bug']='bugi';
$translations['Feature Request']='Arenduse tellimus';
