<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt
 */
global $translations;
$translations['Change Status']='';
$translations['Mark as New']='';
$translations['Reopen']='';
$translations['Need Feedback']='';
$translations['Resolved']='Resolvido';
$translations['Awaiting Feedback']='Aguardando Retorno';
$translations['Assigned To']='Atribuido a';
$translations['Tickets']='';
$translations['No. of Notes']='';
$translations['Due Date']='Data de Vencimento';
$translations['Project']='Projeto';
$translations['Project Name']='Nome do Projeto';
$translations['Resolution']='Resolução';
$translations['Feedback']='';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='ID do BIlhete';
$translations['Required tickets']='Bilhetes obrigatórios';
$translations['Critical']='Crítico';
$translations['Major']='Maior';
$translations['Minor']='Meno';
$translations['Trivial']='Normal';
$translations['Fixed']='Fixado';
$translations['Invalid']='Inválido';
$translations['Duplicate']='Duplicar';
$translations['Will Not Fix']='Não fixará';
$translations['Works For Me']='Funciona pra mim';
$translations['Ticket status']='Estado do bilhete';
$translations['Resolution is required when marking ticket as closed or resolved.']='';
$translations['Abandon ticket']='';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='Aguardando Revisão';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='';
$translations['Ticket Owner']='Dono do bilhete';
$translations['Ticket Type']='';
$translations['Ticket']='';
$translations['Assigned']='';
$translations['Search by ticket ID']='';
$translations['Bug tracker']='Projetos/Tickets';
$translations['Projects & Tickets']='Projetos & Tickets';
$translations['Tickets for Projects']='Tickets para projetos';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='Aguardando Testes';
$translations['Recently visited tickets']='';
$translations['Developer']='';
$translations['Bug']='Erro';
$translations['Feature Request']='Solicitação de recurso';
