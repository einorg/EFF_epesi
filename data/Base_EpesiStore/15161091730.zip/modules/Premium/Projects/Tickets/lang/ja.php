<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ja
 */
global $translations;
$translations['Change Status']='ステータス変更';
$translations['Mark as New']='新規';
$translations['Reopen']='再開';
$translations['Need Feedback']='フィードバックの要有';
$translations['Resolved']='解決済';
$translations['Awaiting Feedback']='フィードバック待ち';
$translations['Assigned To']='割当済';
$translations['Tickets']='チケット';
$translations['No. of Notes']='';
$translations['Due Date']='期日';
$translations['Project']='';
$translations['Project Name']='プロジェクト名';
$translations['Resolution']='解決';
$translations['Feedback']='';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='チケットID';
$translations['Required tickets']='要求されたチケット';
$translations['Critical']='クリティカル';
$translations['Major']='主要な';
$translations['Minor']='マイナーな';
$translations['Trivial']='些細な';
$translations['Fixed']='フィックスされた';
$translations['Invalid']='無効な';
$translations['Duplicate']='重複した';
$translations['Will Not Fix']='直されない';
$translations['Works For Me']='私の為に働く';
$translations['Ticket status']='チケットステータス';
$translations['Resolution is required when marking ticket as closed or resolved.']='要処理事項を終了もしくは解決済とする最終判断が必要です';
$translations['Abandon ticket']='破棄された処理事項';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='';
$translations['Ticket Owner']='チケット所有者';
$translations['Ticket Type']='';
$translations['Ticket']='チケット';
$translations['Assigned']='割当済';
$translations['Search by ticket ID']='';
$translations['Bug tracker']='バグ追跡';
$translations['Projects & Tickets']='プロジェクトとチケット';
$translations['Tickets for Projects']='プロジェクト用チケット';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='開発者';
$translations['Bug']='バグ';
$translations['Feature Request']='機能要求';
