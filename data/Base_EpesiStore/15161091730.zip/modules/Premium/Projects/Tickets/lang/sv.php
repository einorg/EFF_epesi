<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sv
 */
global $translations;
$translations['Change Status']='Ändra status';
$translations['Mark as New']='Markera som ny';
$translations['Reopen']='Öppna';
$translations['Need Feedback']='Behöver Feedback';
$translations['Resolved']='Lösta';
$translations['Awaiting Feedback']='Väntar på kommentar';
$translations['Assigned To']='Tilldelad';
$translations['Tickets']='Ärenden';
$translations['No. of Notes']='Antal Notes';
$translations['Due Date']='Förfallodatum';
$translations['Project']='Projekt';
$translations['Project Name']='Projektnamn';
$translations['Resolution']='Beslut';
$translations['Feedback']='Feedback';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='Ärende-ID';
$translations['Required tickets']='Obligatoriska ärenden';
$translations['Critical']='Kritisk';
$translations['Major']='Major';
$translations['Minor']='Mindre';
$translations['Trivial']='Trivial';
$translations['Fixed']='Lagad';
$translations['Invalid']='Ogiltig';
$translations['Duplicate']='Duplicerad';
$translations['Will Not Fix']='Kommer inte laga';
$translations['Works For Me']='Fungerar för mig';
$translations['Ticket status']='Ärendestatus';
$translations['Resolution is required when marking ticket as closed or resolved.']='Beslut krävs vid märkning ärende som stängd eller lösas.';
$translations['Abandon ticket']='Abandon ärende';
$translations['Claim ticket']='Fordran ärende';
$translations['Unassigned tickets']='Otilldelade ärenden';
$translations['New tickets assigned to employee']='Nya ärenden som tilldelats anställda';
$translations['Active tickets assigned to employee']='Aktiv ärenden som tilldelats anställda';
$translations['All tickets assigned to employee']='Alla ärenden som tilldelats anställda';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='Dina favoriter (utom anställd)';
$translations['Applet type']='Applet-typ';
$translations['Tickets type']='Ärendetyp';
$translations['Ticket Owner']='Ärende-ägare';
$translations['Ticket Type']='';
$translations['Ticket']='Ärende';
$translations['Assigned']='';
$translations['Search by ticket ID']='Sök på ärende-ID';
$translations['Bug tracker']='Bug tracker';
$translations['Projects & Tickets']='';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='Skymd av följande ärenden:';
$translations['Blocks ticket ']='Blockerar ärende';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='';
$translations['Bug']='Bug';
$translations['Feature Request']='Förfrågan om funktion';
