<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt_PT
 */
global $translations;
$translations['Change Status']='Alterar estado';
$translations['Mark as New']='Marcar como novo';
$translations['Reopen']='Reabrir';
$translations['Need Feedback']='Resposta necessária';
$translations['Resolved']='Resolvido';
$translations['Awaiting Feedback']='Aguarda resposta';
$translations['Assigned To']='Atribuido a';
$translations['Tickets']='Requisições';
$translations['No. of Notes']='N.º de notas';
$translations['Due Date']='Prazo de execução';
$translations['Project']='Projeto';
$translations['Project Name']='Nome do projeto';
$translations['Resolution']='Resolução';
$translations['Feedback']='Resposta';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='ID do Bilhete';
$translations['Required tickets']='Requisições obrigatórias';
$translations['Critical']='Crítico';
$translations['Major']='Maior';
$translations['Minor']='Meno';
$translations['Trivial']='Normal';
$translations['Fixed']='Corrigido';
$translations['Invalid']='Inválido';
$translations['Duplicate']='Duplicar';
$translations['Will Not Fix']='Não resulta';
$translations['Works For Me']='Funciona para mim';
$translations['Ticket status']='Estado do bilhete';
$translations['Resolution is required when marking ticket as closed or resolved.']='';
$translations['Abandon ticket']='';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='Aguardando Revisão';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='';
$translations['Ticket Owner']='Autor da requisição';
$translations['Ticket Type']='Tipo de requisição';
$translations['Ticket']='Requisição';
$translations['Assigned']='Atribuído';
$translations['Search by ticket ID']='';
$translations['Bug tracker']='Projetos/Requisições';
$translations['Projects & Tickets']='Projetos & Requisições';
$translations['Tickets for Projects']='Requisições para projetos';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='Aguardando Testes';
$translations['Recently visited tickets']='';
$translations['Developer']='Programador';
$translations['Bug']='Erro';
$translations['Feature Request']='Solicitação de recurso';
