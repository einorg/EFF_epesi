<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ru
 */
global $translations;
$translations['Change Status']='Изменить статус';
$translations['Mark as New']='Пометить как новое';
$translations['Reopen']='Переоткрыть';
$translations['Need Feedback']='Необходим ответ';
$translations['Resolved']='Решена';
$translations['Awaiting Feedback']='Ожидает ответа';
$translations['Assigned To']='Ассоциировать с';
$translations['Tickets']='Заявки';
$translations['No. of Notes']='';
$translations['Due Date']='Срок сдачи';
$translations['Project']='Проект';
$translations['Project Name']='Название проекта';
$translations['Resolution']='Заключение';
$translations['Feedback']='Ответ';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='Номер заявки';
$translations['Required tickets']='Обязательные заявки';
$translations['Critical']='Критический';
$translations['Major']='Основной';
$translations['Minor']='Незначительный';
$translations['Trivial']='Обычный';
$translations['Fixed']='Исправлено';
$translations['Invalid']='Неверно';
$translations['Duplicate']='Дубликат';
$translations['Will Not Fix']='Не будет исправлено';
$translations['Works For Me']='Работа для меня';
$translations['Ticket status']='Статус заявки';
$translations['Resolution is required when marking ticket as closed or resolved.']='Необходимо заключение для закрытия или решения заявки';
$translations['Abandon ticket']='Снять заявку';
$translations['Claim ticket']='Создать заявку';
$translations['Unassigned tickets']='Неопределенные заявки';
$translations['New tickets assigned to employee']='Новая заявка связанная с сотрудником';
$translations['Active tickets assigned to employee']='Активные заявки связанные с сотрудником';
$translations['All tickets assigned to employee']='Все заявки связанные с сотрудником';
$translations['Employee\'s tickets - Awaiting review']='Заявки сотрудников, ожидающие просмотра';
$translations['Employee\'s tickets - All']='Заявки сотрудников';
$translations['Your favorites (ignores employee)']='Избранное';
$translations['Applet type']='Тип виджета';
$translations['Tickets type']='Типы заявок';
$translations['Ticket Owner']='Автор заявки';
$translations['Ticket Type']='Тип заявки';
$translations['Ticket']='Заявка';
$translations['Assigned']='';
$translations['Search by ticket ID']='Поиск по номеру заявки';
$translations['Bug tracker']='Отладчик';
$translations['Projects & Tickets']='Проекты и билеты';
$translations['Tickets for Projects']='Заявки для проектов';
$translations['Blocked due to following tickets:']='Заблокированы следующие заявки:';
$translations['Blocks ticket ']='Блокировка заявки';
$translations['Employee\'s tickets - Awaiting tests']='Заявки сорудников, ожидающие тестирования';
$translations['Recently visited tickets']='';
$translations['Developer']='Разработчик';
$translations['Bug']='Ошибка';
$translations['Feature Request']='Запрос на доработку';
