<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Change Status']='Zmień status';
$translations['Mark as New']='Oznacz jako nowy';
$translations['Reopen']='Wznów';
$translations['Need Feedback']='Potrzebny komentarz';
$translations['Resolved']='Rozwiązane';
$translations['Awaiting Feedback']='Oczekiwany komentarz';
$translations['Assigned To']='Przypisany do';
$translations['Tickets']='Zgloszenia';
$translations['No. of Notes']='Ilość notek';
$translations['Due Date']='Termin';
$translations['Project']='Projekt';
$translations['Project Name']='Nazwa projektu';
$translations['Resolution']='Rozwiązanie';
$translations['Feedback']='Komentarz';
$translations['Ticket (attachment) #%d, %s']='Bilet (załącznik) #%d, %s';
$translations['Ticket ID']='Numer biletu';
$translations['Required tickets']='Wymagane bilety';
$translations['Critical']='Krytyczny';
$translations['Major']='Istotny';
$translations['Minor']='Zwykły';
$translations['Trivial']='Trywialny';
$translations['Fixed']='Naprawione';
$translations['Invalid']='Nieprawidłowy';
$translations['Duplicate']='Duplikat';
$translations['Will Not Fix']='Nie zostanie naprawione';
$translations['Works For Me']='U mnie działa';
$translations['Ticket status']='Status biletu';
$translations['Resolution is required when marking ticket as closed or resolved.']='Rozwiązanie jest wymagane kiedy status ma być ustawiony na zamkniętny lub rozwiązany.';
$translations['Abandon ticket']='Porzuć bilet';
$translations['Claim ticket']='Przyjmij bilet';
$translations['Unassigned tickets']='Bilety nieprzypisane';
$translations['New tickets assigned to employee']='Nowe bilety przypisane do pracownika';
$translations['Active tickets assigned to employee']='Aktywne bilety przypisane do pracownika';
$translations['All tickets assigned to employee']='Wszystkie bilety przypisane do pracownika';
$translations['Employee\'s tickets - Awaiting review']='Bilety pracownika - Oczekujące na przegląd';
$translations['Employee\'s tickets - All']='Bilety pracownika - Wszystkie';
$translations['Your favorites (ignores employee)']='Twoje ulubione (ignoruje pracownika)';
$translations['Applet type']='Typ apletu';
$translations['Tickets type']='Typ biletów';
$translations['Ticket Owner']='Właściciel biletu';
$translations['Ticket Type']='Typ biletu';
$translations['Ticket']='Bilet';
$translations['Assigned']='Przydzielone';
$translations['Search by ticket ID']='Szukaj po ID biletu';
$translations['Bug tracker']='Zarządzanie projektami';
$translations['Projects & Tickets']='Projekty i Zgloszenia';
$translations['Tickets for Projects']='Bilety pod Projektami';
$translations['Blocked due to following tickets:']='Zablokowany z powodu następujących biletów:';
$translations['Blocks ticket ']='Blokuje bilet ';
$translations['Employee\'s tickets - Awaiting tests']='Bilety pracownika - Oczekujące na testy';
$translations['Recently visited tickets']='Ostatnio odwiedzone zadania';
$translations['Developer']='Programista';
$translations['Bug']='Błąd';
$translations['Feature Request']='Nowa właściwość';
