<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage es
 */
global $translations;
$translations['Change Status']='Cambiar Estado';
$translations['Mark as New']='Marcar como Nuevo';
$translations['Reopen']='Re-Abrir';
$translations['Need Feedback']='Necesita Respuesta';
$translations['Resolved']='Resuelta';
$translations['Awaiting Feedback']='Testeando Solución';
$translations['Assigned To']='Asignado a';
$translations['Tickets']='Incidencias';
$translations['No. of Notes']='Nº de Notas:';
$translations['Due Date']='Fecha Vencimiento';
$translations['Project']='Proyecto';
$translations['Project Name']='Nombre del Proyecto';
$translations['Resolution']='Conclusión';
$translations['Feedback']='Retroalimentación';
$translations['Ticket (attachment) #%d, %s']='Incidencia (adjuntos) #%d, %s';
$translations['Ticket ID']='ID de Incidencia';
$translations['Required tickets']='Incidencia Requerida';
$translations['Critical']='1 Crítica';
$translations['Major']='2 Alta';
$translations['Minor']='2 Media';
$translations['Trivial']='3 Baja';
$translations['Fixed']='Solucionada';
$translations['Invalid']='Error de operación';
$translations['Duplicate']='Ya existente';
$translations['Will Not Fix']='No se puede corregir';
$translations['Works For Me']='No es Incidencia';
$translations['Ticket status']='Estado de la Incidencia';
$translations['Resolution is required when marking ticket as closed or resolved.']='Es necesario indicar una Conclusión al marcar la Incidencia como cerrada o resuelta.';
$translations['Abandon ticket']='Abandonar Incidencia';
$translations['Claim ticket']='Reclamar Incidencia';
$translations['Unassigned tickets']='Incidencias no asignadas';
$translations['New tickets assigned to employee']='Nuevas Incidencias asignadas al Usuario';
$translations['Active tickets assigned to employee']='Incidencias Activas asignados al Usuario';
$translations['All tickets assigned to employee']='Todas las Incidencias asignadas al Usuario';
$translations['Employee\'s tickets - Awaiting review']='Incidencias en espera de revisión';
$translations['Employee\'s tickets - All']='Incidencias - Todas';
$translations['Your favorites (ignores employee)']='Tus Favoritos (Ignora Empleados)';
$translations['Applet type']='Tipo de Applet';
$translations['Tickets type']='Tipo de Incidencia';
$translations['Ticket Owner']='Responsable de la Incidencia';
$translations['Ticket Type']='Tipo de Incidencia';
$translations['Ticket']='Incidencia';
$translations['Assigned']='Asignado';
$translations['Search by ticket ID']='Buscar por el ID de la Incidencia';
$translations['Bug tracker']='Gestión Postventa';
$translations['Projects & Tickets']='Proyectos &amp; Incidencias';
$translations['Tickets for Projects']='Incidencias de Proyectos';
$translations['Blocked due to following tickets:']='Bloqueado debido a las siguientes Incidencias:';
$translations['Blocks ticket ']='Bloquea a la Incidencia';
$translations['Employee\'s tickets - Awaiting tests']='Incidencias en espera de resultados de testeo';
$translations['Recently visited tickets']='';
$translations['Developer']='Soporte Técnico';
$translations['Bug']='Error de funcionamiento / Bug';
$translations['Feature Request']='Solicitud de nueva funcionalidad';
