<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Change Status']='Změnit stav';
$translations['Mark as New']='Označit jako nové';
$translations['Reopen']='Znovu otevřít';
$translations['Need Feedback']='Je potřeba zpětná vazba';
$translations['Resolved']='Vyřešeno';
$translations['Awaiting Feedback']='Čekání na odezvu';
$translations['Assigned To']='Přiřazeno';
$translations['Tickets']='Problémy';
$translations['No. of Notes']='Počet poznámek';
$translations['Due Date']='Termín';
$translations['Project']='Projekt';
$translations['Project Name']='Název projektu';
$translations['Resolution']='Řešení';
$translations['Feedback']='Zpětná vazba';
$translations['Ticket (attachment) #%d, %s']='Problémy (příloha) #%d, %s';
$translations['Ticket ID']='ID problému';
$translations['Required tickets']='Požadované problémy';
$translations['Critical']='Kritické';
$translations['Major']='Významné';
$translations['Minor']='Nízká';
$translations['Trivial']='Triviální';
$translations['Fixed']='Opraveno';
$translations['Invalid']='Neplatné';
$translations['Duplicate']='Duplicitní';
$translations['Will Not Fix']='Nebude se opravovat';
$translations['Works For Me']='Pro mě dobré';
$translations['Ticket status']='Stav problému';
$translations['Resolution is required when marking ticket as closed or resolved.']='Pro uzavření problému je potřeba uvést řešení.';
$translations['Abandon ticket']='Opustit problém';
$translations['Claim ticket']='Přihlásit se o problém';
$translations['Unassigned tickets']='Nepřiřazený problém';
$translations['New tickets assigned to employee']='Nový problém přiřazen zaměstnanci';
$translations['Active tickets assigned to employee']='Aktivní problémy přiřazeny zaměstnanci';
$translations['All tickets assigned to employee']='Všechny problémy přiřazeny zaměstnanci';
$translations['Employee\'s tickets - Awaiting review']='Zaměstnanecké problémy, čekající na posouzení';
$translations['Employee\'s tickets - All']='Všechny zaměstnanecké problémy';
$translations['Your favorites (ignores employee)']='Vaše oblíbené (ignoruje zaměstnance)';
$translations['Applet type']='Typ modulu';
$translations['Tickets type']='Druhy problému';
$translations['Ticket Owner']='Vlastník problému';
$translations['Ticket Type']='Druh problému';
$translations['Ticket']='Problém';
$translations['Assigned']='Přiřazeno';
$translations['Search by ticket ID']='Hledat podle ID lístku';
$translations['Bug tracker']='Projekty a Problémy';
$translations['Projects & Tickets']='Projekty a Problémy';
$translations['Tickets for Projects']='Problémy k projektům';
$translations['Blocked due to following tickets:']='Blokováno kvůli následujícím problémům:';
$translations['Blocks ticket ']='Blokuje lístky';
$translations['Employee\'s tickets - Awaiting tests']='Zaměstnanecké problémy, čekající na testování';
$translations['Recently visited tickets']='';
$translations['Developer']='Vývojář';
$translations['Bug']='Chyba';
$translations['Feature Request']='Požadavek';
