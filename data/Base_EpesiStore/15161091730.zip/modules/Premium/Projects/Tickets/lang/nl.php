<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage nl
 */
global $translations;
$translations['Change Status']='Verander status';
$translations['Mark as New']='Markeer als nieuw';
$translations['Reopen']='Heropenen';
$translations['Need Feedback']='Feedback benodigd';
$translations['Resolved']='Opgelost';
$translations['Awaiting Feedback']='In afwachting van feedback';
$translations['Assigned To']='Aangewezen aan';
$translations['Tickets']='Werkbon';
$translations['No. of Notes']='Aantal notities';
$translations['Due Date']='Deadline';
$translations['Project']='';
$translations['Project Name']='Projectnaam';
$translations['Resolution']='Oplossing';
$translations['Feedback']='';
$translations['Ticket (attachment) #%d, %s']='Werkbon (bijlage) #%d, %s';
$translations['Ticket ID']='Werkbon ID';
$translations['Required tickets']='Verplichte werkbon';
$translations['Critical']='Prio 1';
$translations['Major']='Hoog';
$translations['Minor']='Normaal';
$translations['Trivial']='Laag';
$translations['Fixed']='Opgelost';
$translations['Invalid']='Ongeldig';
$translations['Duplicate']='Duplicaat';
$translations['Will Not Fix']='Onopgelost';
$translations['Works For Me']='Tijdelijk opgelost';
$translations['Ticket status']='Status werkbon';
$translations['Resolution is required when marking ticket as closed or resolved.']='De klus moet volledig zijn afgerond alvorens deze te mogen afsluiten';
$translations['Abandon ticket']='Verlaat werkbon';
$translations['Claim ticket']='Accepteer werkbon';
$translations['Unassigned tickets']='Onaangewezen werkbonnen';
$translations['New tickets assigned to employee']='Nieuwe werkbonnen aangewezen aan';
$translations['Active tickets assigned to employee']='Actieve werkbonnen aangewezen aan';
$translations['All tickets assigned to employee']='Alle werkbonnen aangewezen aan';
$translations['Employee\'s tickets - Awaiting review']='Aangewezen werkbonnen in afwachting van review';
$translations['Employee\'s tickets - All']='Alle aangewezen werkbonnen';
$translations['Your favorites (ignores employee)']='Mijn favorieten';
$translations['Applet type']='';
$translations['Tickets type']='Werkbon type';
$translations['Ticket Owner']='Werkbon eigenaar';
$translations['Ticket Type']='Werbon type';
$translations['Ticket']='Werkbon';
$translations['Assigned']='Aangewezen';
$translations['Search by ticket ID']='Zoek via werkbonnummer';
$translations['Bug tracker']='Foutenzoeker';
$translations['Projects & Tickets']='Projecten en werkbonnen';
$translations['Tickets for Projects']='Projectbon';
$translations['Blocked due to following tickets:']='Geblokkeerd vanwege de volgende werkbonnen';
$translations['Blocks ticket ']='Werkbon geblokkeerd';
$translations['Employee\'s tickets - Awaiting tests']='Aangewezen werkbonnen in afwachting van test';
$translations['Recently visited tickets']='';
$translations['Developer']='Ontwikkelaar';
$translations['Bug']='Storing';
$translations['Feature Request']='Installatie klus';
