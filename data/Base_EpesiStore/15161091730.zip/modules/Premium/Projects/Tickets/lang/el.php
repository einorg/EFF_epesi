<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage el
 */
global $translations;
$translations['Change Status']='Αλλαγή κατάστασης';
$translations['Mark as New']='';
$translations['Reopen']='Επανάνοιγμα';
$translations['Need Feedback']='Need Feedback';
$translations['Resolved']='Αποφασισμένο';
$translations['Awaiting Feedback']='Αναμονή Feedback';
$translations['Assigned To']='Ανατέθηκε σε';
$translations['Tickets']='Αιτήσεις υποστήριξης';
$translations['No. of Notes']='Αρ. Σημειώσεων';
$translations['Due Date']='Ημερομηνία λήξης';
$translations['Project']='';
$translations['Project Name']='Όνομα έργου';
$translations['Resolution']='Ψήφισμα';
$translations['Feedback']='Feedback';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='ID αιτήσεων υποστήριξης';
$translations['Required tickets']='Απαιτούμενες αιτήσεις υποστήριξης';
$translations['Critical']='Κρίσιμο';
$translations['Major']='Μέγιστος';
$translations['Minor']='Ελάχιστος';
$translations['Trivial']='Ασήμαντο';
$translations['Fixed']='Σταθερό';
$translations['Invalid']='Μη έγκυρο';
$translations['Duplicate']='Αντίγραφο';
$translations['Will Not Fix']='Δεν φτίαχνεται';
$translations['Works For Me']='Εργασίες Για Μένα';
$translations['Ticket status']='Κατάσταση αίτησης υποστήριξης';
$translations['Resolution is required when marking ticket as closed or resolved.']='Η ανάλυση είναι απαραίτητη όταν σημειώνεται μία αίτηση ς κλεισμένη ή αποφασισμένη.';
$translations['Abandon ticket']='Αγνοήστε υποστήριξη';
$translations['Claim ticket']='Ζητήστε υποστήριξη';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='Τύπος αιτήσεων υποστήριξης';
$translations['Ticket Owner']='';
$translations['Ticket Type']='';
$translations['Ticket']='Αίτηση υποστήριξης';
$translations['Assigned']='';
$translations['Search by ticket ID']='Αναζήτηση κατά ID αιτήσεων υποστήριξης';
$translations['Bug tracker']='Bug tracker';
$translations['Projects & Tickets']='Εργασίες & Εισιτήρια';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='Αποκλεισμός λόγω των ακόλουθων αιτήσεων υποστήριξης:';
$translations['Blocks ticket ']='Αποκλεισμός αιτήσεων υποστήριξης ';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='';
$translations['Bug']='Bug';
$translations['Feature Request']='Χαρακτηριστικό αίτησης';
