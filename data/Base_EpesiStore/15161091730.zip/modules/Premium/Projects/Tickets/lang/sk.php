<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sk
 */
global $translations;
$translations['Change Status']='Zmeniť stav';
$translations['Mark as New']='Označiť ako nove';
$translations['Reopen']='Opäť otvoriť';
$translations['Need Feedback']='Je potrebná spätná väzba';
$translations['Resolved']='Vyriešené';
$translations['Awaiting Feedback']='Čakanie na spätnä väzbu';
$translations['Assigned To']='Priradené';
$translations['Tickets']='Tikety';
$translations['No. of Notes']='Počet poznámok';
$translations['Due Date']='Požadovaný dátum';
$translations['Project']='Projekt';
$translations['Project Name']='Názov projektu';
$translations['Resolution']='Riešenie';
$translations['Feedback']='Spätná väzba';
$translations['Ticket (attachment) #%d, %s']='Tiket (príloha) #%d, %s';
$translations['Ticket ID']='ID tiketu';
$translations['Required tickets']='Požadované tikety';
$translations['Critical']='Kritické';
$translations['Major']='Významne';
$translations['Minor']='Nízka';
$translations['Trivial']='Trivialne';
$translations['Fixed']='Opravene';
$translations['Invalid']='Neplatné';
$translations['Duplicate']='Duplicitné';
$translations['Will Not Fix']='Nebude sa opravovať';
$translations['Works For Me']='Pre mňa dobré';
$translations['Ticket status']='Stav tiketu';
$translations['Resolution is required when marking ticket as closed or resolved.']='Pri uzatváraní tiketu je potrebné uviesť riešenie';
$translations['Abandon ticket']='Opustiť tiket';
$translations['Claim ticket']='Prihlásiť sa o tiket';
$translations['Unassigned tickets']='Nepriradený tiket';
$translations['New tickets assigned to employee']='Nový tiket priradený zamestnancovi';
$translations['Active tickets assigned to employee']='Aktívne tikety priradené zamestnancom';
$translations['All tickets assigned to employee']='Všetky tikety priradené zamestnancom';
$translations['Employee\'s tickets - Awaiting review']='Zmamestnanecké tikety, čakajúce na posúdenie';
$translations['Employee\'s tickets - All']='Všetky zamestnanecké tikety';
$translations['Your favorites (ignores employee)']='Vaše obľúbené (ignoruje zamestnancov)';
$translations['Applet type']='Typ appletu';
$translations['Tickets type']='Druhy tiketov';
$translations['Ticket Owner']='Vlastník tiketu';
$translations['Ticket Type']='Druh tiketu';
$translations['Ticket']='Tiket';
$translations['Assigned']='Priradené';
$translations['Search by ticket ID']='Hľadať podľa ID tiketu';
$translations['Bug tracker']='Projekty a tikety';
$translations['Projects & Tickets']='Projekty a tikety';
$translations['Tickets for Projects']='Tikety pre projekty';
$translations['Blocked due to following tickets:']='Blokováne kvôli nasledujúcim tiketom:';
$translations['Blocks ticket ']='Blokované tikety';
$translations['Employee\'s tickets - Awaiting tests']='Zamestnanecke tikety, čakajúce na testovanie';
$translations['Recently visited tickets']='';
$translations['Developer']='Vývojar';
$translations['Bug']='Chyba';
$translations['Feature Request']='Požiadavka';
