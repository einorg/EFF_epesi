<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sl
 */
global $translations;
$translations['Change Status']='Spremeni status';
$translations['Mark as New']='Označi kot novo';
$translations['Reopen']='Ponovno odpri';
$translations['Need Feedback']='Potrebna povratna informacija';
$translations['Resolved']='Rešeno';
$translations['Awaiting Feedback']='Čakam odgovor';
$translations['Assigned To']='Dodelje k';
$translations['Tickets']='Zadolžitve';
$translations['No. of Notes']='Št. beležk';
$translations['Due Date']='Rok';
$translations['Project']='Projekt';
$translations['Project Name']='Št. in kratek opis projekta';
$translations['Resolution']='Rešitev';
$translations['Feedback']='Povratna informacija';
$translations['Ticket (attachment) #%d, %s']='Zadolžitev (priloga) #%d, %s';
$translations['Ticket ID']='ID Zadolžitve';
$translations['Required tickets']='Potrebne zadolžitve';
$translations['Critical']='Kritično';
$translations['Major']='Huje';
$translations['Minor']='Manjše';
$translations['Trivial']='V vednost';
$translations['Fixed']='Končano';
$translations['Invalid']='Neveljavno';
$translations['Duplicate']='Podvojeno';
$translations['Will Not Fix']='Ne bo izvedeno';
$translations['Works For Me']='Delo zame';
$translations['Ticket status']='Status zadolžitve';
$translations['Resolution is required when marking ticket as closed or resolved.']='Zahteva se sklep v kolikor se zadolžitev označi kot zaprta ali rešena.';
$translations['Abandon ticket']='Zapuščena zadolžitev';
$translations['Claim ticket']='Zahtevana zadolžitev';
$translations['Unassigned tickets']='Nedodeljena zadolžitev';
$translations['New tickets assigned to employee']='Nova zadolžitev referentu';
$translations['Active tickets assigned to employee']='Aktivne zadolžitve dodeljene referentu';
$translations['All tickets assigned to employee']='Vse zadolžitve dodeljene referentu';
$translations['Employee\'s tickets - Awaiting review']='Zadolžitve referenta: Na čakanju za pregled';
$translations['Employee\'s tickets - All']='Zadolžitve referenta: Vse';
$translations['Your favorites (ignores employee)']='Tvoji zaznamki (prezrti referenti)';
$translations['Applet type']='Tip pripomočka';
$translations['Tickets type']='Tip zadolžitve';
$translations['Ticket Owner']='Zadolžitev določil';
$translations['Ticket Type']='Tip zadolžitve';
$translations['Ticket']='Zadolžitev';
$translations['Assigned']='Dodeljen';
$translations['Search by ticket ID']='Iskanje po ID zadolžitve';
$translations['Bug tracker']='Projekti in zadolžitve';
$translations['Projects & Tickets']='Projekti in zadolžitve';
$translations['Tickets for Projects']='Zadolžitev za projekte';
$translations['Blocked due to following tickets:']='Blokirano zaradi naslednjih zadolžitev:';
$translations['Blocks ticket ']='Blokirane zadolžitve';
$translations['Employee\'s tickets - Awaiting tests']='Zadolžitve referenta: Čakanje na sledenje';
$translations['Recently visited tickets']='';
$translations['Developer']='Izvajalec';
$translations['Bug']='Sledilnik';
$translations['Feature Request']='Prošnja za novo stvar';
