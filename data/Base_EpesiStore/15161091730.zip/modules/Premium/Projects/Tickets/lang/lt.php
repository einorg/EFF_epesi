<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage lt
 */
global $translations;
$translations['Change Status']='Pakeisti statusą';
$translations['Mark as New']='';
$translations['Reopen']='Atnaujinti';
$translations['Need Feedback']='Reikalingas atsiliepimas';
$translations['Resolved']='Išspręsta';
$translations['Awaiting Feedback']='Laukiama atsiliepimo';
$translations['Assigned To']='Priskirta atlikti';
$translations['Tickets']='Kortelės';
$translations['No. of Notes']='Nr. pastabos';
$translations['Due Date']='Atlikti iki';
$translations['Project']='';
$translations['Project Name']='Projekto pavadinimas';
$translations['Resolution']='Sprendimas';
$translations['Feedback']='Atsiliepimas';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='Kortelės ID';
$translations['Required tickets']='Reikalingos kortelės';
$translations['Critical']='Kritinis';
$translations['Major']='Svarbus';
$translations['Minor']='Paprastas';
$translations['Trivial']='Nesvarbus';
$translations['Fixed']='Padaryta';
$translations['Invalid']='Klaida';
$translations['Duplicate']='Dublikatas';
$translations['Will Not Fix']='Nepadarysiu';
$translations['Works For Me']='Darbas man';
$translations['Ticket status']='Kortelės statusas';
$translations['Resolution is required when marking ticket as closed or resolved.']='Spendimas reikalingas tada kai kortelė yra uždaroma arba pašalinama.';
$translations['Abandon ticket']='';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='Kortelės tipas';
$translations['Ticket Owner']='Kortelės savininkas';
$translations['Ticket Type']='';
$translations['Ticket']='';
$translations['Assigned']='';
$translations['Search by ticket ID']='Ieškoti pagal kortelės ID';
$translations['Bug tracker']='Klaidų sekimas';
$translations['Projects & Tickets']='';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='Vykdytojas';
$translations['Bug']='Klaida';
$translations['Feature Request']='Užduotis';
