<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage it
 */
global $translations;
$translations['Change Status']='Cambia Stato';
$translations['Mark as New']='';
$translations['Reopen']='Riaprire';
$translations['Need Feedback']='Feedback Richiesto';
$translations['Resolved']='Risolto';
$translations['Awaiting Feedback']='In attesa di riscontro';
$translations['Assigned To']='Assegnato a';
$translations['Tickets']='Tickets';
$translations['No. of Notes']='Numero di note';
$translations['Due Date']='Scadenza';
$translations['Project']='';
$translations['Project Name']='Nome progetto';
$translations['Resolution']='Risoluzione';
$translations['Feedback']='Feedback';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='Ticket ID';
$translations['Required tickets']='Tickets richiesti';
$translations['Critical']='Critico';
$translations['Major']='Maggiore';
$translations['Minor']='Minore';
$translations['Trivial']='Insignificante';
$translations['Fixed']='Risolto';
$translations['Invalid']='non valido';
$translations['Duplicate']='Duplicato';
$translations['Will Not Fix']='Non risolve';
$translations['Works For Me']='Funziona Per Me';
$translations['Ticket status']='Stato ticket';
$translations['Resolution is required when marking ticket as closed or resolved.']='La risoluzione e\' necessaria quando lo stato del ticket e\' chiuso o risolto.';
$translations['Abandon ticket']='Abbandona ticket';
$translations['Claim ticket']='reclamo ticket';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='Tipo ticket';
$translations['Ticket Owner']='Proprietario Ticket';
$translations['Ticket Type']='';
$translations['Ticket']='Ticket';
$translations['Assigned']='';
$translations['Search by ticket ID']='Cerca per ID ticket';
$translations['Bug tracker']='Tracciamento difetti';
$translations['Projects & Tickets']='Progetti & Ticket';
$translations['Tickets for Projects']='';
$translations['Blocked due to following tickets:']='Bloccato a causa dei seguenti tickets:';
$translations['Blocks ticket ']='Blocchi ticket';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='Sviluppatore';
$translations['Bug']='Difetto';
$translations['Feature Request']='Funzione richiesta';
