<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage tr
 */
global $translations;
$translations['Change Status']='Durumu Değiştir';
$translations['Mark as New']='Yeni Olarak İşle';
$translations['Reopen']='Tekrar aç';
$translations['Need Feedback']='Geribildirim Gerekli';
$translations['Resolved']='Çözümlendi';
$translations['Awaiting Feedback']='Cevaplanmak için bekleyenler';
$translations['Assigned To']='Atanan';
$translations['Tickets']='Takip sayfalarý';
$translations['No. of Notes']='Not yok';
$translations['Due Date']='Tarih';
$translations['Project']='Proje';
$translations['Project Name']='Proje adı';
$translations['Resolution']='Çözünürlük';
$translations['Feedback']='Geribildirim';
$translations['Ticket (attachment) #%d, %s']='Ticket (Eki) #%d, %s';
$translations['Ticket ID']='Ticket ID';
$translations['Required tickets']='Ticket Gerekli';
$translations['Critical']='Kritik';
$translations['Major']='Önemli';
$translations['Minor']='Önemsiz';
$translations['Trivial']='Gözardý edilebilir';
$translations['Fixed']='Çözüldü';
$translations['Invalid']='Geçersiz';
$translations['Duplicate']='Kopya Ekle';
$translations['Will Not Fix']='Çözülmedi';
$translations['Works For Me']='Benim sorumluluklarým';
$translations['Ticket status']='Ticket Durumu';
$translations['Resolution is required when marking ticket as closed or resolved.']='Ticketı kapatmatmak yada çözüldüyü işaretlemek için Çözüm yazılması gerekli';
$translations['Abandon ticket']='Cevapsýz takip sayfasý';
$translations['Claim ticket']='Takip sayfasý talebi';
$translations['Unassigned tickets']='Atanmayan Ticket';
$translations['New tickets assigned to employee']='Personele Ticket atandı.';
$translations['Active tickets assigned to employee']='Aktif Ticketlar Personele atandı';
$translations['All tickets assigned to employee']='Personele atanan tüm Ticketlar';
$translations['Employee\'s tickets - Awaiting review']='Personel Ticketları - Görüntüleme Bekliyor';
$translations['Employee\'s tickets - All']='Personel Ticketları - Tümü';
$translations['Your favorites (ignores employee)']='Sık kullanılanlarınız (Personelleri dışında bırak)';
$translations['Applet type']='Eklenti türü';
$translations['Tickets type']='Takip sayfalarý tipi';
$translations['Ticket Owner']='Ticket Sahibi';
$translations['Ticket Type']='Ticket türü';
$translations['Ticket']='Ticket';
$translations['Assigned']='Onaylı';
$translations['Search by ticket ID']='Ticket ID ile ara';
$translations['Bug tracker']='Hata Kaydı';
$translations['Projects & Tickets']='Proje & Ticketlar';
$translations['Tickets for Projects']='Proje Ticketları';
$translations['Blocked due to following tickets:']='Takip edilen ticketları engelle';
$translations['Blocks ticket ']='Ticketları engelle';
$translations['Employee\'s tickets - Awaiting tests']='Personel Ticketları - Bekleyen testler';
$translations['Recently visited tickets']='';
$translations['Developer']='Geliştirici';
$translations['Bug']='Hata';
$translations['Feature Request']='Yeni fonksiyon talebi';
