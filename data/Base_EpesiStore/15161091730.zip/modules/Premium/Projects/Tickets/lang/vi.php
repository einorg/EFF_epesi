<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage vi
 */
global $translations;
$translations['Change Status']='Thay đổi trạng thái';
$translations['Mark as New']='Đánh dấu là Mới';
$translations['Reopen']='Mở cửa trở lại';
$translations['Need Feedback']='Cần phản hồi';
$translations['Resolved']='Đã lấy xong';
$translations['Awaiting Feedback']='Chờ phản hồi';
$translations['Assigned To']='Phân công';
$translations['Tickets']='Vé';
$translations['No. of Notes']='Số Ghi chú';
$translations['Due Date']='Kết thúc';
$translations['Project']='Dự án';
$translations['Project Name']='Tên dự án';
$translations['Resolution']='Độ phân giải';
$translations['Feedback']='Thông tin phản hồi';
$translations['Ticket (attachment) #%d, %s']='Vé (file đính kèm) #%d, %s';
$translations['Ticket ID']='Vé ID';
$translations['Required tickets']='Vé được yêu cầu';
$translations['Critical']='Quan trọng';
$translations['Major']='Chính';
$translations['Minor']='Phụ';
$translations['Trivial']='Không quan trọng';
$translations['Fixed']='Cố định';
$translations['Invalid']='Không hợp lệ';
$translations['Duplicate']='Trùng lặp';
$translations['Will Not Fix']='sẽ không sửa';
$translations['Works For Me']='Làm việc cho tôi';
$translations['Ticket status']='Trạng thái vé';
$translations['Resolution is required when marking ticket as closed or resolved.']='Độ phân giải được yêu cầu khi đánh dấu vé như đóng cửa hoặc giải quyết.';
$translations['Abandon ticket']='Bỏ vé';
$translations['Claim ticket']='Bồi thường vé';
$translations['Unassigned tickets']='Vé không được gán';
$translations['New tickets assigned to employee']='Vé mới được gán cho nhân viên';
$translations['Active tickets assigned to employee']='Vé hoạt động được gán cho nhân viên';
$translations['All tickets assigned to employee']='Tất cả vé được gán cho nhân viên';
$translations['Employee\'s tickets - Awaiting review']='Vé của nhân viên - Đang chờ xem lại';
$translations['Employee\'s tickets - All']='Vé của nhân viên - Tất cả';
$translations['Your favorites (ignores employee)']='Yêu thích của bạn (bỏ qua nhân viên)';
$translations['Applet type']='Loại applet';
$translations['Tickets type']='Loại vé';
$translations['Ticket Owner']='Chủ vé';
$translations['Ticket Type']='Loại vé';
$translations['Ticket']='Vé';
$translations['Assigned']='Đã giao';
$translations['Search by ticket ID']='Tìm kiếm theo vé ID';
$translations['Bug tracker']='Theo dõi';
$translations['Projects & Tickets']='Dự án và Tickets';
$translations['Tickets for Projects']='Vé cho các dự án';
$translations['Blocked due to following tickets:']='Bị chặn do vé như sau:';
$translations['Blocks ticket ']='Chặn vé';
$translations['Employee\'s tickets - Awaiting tests']='Vé của nhân viên - Đang chờ kiểm tra';
$translations['Recently visited tickets']='';
$translations['Developer']='Lập trình viên';
$translations['Bug']='Lỗi';
$translations['Feature Request']='Tính năng yêu cầu';
