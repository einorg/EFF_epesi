<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Change Status']='Status ändern';
$translations['Mark as New']='Als neu markieren';
$translations['Reopen']='Wieder geöffnet';
$translations['Need Feedback']='Brauche Feedback';
$translations['Resolved']='Gelöst';
$translations['Awaiting Feedback']='Erwarte Rückmeldung';
$translations['Assigned To']='Zugewiesen an';
$translations['Tickets']='Tickets';
$translations['No. of Notes']='Anzahl der Notizen';
$translations['Due Date']='Fällig am';
$translations['Project']='Projekt';
$translations['Project Name']='Projektname';
$translations['Resolution']='Lösung';
$translations['Feedback']='Feedback';
$translations['Ticket (attachment) #%d, %s']='Ticket (Anhang) #%d, %s';
$translations['Ticket ID']='Ticket ID';
$translations['Required tickets']='Benötigte Tickets';
$translations['Critical']='Kritisch';
$translations['Major']='Schwerwiegend';
$translations['Minor']='Gering';
$translations['Trivial']='Trivial';
$translations['Fixed']='Behoben';
$translations['Invalid']='Ungültig';
$translations['Duplicate']='Duplikat';
$translations['Will Not Fix']='Wird nicht behoben';
$translations['Works For Me']='Funktioniert hier';
$translations['Ticket status']='Ticket Status';
$translations['Resolution is required when marking ticket as closed or resolved.']='Lösung wird benötigt wenn ein Ticket als geschlossen oder gelöst markiert wird.';
$translations['Abandon ticket']='Ticket ausbuchen';
$translations['Claim ticket']='Ticket einfordern';
$translations['Unassigned tickets']='Nicht zugewiesene Tickets';
$translations['New tickets assigned to employee']='Neuzugewiesene Tickets des Mitarbeiters';
$translations['Active tickets assigned to employee']='Zugewiesene aktive Tickets des Mitarbeiters';
$translations['All tickets assigned to employee']='Alle dem Mitarbeiter zugewiesene Tickets';
$translations['Employee\'s tickets - Awaiting review']='Mitarbeiter-Tickets - auf Überprüfung wartend';
$translations['Employee\'s tickets - All']='Alle Mitarbeitertickets';
$translations['Your favorites (ignores employee)']='Ihre Favoriten (nicht mitarbeiterabhängig)';
$translations['Applet type']='';
$translations['Tickets type']='Ticket Typ';
$translations['Ticket Owner']='Ticket-Besitzer';
$translations['Ticket Type']='Ticket Typ';
$translations['Ticket']='Ticket';
$translations['Assigned']='';
$translations['Search by ticket ID']='Nach Ticket ID suchen';
$translations['Bug tracker']='Projektverwaltung';
$translations['Projects & Tickets']='Projekte & Tickets';
$translations['Tickets for Projects']='Projekt Tickets';
$translations['Blocked due to following tickets:']='Aufgrund folgender Tickets gesperrt:';
$translations['Blocks ticket ']='Sperrt Ticket';
$translations['Employee\'s tickets - Awaiting tests']='Mitarbeiter Tickets - zu testen';
$translations['Recently visited tickets']='';
$translations['Developer']='Entwickler';
$translations['Bug']='Fehler';
$translations['Feature Request']='Erweiterung';
