<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Change Status']='';
$translations['Mark as New']='';
$translations['Reopen']='';
$translations['Need Feedback']='';
$translations['Resolved']='مصمم';
$translations['Awaiting Feedback']='در انتظار انتقادات و پیشنهادات';
$translations['Assigned To']='واگذار شده به';
$translations['Tickets']='درخواستهای پشتیبانی';
$translations['No. of Notes']='';
$translations['Due Date']='موعد مقرر';
$translations['Project']='';
$translations['Project Name']='نام پروژه';
$translations['Resolution']='حل';
$translations['Feedback']='';
$translations['Ticket (attachment) #%d, %s']='';
$translations['Ticket ID']='ID درخواست';
$translations['Required tickets']='درخواست مورد نیاز';
$translations['Critical']='بحرانی';
$translations['Major']='عمده';
$translations['Minor']='جزئی';
$translations['Trivial']='ناچیز';
$translations['Fixed']='تعمیر شده';
$translations['Invalid']='نامعتبر';
$translations['Duplicate']='تکراری';
$translations['Will Not Fix']='تعمیر نشده';
$translations['Works For Me']='این نسخهها کار میکند برای من';
$translations['Ticket status']='وضعیت درخواست';
$translations['Resolution is required when marking ticket as closed or resolved.']='';
$translations['Abandon ticket']='';
$translations['Claim ticket']='';
$translations['Unassigned tickets']='';
$translations['New tickets assigned to employee']='درخواست پشتیبانی جدبد منتصب شده به کارمند';
$translations['Active tickets assigned to employee']='درخواست های پشتیبانی فعال منتصب به کارمند';
$translations['All tickets assigned to employee']='تمامی درخواست های پشتیبانی منتصب به کارمند';
$translations['Employee\'s tickets - Awaiting review']='درخواست های پشتیبانی کارمند - پیشنمایش در انتظار ها';
$translations['Employee\'s tickets - All']='درخواست های پشتیبانی کارمند - همه';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='نوع افزونه';
$translations['Tickets type']='انواع درخواست های پشتیبانی';
$translations['Ticket Owner']='مالک درخواست';
$translations['Ticket Type']='نوع درخواست پشتیبانی';
$translations['Ticket']='درخواست';
$translations['Assigned']='واگذار شده';
$translations['Search by ticket ID']='';
$translations['Bug tracker']='اشکالات';
$translations['Projects & Tickets']='پروژه ها و درخواستهای پشتیبانی';
$translations['Tickets for Projects']='درخواس پشتیبانی برای پروژه';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='';
$translations['Employee\'s tickets - Awaiting tests']='درخواست های پشتیبانی کارمند - در انتظار آزمایش';
$translations['Recently visited tickets']='';
$translations['Developer']='توسعه دهنده';
$translations['Bug']='حفره امنیتی';
$translations['Feature Request']='درخواست ویژگی';
