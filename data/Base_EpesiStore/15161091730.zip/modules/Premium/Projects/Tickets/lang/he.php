<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage he
 */
global $translations;
$translations['Change Status']='';
$translations['Mark as New']='';
$translations['Reopen']='';
$translations['Need Feedback']='צריך משוב';
$translations['Resolved']='נפתר';
$translations['Awaiting Feedback']='מחכה למשוב';
$translations['Assigned To']='הוקצה אל';
$translations['Tickets']='כרטיסי עבודה';
$translations['No. of Notes']='';
$translations['Due Date']='תאריך יעד';
$translations['Project']='פרוייקט';
$translations['Project Name']='שם פרויקט';
$translations['Resolution']='החלטה';
$translations['Feedback']='משוב';
$translations['Ticket (attachment) #%d, %s']='כרטיס (קובץ מצורף)';
$translations['Ticket ID']='מספר כרטיס';
$translations['Required tickets']='כרטיסי עבודה נדרשים';
$translations['Critical']='קריטי';
$translations['Major']='מָג\'וֹרִי';
$translations['Minor']='מינורי';
$translations['Trivial']='ברור מאליו';
$translations['Fixed']='תוקן';
$translations['Invalid']='לא זמין';
$translations['Duplicate']='שכפול';
$translations['Will Not Fix']='לא יתוקן';
$translations['Works For Me']='עובד בשבילי';
$translations['Ticket status']='סטטוס כרטיס';
$translations['Resolution is required when marking ticket as closed or resolved.']='החלטה נדרשת כאשר סומן שכרטיס נסגר או נפתר';
$translations['Abandon ticket']='נטוש כרטיס';
$translations['Claim ticket']='בקש כרטיס';
$translations['Unassigned tickets']='כרטיס לא משוייך';
$translations['New tickets assigned to employee']='';
$translations['Active tickets assigned to employee']='';
$translations['All tickets assigned to employee']='';
$translations['Employee\'s tickets - Awaiting review']='';
$translations['Employee\'s tickets - All']='';
$translations['Your favorites (ignores employee)']='';
$translations['Applet type']='';
$translations['Tickets type']='סוגי כרטיסים';
$translations['Ticket Owner']='כרטיס על שם';
$translations['Ticket Type']='סוג כרטיס';
$translations['Ticket']='כרטיס';
$translations['Assigned']='מוקצה';
$translations['Search by ticket ID']='חפש על פי מספר כרטיס';
$translations['Bug tracker']='מעקב פניות';
$translations['Projects & Tickets']='פרויקטים וכרטיסי עבודה';
$translations['Tickets for Projects']='כרטיסי עבודה עבור פרויקטים';
$translations['Blocked due to following tickets:']='';
$translations['Blocks ticket ']='כרטיס חסום';
$translations['Employee\'s tickets - Awaiting tests']='';
$translations['Recently visited tickets']='';
$translations['Developer']='מפתח';
$translations['Bug']='באג';
$translations['Feature Request']='בקשה עתידית';
