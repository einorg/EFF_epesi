<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ru
 */
global $translations;
$translations['Change Status']='Изменить статус';
$translations['Result']='Результат';
$translations['Ticket ID']='Номер заявки';
$translations['Ticket']='Заявка';
$translations['Bug tracker']='Отладчик';
$translations['Projects & Tickets']='Проекты и билеты';
$translations['Testing']='Тестирование';
$translations['Tickets Testing']='Тестирование билета';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='Начало теста';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='Выполнена';
$translations['Tested']='';
$translations['Signed up']='Занялся исполнением';
$translations['Working']='Обрабатывается';
$translations['Additional Feedback']='Требует доработки';
