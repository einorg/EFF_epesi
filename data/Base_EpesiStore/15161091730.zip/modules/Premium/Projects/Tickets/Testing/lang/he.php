<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage he
 */
global $translations;
$translations['Change Status']='';
$translations['Result']='תוצאה';
$translations['Ticket ID']='מספר כרטיס';
$translations['Ticket']='כרטיס';
$translations['Bug tracker']='מעקב פניות';
$translations['Projects & Tickets']='פרויקטים וכרטיסי עבודה';
$translations['Testing']='בדיקות';
$translations['Tickets Testing']='בדיקות כרטיסי עבודה';
$translations['Testing procedure for Tickets']='תהליכי בדיקה עבור כרטיסי עבודה';
$translations['Result is required when marking test as closed.']='חובה להגדיר תוצאה לפני סגירה';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='נגמר ב';
$translations['Tested']='נבדק';
$translations['Signed up']='נרשם';
$translations['Working']='עובד';
$translations['Additional Feedback']='פידבק נוסף';
