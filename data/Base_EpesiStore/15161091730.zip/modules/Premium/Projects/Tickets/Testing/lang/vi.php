<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage vi
 */
global $translations;
$translations['Change Status']='Thay đổi trạng thái';
$translations['Result']='Kết quả';
$translations['Ticket ID']='Vé ID';
$translations['Ticket']='Vé';
$translations['Bug tracker']='Theo dõi';
$translations['Projects & Tickets']='Dự án và Tickets';
$translations['Testing']='';
$translations['Tickets Testing']='Vé đang kiểm tra';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
