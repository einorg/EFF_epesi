<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt_PT
 */
global $translations;
$translations['Change Status']='Alterar estado';
$translations['Result']='';
$translations['Ticket ID']='ID do Bilhete';
$translations['Ticket']='Requisição';
$translations['Bug tracker']='Projetos/Requisições';
$translations['Projects & Tickets']='Projetos & Requisições';
$translations['Testing']='';
$translations['Tickets Testing']='';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
