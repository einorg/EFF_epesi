<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage et
 */
global $translations;
$translations['Change Status']='Muuda olekut';
$translations['Result']='';
$translations['Ticket ID']='Pileti ID';
$translations['Ticket']='Pilet';
$translations['Bug tracker']='Bugijälitaja';
$translations['Projects & Tickets']='';
$translations['Testing']='';
$translations['Tickets Testing']='';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
