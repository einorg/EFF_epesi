<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_Tickets_Testing extends Module {
	private $rb;

	public function body() {
		$this->rb = $this->init_module('Utils/RecordBrowser','premium_tickets_testing','premium_tickets_testing');
		$me = CRM_ContactsCommon::get_my_record();
		$this->rb->set_defaults(array('employee'=>$me['id'], 'status'=>0));

		$sts = Utils_CommonDataCommon::get_translated_array('Premium/Ticket/Testing/Status',true);
		$trans = array('__NULL__'=>array(), '__ACTIVE__'=>array('!status'=>array(2,3)));
		foreach ($sts as $k=>$v)
			$trans[$k] = array('status'=>$k);
		$this->rb->set_custom_filter('status',array('type'=>'select','label'=>__('Status'),'args'=>array('__NULL__'=>'['.__('All').']','__ACTIVE__'=>'['.__('Active').']')+$sts,'trans'=>$trans));

		$this->rb->set_filters_defaults(array('employee'=>$this->rb->crm_perspective_default(), 'status'=>'__ACTIVE__'));
		$this->rb->set_header_properties(array(
			'employee'=>array('width'=>7)
			));
		$this->display_module($this->rb);
	}

	public function tickets_testing_addon($arg){
		$this->rb = $this->init_module('Utils/RecordBrowser','premium_tickets_testing','premium_tickets_testing');
		$me = CRM_ContactsCommon::get_my_record();
		$this->rb->set_defaults(array('ticket'=>$arg['id'], 'employee'=>$me['id'], 'status'=>0));
		$this->rb->set_header_properties(array(
			'employee'=>array('width'=>7)
			));
		$this->display_module($this->rb, array(array('ticket'=>$arg['id']), array('ticket'=>false)), 'show_data');
	}

	public function applet($conf, & $opts) {
		$opts['go'] = true;
		
		$me = CRM_ContactsCommon::get_my_record();
		
		$defaults = array('employee'=>$me['id'], 'status'=>0);
		$rb = $this->init_module('Utils/RecordBrowser','premium_tickets_testing','premium_tickets_testing');

		$crits = array('status'=>array(0, 1), 'employee'=>$me['id']);
		
		$opts['actions'][] = Utils_RecordBrowserCommon::applet_new_record_button('premium_tickets_testing',$defaults);

		$conds = array(
									array(	array('field'=>'ticket', 'width'=>40),
											array('field'=>'status', 'width'=>10)
										),
									$crits,
									array('status'=>'DESC'),
									array('Premium_Projects_Tickets_TestingCommon','applet_info_format'),
									15,
									$conf,
									& $opts
				);
		$this->display_module($rb, $conds, 'mini_view');
	}

	public function caption() {
		return __('Tickets Testing');
	}

}

?>
