<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sk
 */
global $translations;
$translations['Change Status']='Zmeniť stav';
$translations['Result']='Výsledok';
$translations['Ticket ID']='ID tiketu';
$translations['Ticket']='Tiket';
$translations['Bug tracker']='Projekty a tikety';
$translations['Projects & Tickets']='Projekty a tikety';
$translations['Testing']='Testovanie';
$translations['Tickets Testing']='Testovanie tiketu';
$translations['Testing procedure for Tickets']='Proces testovania tiketov';
$translations['Result is required when marking test as closed.']='Musíte zadať riešenie, keď sa test označuje ako uzatvorený.';
$translations['Starting Test']='Začiatok testu';
$translations['Test Complete']='Test je ukončený';
$translations['Test Canceled']='Test je zrušený';
$translations['Finished on']='Dokončené';
$translations['Tested']='Otestované';
$translations['Signed up']='Prihlásené';
$translations['Working']='Ukončené';
$translations['Additional Feedback']='Ďalšia spätná väzba';
