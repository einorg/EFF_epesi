<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Change Status']='Status ändern';
$translations['Result']='';
$translations['Ticket ID']='Ticket ID';
$translations['Ticket']='Ticket';
$translations['Bug tracker']='Projektverwaltung';
$translations['Projects & Tickets']='Projekte & Tickets';
$translations['Testing']='';
$translations['Tickets Testing']='Ticketstest';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
