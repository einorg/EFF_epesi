<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ja
 */
global $translations;
$translations['Change Status']='ステータス変更';
$translations['Result']='結果';
$translations['Ticket ID']='チケットID';
$translations['Ticket']='チケット';
$translations['Bug tracker']='バグ追跡';
$translations['Projects & Tickets']='プロジェクトとチケット';
$translations['Testing']='テスト中';
$translations['Tickets Testing']='チケットテスト';
$translations['Testing procedure for Tickets']='チケット用テスト方法';
$translations['Result is required when marking test as closed.']='テストが終了した時には成果が要求されます';
$translations['Starting Test']='テスト開始';
$translations['Test Complete']='テスト完了';
$translations['Test Canceled']='テストキャンセル';
$translations['Finished on']='終了';
$translations['Tested']='テスト済';
$translations['Signed up']='サイン済';
$translations['Working']='稼働中';
$translations['Additional Feedback']='追加のフィードバック';
