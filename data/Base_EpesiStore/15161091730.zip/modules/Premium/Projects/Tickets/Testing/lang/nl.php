<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage nl
 */
global $translations;
$translations['Change Status']='Verander status';
$translations['Result']='';
$translations['Ticket ID']='Werkbon ID';
$translations['Ticket']='Werkbon';
$translations['Bug tracker']='Foutenzoeker';
$translations['Projects & Tickets']='Projecten en werkbonnen';
$translations['Testing']='';
$translations['Tickets Testing']='Werkbon testen';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
