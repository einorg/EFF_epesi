<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage es
 */
global $translations;
$translations['Change Status']='Cambiar Estado';
$translations['Result']='Resultado';
$translations['Ticket ID']='ID de Incidencia';
$translations['Ticket']='Incidencia';
$translations['Bug tracker']='Gestión Postventa';
$translations['Projects & Tickets']='Proyectos &amp; Incidencias';
$translations['Testing']='Probando';
$translations['Tickets Testing']='Testeo de Incidencias';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='Firmado';
$translations['Working']='';
$translations['Additional Feedback']='';
