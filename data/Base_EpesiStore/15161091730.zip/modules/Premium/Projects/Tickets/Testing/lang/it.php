<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage it
 */
global $translations;
$translations['Change Status']='Cambia Stato';
$translations['Result']='Risultato';
$translations['Ticket ID']='Ticket ID';
$translations['Ticket']='Ticket';
$translations['Bug tracker']='Tracciamento difetti';
$translations['Projects & Tickets']='Progetti & Ticket';
$translations['Testing']='Test in corso';
$translations['Tickets Testing']='Controllo tickets';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='Testato';
$translations['Signed up']='Registrato';
$translations['Working']='Lavoro in corso';
$translations['Additional Feedback']='Feedback aggiuntivo';
