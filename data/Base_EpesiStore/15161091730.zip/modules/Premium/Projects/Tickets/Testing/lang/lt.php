<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage lt
 */
global $translations;
$translations['Change Status']='Pakeisti statusą';
$translations['Result']='';
$translations['Ticket ID']='Kortelės ID';
$translations['Ticket']='';
$translations['Bug tracker']='Klaidų sekimas';
$translations['Projects & Tickets']='';
$translations['Testing']='';
$translations['Tickets Testing']='';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
