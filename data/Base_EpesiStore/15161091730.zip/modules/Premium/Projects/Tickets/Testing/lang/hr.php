<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hr
 */
global $translations;
$translations['Change Status']='';
$translations['Result']='Rezultati';
$translations['Ticket ID']='';
$translations['Ticket']='';
$translations['Bug tracker']='';
$translations['Projects & Tickets']='';
$translations['Testing']='Testiranje';
$translations['Tickets Testing']='Testiranje prijave';
$translations['Testing procedure for Tickets']='Testna procedura za Prijave';
$translations['Result is required when marking test as closed.']='Rezultat je obvezan kad označavaš test završenim';
$translations['Starting Test']='Pokrećem testiranje';
$translations['Test Complete']='Testiranje izvršeno';
$translations['Test Canceled']='Testiranje prekinuto';
$translations['Finished on']='Završeno';
$translations['Tested']='Testirano';
$translations['Signed up']='pretplaćen';
$translations['Working']='Ispravno';
$translations['Additional Feedback']='Dodatne povratne informacije';
