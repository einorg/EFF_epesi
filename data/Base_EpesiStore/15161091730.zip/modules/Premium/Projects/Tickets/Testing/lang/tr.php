<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage tr
 */
global $translations;
$translations['Change Status']='Durumu Değiştir';
$translations['Result']='Sonuç';
$translations['Ticket ID']='Ticket ID';
$translations['Ticket']='Ticket';
$translations['Bug tracker']='Hata Kaydı';
$translations['Projects & Tickets']='Proje & Ticketlar';
$translations['Testing']='Test ediliyor';
$translations['Tickets Testing']='Ticket Testleri';
$translations['Testing procedure for Tickets']='Ticketlar için test prosedürü';
$translations['Result is required when marking test as closed.']='Açıklama yazılmalıdır bu işi kapatmak için';
$translations['Starting Test']='Testlere başla';
$translations['Test Complete']='Test Tamamlandı';
$translations['Test Canceled']='Test İptal edildi';
$translations['Finished on']='Bitirildi';
$translations['Tested']='Test edildi';
$translations['Signed up']='İmzlandı';
$translations['Working']='Çalışıyor';
$translations['Additional Feedback']='Geriildirim ekle';
