<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Change Status']='';
$translations['Result']='';
$translations['Ticket ID']='ID درخواست';
$translations['Ticket']='درخواست';
$translations['Bug tracker']='اشکالات';
$translations['Projects & Tickets']='پروژه ها و درخواستهای پشتیبانی';
$translations['Testing']='';
$translations['Tickets Testing']='تست درخواستهای پشتیبانی';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
