<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Change Status']='Zmień status';
$translations['Result']='Wynik';
$translations['Ticket ID']='Numer biletu';
$translations['Ticket']='Bilet';
$translations['Bug tracker']='Zarządzanie projektami';
$translations['Projects & Tickets']='Projekty i Zgloszenia';
$translations['Testing']='';
$translations['Tickets Testing']='Testowanie biletów';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='Test Zakończony';
$translations['Test Canceled']='Test Anulowany';
$translations['Finished on']='Zakończono';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
