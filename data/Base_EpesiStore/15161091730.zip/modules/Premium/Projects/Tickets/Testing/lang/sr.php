<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sr
 */
global $translations;
$translations['Change Status']='';
$translations['Result']='';
$translations['Ticket ID']='';
$translations['Ticket']='';
$translations['Bug tracker']='';
$translations['Projects & Tickets']='';
$translations['Testing']='';
$translations['Tickets Testing']='';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
