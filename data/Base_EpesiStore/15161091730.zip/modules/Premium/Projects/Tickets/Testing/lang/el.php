<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage el
 */
global $translations;
$translations['Change Status']='Αλλαγή κατάστασης';
$translations['Result']='';
$translations['Ticket ID']='ID αιτήσεων υποστήριξης';
$translations['Ticket']='Αίτηση υποστήριξης';
$translations['Bug tracker']='Bug tracker';
$translations['Projects & Tickets']='Εργασίες & Εισιτήρια';
$translations['Testing']='';
$translations['Tickets Testing']='';
$translations['Testing procedure for Tickets']='';
$translations['Result is required when marking test as closed.']='';
$translations['Starting Test']='';
$translations['Test Complete']='';
$translations['Test Canceled']='';
$translations['Finished on']='';
$translations['Tested']='';
$translations['Signed up']='';
$translations['Working']='';
$translations['Additional Feedback']='';
