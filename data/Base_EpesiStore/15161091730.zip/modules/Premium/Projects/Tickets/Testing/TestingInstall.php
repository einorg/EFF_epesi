<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_Tickets_TestingInstall extends ModuleInstall {

	public function install() {
		Base_LangCommon::install_translations($this->get_type());
		Base_ThemeCommon::install_default_theme($this->get_type());
		
		$fields = array(
			array('name' => _M('Ticket'), 			'type'=>'select','param'=>array('premium_tickets'=>'Ticket ID|Title', 'Premium_Projects_Tickets_TestingCommon'=>'tickets_crits'), 'required'=>true, 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_Tickets_TestingCommon', 'display_ticket')),
			array('name' => _M('Employee'), 			'type'=>'crm_contact', 'param'=>array('field_type'=>'select', 'crits'=>array('Premium_Projects_Tickets_TestingCommon','employee_crits')), 'filter'=>true, 'required'=>true, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Status'),				'type'=>'commondata', 'required'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium/Ticket/Testing/Status'), 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_Tickets_TestingCommon','display_status')),
			array('name' => _M('Result'),				'type'=>'commondata', 'required'=>false, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium/Ticket/Testing/Result'), 'extra'=>false, 'visible'=>true),
			array('name' => _M('Finished on'),		'type'=>'timestamp', 'extra'=>false, 'visible'=>true)
			//array('name' => _M('Notes'),				'type'=>'text', 'param'=>128, 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_Tickets_TestingCommon', 'display_notes'))
		);

		Utils_RecordBrowserCommon::install_new_recordset('premium_tickets_testing', $fields);

		Utils_RecordBrowserCommon::enable_watchdog('premium_tickets_testing', array('Premium_Projects_Tickets_TestingCommon','watchdog_label'));
		Utils_RecordBrowserCommon::set_recent('premium_tickets_testing', 15);
		Utils_RecordBrowserCommon::set_caption('premium_tickets_testing', _M('Tickets Testing'));
		Utils_RecordBrowserCommon::register_processing_callback('premium_tickets_testing', array('Premium_Projects_Tickets_TestingCommon', 'submit_testing'));

// ********* modify tickets *********** //
		Utils_RecordBrowserCommon::register_processing_callback('premium_tickets', array('Premium_Projects_Tickets_TestingCommon', 'submit_ticket'));
		Utils_RecordBrowserCommon::new_record_field('premium_tickets', 
			array('name' => _M('Tested'),	'type'=>'checkbox', 'extra'=>false, 'visible'=>false, 'position'=>'Resolution')
		);
		Utils_RecordBrowserCommon::field_deny_access('premium_tickets', 'Tested', 'edit');
		Utils_RecordBrowserCommon::field_deny_access('premium_tickets', 'Tested', 'add');

// ************ addons ************** //

		Utils_RecordBrowserCommon::new_addon('premium_tickets', 'Premium/Projects/Tickets/Testing', 'tickets_testing_addon', _M('Testing'));

// ************ other ************** //

// Common Data Arrays
		Utils_CommonDataCommon::new_array('Premium/Ticket/Testing/Status',array(_M('Signed up'),_M('Testing'),_M('Done'),_M('Canceled')), true,true);
		Utils_CommonDataCommon::new_array('Premium/Ticket/Testing/Result',array(_M('Working'),_M('Additional Feedback'),_M('Problem encountered')), true,true);

		Utils_RecordBrowserCommon::add_access('premium_tickets_testing', 'view', 'ACCESS:employee');
		Utils_RecordBrowserCommon::add_access('premium_tickets_testing', 'add', 'ACCESS:employee', array('!ticket[status]'=>6), array('finished_on'));
		Utils_RecordBrowserCommon::add_access('premium_tickets_testing', 'edit', 'ACCESS:employee', array(), array('finished_on', 'ticket'));
		Utils_RecordBrowserCommon::add_access('premium_tickets_testing', 'delete', 'ACCESS:employee', array(':Created_by'=>'USER_ID'));
		Utils_RecordBrowserCommon::add_access('premium_tickets_testing', 'delete', array('ACCESS:employee','ACCESS:manager'));

		return true;
	}
	
	public function uninstall() {

		Base_ThemeCommon::uninstall_default_theme($this->get_type());
		Utils_RecordBrowserCommon::unregister_processing_callback('premium_tickets_testing', array('Premium_Projects_Tickets_TestingCommon', 'submit_testing'));
		Utils_RecordBrowserCommon::unregister_processing_callback('premium_tickets', array('Premium_Projects_Tickets_TestingCommon', 'submit_ticket'));
		Utils_RecordBrowserCommon::uninstall_recordset('premium_tickets_testing');
		Utils_RecordBrowserCommon::delete_addon('premium_tickets', 'Premium/Projects/Tickets/Testing', 'tickets_testing_addon');

		Utils_CommonDataCommon::remove('Premium/Ticket/Testing/Status');
		Utils_CommonDataCommon::remove('Premium/Ticket/Testing/Result');

		Utils_RecordBrowserCommon::delete_record_field('premium_tickets', 'Tested');

		return true;
	}

	public function requires($v) {
		return array(
			array('name'=>'Premium/Projects/Tickets', 'version'=>0),
			array('name'=>'Utils/RecordBrowser', 'version'=>0),
			array('name'=>'Utils/Attachment', 'version'=>0),
			array('name'=>'CRM/Contacts', 'version'=>0),
			array('name'=>'CRM/Followup', 'version'=>0),
			array('name'=>'CRM/Common', 'version'=>0),
			array('name'=>'CRM/Calendar', 'version'=>0),
			array('name'=>'Base/Lang', 'version'=>0),
			array('name'=>'Base/Acl', 'version'=>0),
			array('name'=>'Utils/ChainedSelect', 'version'=>0),
			array('name'=>'Data/Countries', 'version'=>0)
		);
	}

    public static function simple_setup() {
        return array('package'=>__('Projects & Tickets'), 'option'=>__('Tickets Testing'));
    }

	public function version() {
		return array('1.0');
	}

// ************************************
	public static function info() {
		return array(
			'Description'=>'Premium Projects - Tickets tracker',
			'Author'=>'abisaga@telaxus.com',
			'License'=>'MIT');
	}
}

?>
