<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Change Status']='Změnit stav';
$translations['Result']='Výsledek';
$translations['Ticket ID']='ID problému';
$translations['Ticket']='Problém';
$translations['Bug tracker']='Projekty a Problémy';
$translations['Projects & Tickets']='Projekty a Problémy';
$translations['Testing']='Testování';
$translations['Tickets Testing']='Testování problému';
$translations['Testing procedure for Tickets']='Proces testování problémů';
$translations['Result is required when marking test as closed.']='Je požadováno řešení, když se test označuje jako uzavřeny.';
$translations['Starting Test']='Test startuje';
$translations['Test Complete']='Test je hotov';
$translations['Test Canceled']='Test zrušen';
$translations['Finished on']='Dokončeno';
$translations['Tested']='Otestováno';
$translations['Signed up']='Přihlášeno';
$translations['Working']='Pracuje se';
$translations['Additional Feedback']='Další zpětná vazba';
