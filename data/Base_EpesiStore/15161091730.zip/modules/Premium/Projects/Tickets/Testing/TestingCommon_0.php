<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_Tickets_TestingCommon extends ModuleCommon {
	
	public static function menu() {
		if (Utils_RecordBrowserCommon::get_access('premium_tickets_testing','browse'))
			return array(_M('Bug tracker')=>array('__submenu__'=>1,_M('Testing')=>array()));
		else
			return array();
	}

	public static function applet_caption() {
		if (Utils_RecordBrowserCommon::get_access('premium_tickets_testing','browse'))
			return __('Tickets Testing');
	}

	public static function applet_info() {
		return __('Testing procedure for Tickets');
	}

	public static function watchdog_label($rid = null, $events = array(), $details = true) {
		return Utils_RecordBrowserCommon::watchdog_label(
				'premium_tickets_testing',
				__('Testing'),
				$rid,
				$events,
				array('Premium_Projects_Tickets_TestingCommon','watchdog_label_format'),
				$details
			);
	}
	public static function watchdog_label_format($r) {
		return $r['ticket'];
	}
	
	public static function display_notes($record, $nolink, $desc, $status = array()) {
		
	}
	
	public static function display_status($record, $nolink, $desc, $tab, $status = array()) {
		$v = $record['status'];
		if (!$v) $v = 0;
		if (empty($status)) $status = Utils_CommonDataCommon::get_translated_array('Premium/Ticket/Testing/Status');
		if ($nolink) return $status[$v];
		$me = CRM_ContactsCommon::get_my_record();
		$leightbox_ready = & CRM_FollowupCommon::$leightbox_ready;
		$prefix = 'premium_ticket_testing_status';
		CRM_FollowupCommon::check_location();
		if (!isset($leightbox_ready[$prefix])) {
			$leightbox_ready[$prefix] = true;

			$theme = Base_ThemeCommon::init_smarty();
			eval_js_once($prefix.'_followups_deactivate = function(){leightbox_deactivate(\''.$prefix.'_followups_leightbox\');}');
	
			$error=__('Result is required when marking test as closed.');
			eval_js('check_if_'.$prefix.'_set_result = function() {not_resolved=$(\''.$prefix.'_result_select\').options[0].selected;if(not_resolved)$(\''.$prefix.'_result_required\').innerHTML=\''.$error.'\';return !not_resolved;}');
			$theme->assign('result_required_error','<div id="'.$prefix.'_result_required" class="form_error"></div>');
			$theme->assign('testing',array('open'=>'<a id="'.$prefix.'_testing" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'testing\');'.$prefix.'_submit_form();">','text'=>__( 'Starting Test'),'close'=>'</a>'));
			$theme->assign('done',array('open'=>'<a id="'.$prefix.'_feedback" onclick="if(check_if_'.$prefix.'_set_result()){'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'done\');'.$prefix.'_submit_form();}">','text'=>__( 'Test Complete'),'close'=>'</a>'));
			$theme->assign('cancel',array('open'=>'<a id="'.$prefix.'_error" onclick="'.$prefix.'_followups_deactivate();'.$prefix.'_set_action(\'cancel\');'.$prefix.'_submit_form();">','text'=>__( 'Test Canceled'),'close'=>'</a>'));

			eval_js($prefix.'_submit_form = function () {'.
						'$(\''.$prefix.'_follow_up_form\').submited.value=1;Epesi.href($(\''.$prefix.'_follow_up_form\').serialize(), \'processing...\');$(\''.$prefix.'_follow_up_form\').submited.value=0;'.
					'}');
			eval_js($prefix.'_set_action = function (arg) {'.
						'document.forms["'.$prefix.'_follow_up_form"].action.value = arg;'.
					'}');
			eval_js($prefix.'_set_id = function (id) {'.
						'document.forms["'.$prefix.'_follow_up_form"].id.value = id;'.
						'document.forms["'.$prefix.'_follow_up_form"].note.value = "";'.
						'document.forms["'.$prefix.'_follow_up_form"].result.selectedIndex = 0;'.
					'}');
			$theme->assign('form_open','<form id="'.$prefix.'_follow_up_form" name="'.$prefix.'_follow_up_form" method="POST">'.
							'<input type="hidden" name="submited" value="0" />'.
							'<input type="hidden" name="form_name" value="'.$prefix.'_follow_up_form" />'.
							'<input type="hidden" name="id" value="" />'.
							'<input type="hidden" name="action" value="" />');
			$theme->assign('form_note',	array('label'=>__('Note'), 'html'=>'<textarea name="note" value=""></textarea>'));
			$result_html = '<select name="result" value="0" id="'.$prefix.'_result_select">';
			$result_html .= '<option value="">---</option>';
			$ress = Utils_CommonDataCommon::get_translated_array('Premium/Ticket/Testing/Result', true);
			foreach ($ress as $k=>$w)
				$result_html .= '<option value="'.$k.'">'.$w.'</option>';
			$result_html .= '</select>';
			$theme->assign('form_result', array('label'=>__('Result'), 'html'=>$result_html));
			$theme->assign('form_close','</form>');
			ob_start();
			Base_ThemeCommon::display_smarty($theme,'Premium_Projects_Tickets_Testing','status_leightbox');
			$profiles_out = ob_get_clean();

			Libs_LeightboxCommon::display($prefix.'_followups_leightbox',$profiles_out,__( 'Change Status'),1);
		}
		$acc = Utils_RecordBrowserCommon::get_access('premium_tickets_testing','edit', $record);
		if (is_array($acc)) {
			if (isset($acc['status']))
				$acc = $acc['status'];
			else
				$acc = true;
		}
		if ($me['id']!=$record['employee']) return $status[$v];
		$v = $record['status'];
		if ($v>=2) return $status[$v];
		if (isset($_REQUEST['form_name']) && $_REQUEST['form_name']==$prefix.'_follow_up_form' && $_REQUEST['id']==$record['id']) {
			unset($_REQUEST['form_name']);
			$note = $_REQUEST['note'];
			$result = $_REQUEST['result'];
			$action  = $_REQUEST['action'];
			switch ($action) {
				case 'testing': $v=1;
								$result = '';
								break;
				case 'done': 	$v=2;
								break;
				case 'cancel': 	$v=3; 
								$result = '';
								break;
			}
			if ($note) {
				if (get_magic_quotes_gpc())
					$note = stripslashes($note);
				$note = str_replace("\n",'<br />',$note);
				Utils_AttachmentCommon::add('premium_tickets/'.$record['ticket'],0,Acl::get_user(),$note);
			}
			Utils_RecordBrowserCommon::update_record('premium_tickets_testing', $record['id'], array('status'=>$v,'result'=>$result));
			location(array());
		}
		return '<a href="javascript:void(0)" class="lbOn" rel="'.$prefix.'_followups_leightbox" onMouseDown="'.$prefix.'_set_id('.$record['id'].');">'.$status[$v].'</a>';
	}

	public static function display_ticket($v, $nolink) {
		$r = Utils_RecordBrowserCommon::get_record('premium_tickets', $v['ticket']);
		return Utils_RecordBrowserCommon::record_link_open_tag('premium_tickets', $v['ticket']).$r['ticket_id'].': '.$r['title'].Utils_RecordBrowserCommon::record_link_close_tag();
	}
	
	public static function tickets_crits() {
		return array('!status'=>6);
	}

	public static function employee_crits(){
		return array('(company_name'=>CRM_ContactsCommon::get_main_company(),'|related_companies'=>array(CRM_ContactsCommon::get_main_company()));
	}
	
	public static function applet_info_format($r){
		$args=array(
					__('Ticket ID') => '<b>'.$r['ticket'].'</b>',
					__('Employee') => CRM_ContactsCommon::display_contact(array('id'=>$r['employee']),true,array('id'=>'id', 'param'=>'::;CRM_ContactsCommon::contact_format_no_company'))
					);

		$ret = array('notes'=>Utils_TooltipCommon::format_info_tooltip($args));
		return $ret;
	}
	
	public static function submit_ticket($values, $mode) {
		switch ($mode) {
		case 'edit':
			if ($values['status']<4 && $values['tested']==1)
				Utils_RecordBrowserCommon::update_record('premium_tickets',$values['id'],array('tested'=>0));
			if ($values['status']==6) {
				$recs = Utils_RecordBrowserCommon::get_records('premium_tickets_testing',array('ticket'=>$values['id']));
				foreach ($recs as $r) {
					if ($r['status']==0)
						Utils_RecordBrowserCommon::update_record('premium_tickets_testing',$r['id'],array('status'=>3));
				}
			}
		}
		return $values;
	}

	public static function submit_testing($values, $mode) {
		switch ($mode) {
			case 'edit': 
				$r = Utils_RecordBrowserCommon::get_record('premium_tickets',$values['ticket']);
				if ($values['status']==2) {
					if ($values['result']==0) // All OK
						Utils_RecordBrowserCommon::update_record('premium_tickets',$values['ticket'],array('tested'=>1));
					if ($values['result']==2 && $r['status']==4) // Problem
						Utils_RecordBrowserCommon::update_record('premium_tickets',$values['ticket'],array('status'=>1));
					Utils_RecordBrowserCommon::update_record('premium_tickets_testing',$values['id'],array('finished_on'=>date('Y-m-d H:i:s')));
				}
		}
		return $values;
	}
	
	public static function applet_settings() {
		return Utils_RecordBrowserCommon::applet_settings(array());
	}
}

?>