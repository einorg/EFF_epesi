<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sl
 */
global $translations;
$translations['Change Status']='Spremeni status';
$translations['Result']='Rezultat';
$translations['Ticket ID']='ID Zadolžitve';
$translations['Ticket']='Zadolžitev';
$translations['Bug tracker']='Projekti in zadolžitve';
$translations['Projects & Tickets']='Projekti in zadolžitve';
$translations['Testing']='Sledenje';
$translations['Tickets Testing']='Sledenje zadolžitve';
$translations['Testing procedure for Tickets']='Procedura sledenja za zadolžitve';
$translations['Result is required when marking test as closed.']='Zahteva se sklep, če je sledenje označeno kot zaprto.';
$translations['Starting Test']='Začetek sledenja';
$translations['Test Complete']='Sledenje zaključeno';
$translations['Test Canceled']='Sledenje preklicano';
$translations['Finished on']='Končano';
$translations['Tested']='Sleden';
$translations['Signed up']='Podpisano';
$translations['Working']='V delu';
$translations['Additional Feedback']='Dodatna povratna informacija';
