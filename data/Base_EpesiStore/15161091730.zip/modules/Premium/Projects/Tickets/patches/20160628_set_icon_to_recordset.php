<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::set_icon('premium_tickets', Base_ThemeCommon::get_template_filename(Premium_Projects_TicketsInstall::module_name(), 'icon.png'));
