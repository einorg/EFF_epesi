<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_CommonDataCommon::extend_array('Contacts_Groups',array('developer'=>_M('Developer')));

?>

