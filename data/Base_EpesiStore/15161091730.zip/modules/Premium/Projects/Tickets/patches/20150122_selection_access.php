<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::add_access('premium_tickets', 'selection', 'ACCESS:employee',array('!status'=>4,'_!status'=>6));
