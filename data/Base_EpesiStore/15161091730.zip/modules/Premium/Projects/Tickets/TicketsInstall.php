<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_TicketsInstall extends ModuleInstall {
    const version = '1.7.1';

	public function install() {
		Base_LangCommon::install_translations($this->get_type());

		Base_ThemeCommon::install_default_theme($this->get_type());
		$fields = array(
			array('name' => _M('Ticket ID'), 			'type'=>'calculated', 'required'=>false, 'param'=>Utils_RecordBrowserCommon::actual_db_type('text',16), 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_TicketsCommon','display_ticket_id')),
			array('name' => _M('Title'), 				'type'=>'text', 'required'=>true, 'param'=>'255', 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_TicketsCommon','display_title')),
			array('name' => _M('Project Name'), 		'type'=>'select','param'=>array('premium_projects'=>'Project Name', 'Premium_Projects_TicketsCommon'=>'projects_crits'), 'required'=>true, 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_TicketsCommon', 'proj_name_callback')),
			array('name' => _M('Ticket Owner'), 		'type'=>'crm_contact', 'param'=>array('field_type'=>'select', 'crits'=>array('Premium_Projects_TicketsCommon','users_crits'),'format'=>array('CRM_ContactsCommon','contact_format_no_company')), 'display_callback'=>array('Premium_Projects_TicketsCommon','display_assigned_contacts'), 'filter'=>true, 'required'=>true, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Type'),				'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium_Ticket_Type'), 'extra'=>false, 'visible'=>true),
			array('name' => _M('Date'),				'type'=>'date', 'extra'=>false, 'visible'=>true),
			array('name' => _M('Priority'), 			'type'=>'commondata', 'required'=>true, 'visible'=>true, 'param'=>array('order_by_key'=>true,'Premium_Ticket_Priorities'), 'extra'=>false, 'filter'=>true),
			array('name' => _M('Status'),				'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium_Ticket_Status'), 'extra'=>false, 'visible'=>true, 'display_callback'=>array('Premium_Projects_TicketsCommon','display_status')),
			array('name' => _M('Assigned To'), 		'type'=>'crm_contact', 'param'=>array('field_type'=>'multiselect', 'crits'=>array('Premium_Projects_TicketsCommon','employees_crits'),'format'=>array('Premium_Projects_TicketsCommon','assigned_to_format')), 'display_callback'=>array('Premium_Projects_TicketsCommon','display_assigned_contacts'), 'filter'=>true, 'required'=>false, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Permission'), 		'type'=>'commondata', 'required'=>true, 'param'=>array('order_by_key'=>true,'CRM/Access'), 'extra'=>false),
			array('name' => _M('Resolution'),			'type'=>'commondata', 'required'=>false, 'visible'=>false, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium_Ticket_Resolution'), 'extra'=>false, 'visible'=>true),
			array('name' => _M('Due Date'),			'type'=>'date', 'extra'=>false, 'visible'=>true),
			array('name' => _M('Required tickets'), 	'type'=>'multiselect', 'param'=>'premium_tickets::Ticket ID|Title;Premium_Projects_TicketsCommon::required_tickets_crits;Premium_Projects_TicketsCommon::adv_required_tickets_params', 'display_callback'=>array('Premium_Projects_TicketsCommon','display_required_tickets'), 'required'=>false, 'extra'=>false, 'visible'=>true),
			array('name' => _M('Description'), 		'type'=>'long text', 'extra'=>false, 'param'=>'255', 'required'=>false, 'visible'=>false)	
		);


		Utils_RecordBrowserCommon::install_new_recordset('premium_tickets', $fields);

		Utils_RecordBrowserCommon::new_filter('premium_tickets', 'Project Name');
		Utils_RecordBrowserCommon::enable_watchdog('premium_tickets', array('Premium_Projects_TicketsCommon','watchdog_label'));
		Utils_RecordBrowserCommon::set_quickjump('premium_tickets', 'Title');
		Utils_RecordBrowserCommon::set_favorites('premium_tickets', true);
		Utils_RecordBrowserCommon::set_icon('premium_tickets', Base_ThemeCommon::get_template_filename(Premium_Projects_TicketsInstall::module_name(), 'icon.png'));
		Utils_RecordBrowserCommon::set_recent('premium_tickets', 15);
		Utils_RecordBrowserCommon::set_caption('premium_tickets', _M('Tickets'));
		Utils_RecordBrowserCommon::register_processing_callback('premium_tickets', array('Premium_Projects_TicketsCommon', 'submit_ticket'));
        Utils_CommonDataCommon::extend_array('Contacts_Groups',array('developer'=>_M('Developer')));
        Utils_RecordBrowserCommon::set_search('premium_tickets',2,0);

// ************ addons ************** //
//	Parameters: ('table','ModuleLocation','function','Label');
		Utils_RecordBrowserCommon::new_addon('premium_tickets', 'Premium/Projects/Tickets', 'premium_tickets_attachment_addon', _M('Notes'));
		Utils_RecordBrowserCommon::new_addon('premium_projects', 'Premium/Projects/Tickets', 'premium_projects_tickets_addon', _M('Tickets'));

// ************ other ************** //
		Utils_BBCodeCommon::new_bbcode('ticket', 'Premium_Projects_TicketsCommon', 'ticket_bbcode');

// Common Data Arrays
		Utils_CommonDataCommon::new_array('Premium_Ticket_Status',array(_M('New'),_M('Open'),_M('In Progress'),_M('On Hold'),_M('Resolved'),_M('Awaiting Feedback'),_M('Closed')), true,true);
		Utils_CommonDataCommon::new_array('Premium_Ticket_Priorities',array(_M('Critical'),_M('Major'),_M('Minor'),_M('Trivial')), true,true);
		Utils_CommonDataCommon::new_array('Premium_Ticket_Resolution',array(_M('Fixed'),_M('Invalid'),_M('Duplicate'),_M('Will Not Fix'),_M('Works For Me')), true,true);
		Utils_CommonDataCommon::new_array('Premium_Ticket_Type',array(_M('Bug'),_M('Feature Request')), true,true);

		CRM_CalendarCommon::new_event_handler(_M('Tickets'), array('Premium_Projects_TicketsCommon', 'crm_calendar_handler'));

		Utils_RecordBrowserCommon::add_access('premium_tickets', 'view', 'ACCESS:employee', array('(!permission'=>2, '|assigned_to'=>'USER', '|ticket_owner'=>'USER'));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'selection', 'ACCESS:employee',array('!status'=>4,'_!status'=>6));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'add', 'ACCESS:employee');
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'edit', 'ACCESS:employee', array('ticket_owner'=>'USER'));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'edit', 'ACCESS:employee', array('assigned_to'=>'USER'), array('ticket_owner', 'status'));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'edit', 'ACCESS:employee', array('status'=>0, 'permission'=>0), array('ticket_owner', 'status'));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'edit', array('ACCESS:employee','ACCESS:manager'), array('(permission'=>0,'|assigned_to'=>'USER'));
		Utils_RecordBrowserCommon::add_access('premium_tickets', 'delete', 'ACCESS:employee', array('ticket_owner'=>'USER'));

	return true;
	}
	
	public function uninstall() {
		CRM_CalendarCommon::delete_event_handler('Tickets');

		Base_ThemeCommon::uninstall_default_theme($this->get_type());
		Utils_RecordBrowserCommon::unregister_processing_callback('premium_tickets', array('Premium_Projects_TicketsCommon', 'submit_ticket'));
		Utils_RecordBrowserCommon::uninstall_recordset('premium_tickets');
		Utils_CommonDataCommon::remove('Premium_Ticket_Status');
		Utils_CommonDataCommon::remove('Premium_Ticket_Priorities');
		Utils_CommonDataCommon::remove('Premium_Ticket_Resolution');
		Utils_CommonDataCommon::remove('Premium_Ticket_Type');
		return true;
	}

	public function requires($v) {
		return array(
			array('name'=>'Premium/Projects', 'version'=>0),
			array('name'=>'Utils/RecordBrowser', 'version'=>0),
			array('name'=>'Utils/Attachment', 'version'=>0),
			array('name'=>'CRM/Contacts', 'version'=>0),
			array('name'=>'CRM/Followup', 'version'=>0),
			array('name'=>'CRM/Common', 'version'=>0),
			array('name'=>'CRM/Calendar', 'version'=>0),
			array('name'=>'Base/Lang', 'version'=>0),
			array('name'=>'Base/Acl', 'version'=>0),
			array('name'=>'Utils/ChainedSelect', 'version'=>0),
			array('name'=>'Data/Countries', 'version'=>0),
			array('name'=>'Utils/Tray', 'version'=>0)
		);
	}

	public static function simple_setup() {
        return array('package'=>__('Projects & Tickets'));
	}

	public function version() {
		return array(self::version);
	}

// ************************************
	public static function info() {
		return array(
			'Description'=>'Premium Projects - Tickets tracker',
			'Author'=>'abisaga@telaxus.com',
			'License'=>'MIT');
	}
}

?>
