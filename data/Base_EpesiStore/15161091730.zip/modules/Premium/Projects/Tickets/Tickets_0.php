<?php
/**
 *
 * @author Arkadiusz Bisaga <abisaga@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects-tickets
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects_Tickets extends Module {
	private $rb;

	public function body() {
		$this->rb = $this->init_module('Utils/RecordBrowser','premium_tickets','premium_tickets');
		$me = CRM_ContactsCommon::get_my_record();
		$this->rb->set_defaults(array('ticket_owner'=>$me['id'], 'assigned_to'=>$me['id'], 'date'=>date('Y-m-d'), 'status'=>0, 'permission'=>0));

		$sts = Utils_CommonDataCommon::get_translated_array('Premium_Ticket_Status',true);
		$trans = array('__NULL__'=>array(), '__NO_CLOSED__'=>array('!status'=>6), '__ALLACTIVE__'=>Premium_Projects_TicketsCommon::active_tickets_crits());
		foreach ($sts as $k=>$v)
			$trans[$k] = array('status'=>$k);
		$this->rb->set_custom_filter('status',array('type'=>'select','label'=>__('Ticket status'),'args'=>array('__NULL__'=>'['.__('All').']','__ALLACTIVE__'=>'['.__('All active').']','__NO_CLOSED__'=>'['.__('Not closed').']')+$sts,'trans'=>$trans));

		$recs = Utils_RecordBrowserCommon::get_records('premium_projects', array('!status'=>array(2,4)));
		$vals = array('__NULL__'=>'---');
		$trans = array('__NULL__'=>array());
		foreach ($recs as $k=>$v) {
			$vals[$v['id']] = $v['project_name'];
			$trans[$v['id']] = array('project_name'=>$v['id']);
		}
		$this->rb->set_custom_filter('project_name',array('type'=>'select','label'=>__('Project Name'),'args'=>$vals,'trans'=>$trans));

		$this->rb->set_filters_defaults(array('assigned_to'=>$this->rb->crm_perspective_default(), 'status'=>'__NO_CLOSED__'));
		$this->rb->set_default_order(array('status'=>'ASC', 'priority'=>'ASC'));
		$this->rb->set_header_properties(array(
			'ticket_id'=>array('width'=>5),
			'priority'=>array('width'=>5,'wrapmode'=>'nowrap'),
			'title'=>array('width'=>15,'wrapmode'=>'nowrap'),
			'project_name'=>array('name'=>'Project','width'=>5,'wrapmode'=>'nowrap'),
			'ticket_owner'=>array('width'=>5,'wrapmode'=>'nowrap'),
			'assigned_to'=>array('width'=>5, 'wrapmode'=>'nowrap'),
			'status'=>array('width'=>5, 'wrapmode'=>'nowrap'),
			'type'=>array('width'=>5, 'wrapmode'=>'nowrap'),
			'resolution'=>array('width'=>5, 'wrapmode'=>'nowrap'),
			'required_tickets'=>array('name'=>__('Required'),'width'=>5, 'wrapmode'=>'nowrap')
			));
        $this->tray = $this->init_module('Utils/Tray');
        $this->tray->set_filters($this->rb, false);
        $this->display_module($this->rb);
	}

	public function premium_tickets_attachment_addon($arg){
		$a = $this->init_module('Utils/Attachment',array('premium_tickets/'.$arg['id']));
		$a->set_view_func(array('Premium_Projects_TicketsCommon','search_format'),array($arg['id']));
		$a->enable_watchdog('premium_tickets',$arg['id']);
		$this->display_module($a);
	}

	public function premium_projects_tickets_addon($arg){
		$rb = $this->init_module('Utils/RecordBrowser','premium_tickets');
		$ticket = array(array('project_name'=>$arg['id']), array('project_name'=>false,'due_date'=>false,'required_tickets'=>false), array('status'=>'ASC','ticket_id'=>'DESC'));

		$rb->set_header_properties(array('ticket_id'=>array('name'=>__('Ticket'),'width'=>10)),array('title'=>array('width'=>10)),array('assigned_to'=>array('name'=>__('Assigned'),'width'=>10)));

		$me = CRM_ContactsCommon::get_my_record();
		$rb->set_defaults(array('project_name'=>$arg['id'],'assigned_to'=>$me['id'], 'ticket_owner'=>$me['id'], 'date'=>date('Y-m-d'), 'status'=>0, 'permission'=>0));
		$this->display_module($rb,$ticket,'show_data');
	}
	
	public function applet($conf, & $opts) {
		$opts['go'] = true;
		$opts['title'] = $conf['title'];
		$emp = $conf['employee'];
		if (!$emp) {
			CRM_ContactsCommon::no_contact_message();
			return;
		}
		$defaults = array('ticket_owner'=>$emp, 'date'=>date('Y-m-d'), 'status'=>0, 'permission'=>0);
		$rb = $this->init_module('Utils/RecordBrowser','premium_tickets','premium_tickets');

		/********* SEARCH BY ID *************/
		static $id=0;
		$id++;
		print('<div id="tickets_applet_'.$id.'" style="display:none;">');
		$ret = $rb->search_by_id_form(__('Ticket ID'));
		print('</div>');
		if ($ret) eval_js('document.getElementById(\'tickets_applet_'.$id.'\').style.display=\'block\';');
		$opts['actions'][] = '<a onclick="if(document.getElementById(\'tickets_applet_'.$id.'\').style.display==\'none\')set_style=\'block\';else set_style=\'none\';document.getElementById(\'tickets_applet_'.$id.'\').style.display=set_style" href="javascript:void(0)" '.Utils_TooltipCommon::open_tag_attrs(__('Search by ticket ID')).'><img src="'.Base_ThemeCommon::get_template_file('Premium_Projects_Tickets','search.png').'" border="0"></a>';
		/********* SEARCH BY ID *************/

		$crits = array();
        $order = array('priority'=>'ASC','due_date'=>'ASC');
		
		switch ($conf['applet_type']) {
			case 'active': $crits = array('assigned_to'=>$emp, 'status'=>array(1,2,3)); break;
			case 'unassigned': $crits = array('assigned_to'=>'', '!status'=>6); break;
			case 'all_assigned': $crits = array('assigned_to'=>$emp, '!status'=>6); break;
			case 'all_owned': $crits = array('ticket_owner'=>$emp, '!status'=>6); break;
			case 'all_new': $crits = array('assigned_to'=>$emp, 'status'=>0); break;
			case 'favs': $crits = array(':Fav'=>true); break;
            case 'recent': $crits = array('assigned_to'=>$emp, ':Recent' => true);
                           $order = array(':Visited_on' => 'DESC');
                break;
			case 'to_test': 
				$rb->set_additional_actions_method(array($this, 'actions_test'));
				$crits = array('ticket_owner'=>$emp, 'tested'=>array('',0), 'status'=>4);
				break;
			case 'review': 
				if (Premium_Projects_TicketsCommon::testing_enabled())
					$crits = array('ticket_owner'=>$emp, 'status'=>array(4,5), '(tested'=>1, '|status'=>5);
				else
					$crits = array('ticket_owner'=>$emp, 'status'=>array(4,5));
				break;
		}

		if ($conf['tickets_type']!='') $crits['type'] = $conf['tickets_type'];
		
		$opts['actions'][] = Utils_RecordBrowserCommon::applet_new_record_button('premium_tickets',$defaults);

		$conds = array(
									array(	array('field'=>'title', 'width'=>40),
											array('field'=>'status', 'width'=>10, 'callback'=>array('Premium_Projects_TicketsCommon','display_status_applet'))
										),
									$crits,
									$order,
									array('Premium_Projects_TicketsCommon','applet_info_format'),
									15,
									$conf,
									& $opts
				);
		$this->display_module($rb, $conds, 'mini_view');
	}
	
	public function actions_test($r, $gb_row) {
		$gb_row->add_action($this->create_callback_href(array($this, 'add_test'), array($r['id'])), 'Add to pending tests', null, Base_ThemeCommon::get_template_file('Premium_Projects_Tickets_Testing','add_test.png'));
	}
	
	public function add_test($t_id) {
		$me = CRM_ContactsCommon::get_my_record();
		Utils_RecordBrowserCommon::new_record('premium_tickets_testing', array('status'=>0, 'employee'=>$me['id'], 'ticket'=>$t_id));
		location(array());
		return false;
	}

	public function caption() {
		return __('Tickets');
	}

}

?>
