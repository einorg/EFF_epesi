<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage nl
 */
global $translations;
$translations['Completed']='Afgerond';
$translations['Approved']='Goedgekeurd';
$translations['Projects']='Projecten';
$translations['Contact as customer']='Klant als contact';
$translations['Contact as project manager']='Project manager als contact';
$translations['Contact as employee']='Monteur als contact';
$translations['Due Date']='Deadline';
$translations['Project Name']='Projectnaam';
$translations['All Projects']='Alle projecten';
$translations['Display projects with status']='Laat alle projecten zien';
$translations['Projects status']='Projectenstatus';
$translations['Project Manager']='Projectleider';
$translations['Bug tracker']='Foutenzoeker';
$translations['Projects List']='Project lijst';
$translations['Display only my projects']='Laat mijn projecten zien';
$translations['Project (attachment) #%d, %s']='Project (bijlage) #%d, %s';
$translations['Planned']='Gepland';
$translations['Projects & Tickets']='Projecten en werkbonnen';
$translations['Active projects']='Actieve projecten';
$translations['Projects: %s']='Projecten: %s';
