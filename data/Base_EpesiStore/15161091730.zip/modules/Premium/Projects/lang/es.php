<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage es
 */
global $translations;
$translations['Completed']='Ya Completado';
$translations['Approved']='Aún no iniciado';
$translations['Projects']='Proyectos';
$translations['Contact as customer']='Contactar como Cliente';
$translations['Contact as project manager']='Contacto Responsable de Proyecto';
$translations['Contact as employee']='Contacto como Empleado';
$translations['Due Date']='Fecha Vencimiento';
$translations['Project Name']='Nombre del Proyecto';
$translations['All Projects']='Todos los Proyectos';
$translations['Display projects with status']='Mostrar proyectos con estatus';
$translations['Projects status']='Estado del Proyecto';
$translations['Project Manager']='Gestor del Proyecto';
$translations['Bug tracker']='Gestión Postventa';
$translations['Projects List']='Listado de Proyectos';
$translations['Display only my projects']='Mostrar solo mis proyectos';
$translations['Project (attachment) #%d, %s']='Proyecto (adjunto) #%s, %s';
$translations['Planned']='En Planificación';
$translations['Projects & Tickets']='Proyectos &amp; Incidencias';
$translations['Active projects']='Proyectos Activos';
$translations['Projects: %s']='Proyectos: %s';
