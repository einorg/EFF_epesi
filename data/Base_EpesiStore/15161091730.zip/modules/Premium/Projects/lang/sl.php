<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sl
 */
global $translations;
$translations['Completed']='Končan/Izveden';
$translations['Approved']='Potrjen';
$translations['Projects']='Projekti';
$translations['Contact as customer']='Stik kot stranka';
$translations['Contact as project manager']='Stik kot vodja projekta';
$translations['Contact as employee']='Stik kot referent';
$translations['Due Date']='Rok';
$translations['Project Name']='Št. in kratek opis projekta';
$translations['All Projects']='Vsi Projekti';
$translations['Display projects with status']='Pokaži projekte z statusom';
$translations['Projects status']='Statusi projektov';
$translations['Project Manager']='Vodja projekta';
$translations['Bug tracker']='Projekti in zadolžitve';
$translations['Projects List']='Seznam Projektov';
$translations['Display only my projects']='Pokaži samo moje projekte';
$translations['Project (attachment) #%d, %s']='Projekt (priloga) #%d, %s';
$translations['Planned']='Planiran';
$translations['Projects & Tickets']='Projekti in zadolžitve';
$translations['Active projects']='Aktivni projekti';
$translations['Projects: %s']='Projekti: %s';
