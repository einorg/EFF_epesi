<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage tr
 */
global $translations;
$translations['Completed']='Bitti';
$translations['Approved']='İzinli';
$translations['Projects']='Projeler';
$translations['Contact as customer']='Müşteriye Ulaş';
$translations['Contact as project manager']='Proje Yöneticisine Ulaş';
$translations['Contact as employee']='Çalışanlara Ulaş';
$translations['Due Date']='Tarih';
$translations['Project Name']='Proje adı';
$translations['All Projects']='Tüm Projeler';
$translations['Display projects with status']='Projeleri Durumuna göre görüntüle';
$translations['Projects status']='Proje durumu';
$translations['Project Manager']='Proje Yöneticisi';
$translations['Bug tracker']='Hata Kaydı';
$translations['Projects List']='Proje Listesi';
$translations['Display only my projects']='Sadece benim projelerimi görüntüle';
$translations['Project (attachment) #%d, %s']='Proje(Eki) #%d, %s';
$translations['Planned']='Planlı';
$translations['Projects & Tickets']='Proje & Ticketlar';
$translations['Active projects']='Aktif Projeler';
$translations['Projects: %s']='Projeler: %s';
