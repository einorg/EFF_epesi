<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage de
 */
global $translations;
$translations['Completed']='Erledigt';
$translations['Approved']='Bewilligt';
$translations['Projects']='Projekte';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='Als Mitarbeiter kontaktieren';
$translations['Due Date']='Fällig am';
$translations['Project Name']='Projektname';
$translations['All Projects']='Alle Projekte';
$translations['Display projects with status']='Anzeige von Projekten mit Status ';
$translations['Projects status']='Projektstatus';
$translations['Project Manager']='Projektverantwortlicher';
$translations['Bug tracker']='Projektverwaltung';
$translations['Projects List']='Projektliste';
$translations['Display only my projects']='Nur meine Projekte anzeigen';
$translations['Project (attachment) #%d, %s']='Projekt (Anhang) #%d, %s';
$translations['Planned']='Geplant';
$translations['Projects & Tickets']='Projekte & Tickets';
$translations['Active projects']='Aktive Projekte';
$translations['Projects: %s']='Projekte: %s';
