<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sv
 */
global $translations;
$translations['Completed']='Avslutade';
$translations['Approved']='Godkänd';
$translations['Projects']='Projekt';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='Förfallodatum';
$translations['Project Name']='Projektnamn';
$translations['All Projects']='';
$translations['Display projects with status']='Visa projekt med status';
$translations['Projects status']='Projektstatus';
$translations['Project Manager']='Projektledare';
$translations['Bug tracker']='Bug tracker';
$translations['Projects List']='';
$translations['Display only my projects']='Visa endast mina projekt';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planerade';
$translations['Projects & Tickets']='';
$translations['Active projects']='';
$translations['Projects: %s']='Projekt: %s';
