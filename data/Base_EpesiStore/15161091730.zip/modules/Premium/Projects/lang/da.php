<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage da
 */
global $translations;
$translations['Completed']='Færdig';
$translations['Approved']='Godkendt';
$translations['Projects']='Projekter';
$translations['Contact as customer']='Kontakt som kunde';
$translations['Contact as project manager']='Kontakt som projekt manager';
$translations['Contact as employee']='Kontakt som medarbejder';
$translations['Due Date']='Sidste dato';
$translations['Project Name']='Projekt navn';
$translations['All Projects']='Alle Projekter';
$translations['Display projects with status']='';
$translations['Projects status']='Projekter status';
$translations['Project Manager']='Projekt manager';
$translations['Bug tracker']='Fejl tracker';
$translations['Projects List']='Projekt liste';
$translations['Display only my projects']='Vis kun mine projekter';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planlagt';
$translations['Projects & Tickets']='Projekter & Billetter';
$translations['Active projects']='Aktive projekter';
$translations['Projects: %s']='Projekter: %s';
