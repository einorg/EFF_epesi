<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pl
 */
global $translations;
$translations['Completed']='Ukończone';
$translations['Approved']='Zatwierdzony';
$translations['Projects']='Projekty';
$translations['Contact as customer']='Kontakt z klientem';
$translations['Contact as project manager']='Skontaktuj się jako menadżer projektu';
$translations['Contact as employee']='Kontaktuj się jako pracownik';
$translations['Due Date']='Termin';
$translations['Project Name']='Nazwa projektu';
$translations['All Projects']='Wszystkie Projekty';
$translations['Display projects with status']='Wyświetl projekty o statusie';
$translations['Projects status']='Status projektów';
$translations['Project Manager']='Zarządzający Projektem';
$translations['Bug tracker']='Zarządzanie projektami';
$translations['Projects List']='Lista projektów';
$translations['Display only my projects']='Wyświetl tylko moje projekty';
$translations['Project (attachment) #%d, %s']='Projekt (załącznik) #%d, %s';
$translations['Planned']='Zaplanowany';
$translations['Projects & Tickets']='Projekty i Zgloszenia';
$translations['Active projects']='Aktywne projekty';
$translations['Projects: %s']='Projekty: %s';
