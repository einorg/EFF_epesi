<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ja
 */
global $translations;
$translations['Completed']='完了';
$translations['Approved']='承認済';
$translations['Projects']='プロジェクト';
$translations['Contact as customer']='顧客としての個人';
$translations['Contact as project manager']='プロジェクトマネージャーとしての個人';
$translations['Contact as employee']='従業員としての個人';
$translations['Due Date']='期日';
$translations['Project Name']='プロジェクト名';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='プロジェクトステータス';
$translations['Project Manager']='プロジェクトマネージャー';
$translations['Bug tracker']='バグ追跡';
$translations['Projects List']='プロジェクトリスト';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='計画済';
$translations['Projects & Tickets']='プロジェクトとチケット';
$translations['Active projects']='';
$translations['Projects: %s']='';
