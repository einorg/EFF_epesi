<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage zh
 */
global $translations;
$translations['Completed']='完成';
$translations['Approved']='核准';
$translations['Projects']='项目';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='';
$translations['Project Name']='工程名';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='';
$translations['Project Manager']='项目经理';
$translations['Bug tracker']='问题跟踪';
$translations['Projects List']='';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='计划着';
$translations['Projects & Tickets']='';
$translations['Active projects']='';
$translations['Projects: %s']='';
