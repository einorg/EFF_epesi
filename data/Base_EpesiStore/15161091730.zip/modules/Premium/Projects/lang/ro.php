<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ro
 */
global $translations;
$translations['Completed']='Finalizate';
$translations['Approved']='Aprobat';
$translations['Projects']='Proiecte';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='';
$translations['Project Name']='Nume proiect';
$translations['All Projects']='';
$translations['Display projects with status']='Afiseaza proiecte cu statut';
$translations['Projects status']='Starea proiectelor';
$translations['Project Manager']='manager proiect';
$translations['Bug tracker']='Probleme';
$translations['Projects List']='';
$translations['Display only my projects']='Afiseaza doar proiectele mele';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planificat';
$translations['Projects & Tickets']='';
$translations['Active projects']='';
$translations['Projects: %s']='Proiecte: %s';
