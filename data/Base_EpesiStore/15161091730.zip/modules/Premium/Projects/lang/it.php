<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage it
 */
global $translations;
$translations['Completed']='Completato';
$translations['Approved']='Approvato';
$translations['Projects']='Progetti';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='Scadenza';
$translations['Project Name']='Nome progetto';
$translations['All Projects']='Tutti i progetti';
$translations['Display projects with status']='Visualizza progetti con stato';
$translations['Projects status']='Stato progetto';
$translations['Project Manager']='Organizzatore progetto';
$translations['Bug tracker']='Tracciamento difetti';
$translations['Projects List']='';
$translations['Display only my projects']='Visualizza solo i miei progetti';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Pianificato';
$translations['Projects & Tickets']='Progetti & Ticket';
$translations['Active projects']='Progetti attivi';
$translations['Projects: %s']='Progetti: %s';
