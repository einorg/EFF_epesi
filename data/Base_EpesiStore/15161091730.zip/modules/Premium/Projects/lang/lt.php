<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage lt
 */
global $translations;
$translations['Completed']='Užbaigtas';
$translations['Approved']='Patvirtinta';
$translations['Projects']='Projektai';
$translations['Contact as customer']='';
$translations['Contact as project manager']='Susisiekti kaip su projekto vadovu';
$translations['Contact as employee']='';
$translations['Due Date']='Atlikti iki';
$translations['Project Name']='Projekto pavadinimas';
$translations['All Projects']='Visi projektai';
$translations['Display projects with status']='Rodyti projektus su statusais';
$translations['Projects status']='Projektų statusai';
$translations['Project Manager']='Projekto vadovas';
$translations['Bug tracker']='Klaidų sekimas';
$translations['Projects List']='';
$translations['Display only my projects']='Rodyti tik mano projektus';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planuojamas';
$translations['Projects & Tickets']='';
$translations['Active projects']='Einamieji projektai';
$translations['Projects: %s']='';
