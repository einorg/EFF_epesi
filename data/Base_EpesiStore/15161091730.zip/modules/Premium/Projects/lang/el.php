<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage el
 */
global $translations;
$translations['Completed']='Ολοκληρωμένο';
$translations['Approved']='Εγγεκριμένο';
$translations['Projects']='Έργα';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='Ημερομηνία λήξης';
$translations['Project Name']='Όνομα έργου';
$translations['All Projects']='Όλα τα έργα';
$translations['Display projects with status']='Προβολή έργων με κατάσταση';
$translations['Projects status']='Κατάσταση έργων';
$translations['Project Manager']='';
$translations['Bug tracker']='Bug tracker';
$translations['Projects List']='Λίστα Έργων';
$translations['Display only my projects']='Εμφάνιση μόνο των έργων μου';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Προγραμματισμένο';
$translations['Projects & Tickets']='Εργασίες & Εισιτήρια';
$translations['Active projects']='Ενεργά έργα';
$translations['Projects: %s']='Έργα: %s';
