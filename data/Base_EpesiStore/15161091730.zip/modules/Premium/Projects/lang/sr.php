<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sr
 */
global $translations;
$translations['Completed']='';
$translations['Approved']='';
$translations['Projects']='';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='';
$translations['Project Name']='';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='';
$translations['Project Manager']='';
$translations['Bug tracker']='';
$translations['Projects List']='';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='';
$translations['Projects & Tickets']='';
$translations['Active projects']='';
$translations['Projects: %s']='';
