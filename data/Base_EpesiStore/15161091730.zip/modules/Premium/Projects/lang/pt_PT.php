<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage pt_PT
 */
global $translations;
$translations['Completed']='Completo';
$translations['Approved']='Aprovado';
$translations['Projects']='Projetos';
$translations['Contact as customer']='Contactar como cliente';
$translations['Contact as project manager']='Contactar como Gestor do projeto';
$translations['Contact as employee']='';
$translations['Due Date']='Prazo de execução';
$translations['Project Name']='Nome do projeto';
$translations['All Projects']='Todos os projetos';
$translations['Display projects with status']='Mostrar projetos por estado';
$translations['Projects status']='Estado do Projeto';
$translations['Project Manager']='Gestor do projeto';
$translations['Bug tracker']='Projetos/Requisições';
$translations['Projects List']='Lista de projetos';
$translations['Display only my projects']='Mostrar apenas os meus projetos';
$translations['Project (attachment) #%d, %s']='Projeto (anexo) #%d, %s';
$translations['Planned']='Planejado';
$translations['Projects & Tickets']='Projetos & Requisições';
$translations['Active projects']='Projetos ativos';
$translations['Projects: %s']='Projetos: %s';
