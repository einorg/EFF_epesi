<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fr
 */
global $translations;
$translations['Completed']='Terminé';
$translations['Approved']='Approuvé';
$translations['Projects']='Projets';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='';
$translations['Project Name']='Nom du projet';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='Etat des projets';
$translations['Project Manager']='Resp. Projets';
$translations['Bug tracker']='Traqueur de Bug';
$translations['Projects List']='';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planifié';
$translations['Projects & Tickets']='Projets et Tickets';
$translations['Active projects']='Project en cours';
$translations['Projects: %s']='';
