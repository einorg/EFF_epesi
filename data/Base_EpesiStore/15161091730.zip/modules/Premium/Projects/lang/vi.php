<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage vi
 */
global $translations;
$translations['Completed']='Đã nghiệm thu';
$translations['Approved']='Tiếp nhận';
$translations['Projects']='Dự án';
$translations['Contact as customer']='Liên hệ với khách hàng';
$translations['Contact as project manager']='Liên hệ với Quản lý dự án';
$translations['Contact as employee']='Liên hệ với nhân viên';
$translations['Due Date']='Kết thúc';
$translations['Project Name']='Tên dự án';
$translations['All Projects']='Các dự án';
$translations['Display projects with status']='Trình bày dự án với tình trạng';
$translations['Projects status']='Dự án tình trạng';
$translations['Project Manager']='Quản lý dự án';
$translations['Bug tracker']='Theo dõi';
$translations['Projects List']='Công trình';
$translations['Display only my projects']='Chỉ hiển thị các dự án của tôi';
$translations['Project (attachment) #%d, %s']='Dự án (đính kèm) #% d,% s';
$translations['Planned']='Chờ giao phiếu';
$translations['Projects & Tickets']='Dự án và Tickets';
$translations['Active projects']='Hoạt động dự án';
$translations['Projects: %s']='Dự án: %s';
