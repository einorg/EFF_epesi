<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage et
 */
global $translations;
$translations['Completed']='Lõpetatud';
$translations['Approved']='Heakskiidetud';
$translations['Projects']='Projektid';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='Tähtaeg';
$translations['Project Name']='Projekti nimi';
$translations['All Projects']='Kõik projektid';
$translations['Display projects with status']='Kuva staatusega projektid';
$translations['Projects status']='Projekti olek';
$translations['Project Manager']='';
$translations['Bug tracker']='Bugijälitaja';
$translations['Projects List']='';
$translations['Display only my projects']='Kuva ainult minu projekte';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Planeeritud';
$translations['Projects & Tickets']='';
$translations['Active projects']='Aktiivsed projektid';
$translations['Projects: %s']='Projektid: %s';
