<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage hu
 */
global $translations;
$translations['Completed']='Befejezett';
$translations['Approved']='Jóváhagyott';
$translations['Projects']='Projektek';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='';
$translations['Project Name']='Projekt neve';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='Projekt státusz';
$translations['Project Manager']='Projekt menedzser';
$translations['Bug tracker']='Bug követő';
$translations['Projects List']='';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='Tervezett';
$translations['Projects & Tickets']='';
$translations['Active projects']='';
$translations['Projects: %s']='';
