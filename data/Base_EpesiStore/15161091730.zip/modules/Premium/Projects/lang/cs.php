<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage cs
 */
global $translations;
$translations['Completed']='Hotovo';
$translations['Approved']='Schváleno';
$translations['Projects']='Projekty';
$translations['Contact as customer']='';
$translations['Contact as project manager']='';
$translations['Contact as employee']='';
$translations['Due Date']='Termín';
$translations['Project Name']='Název projektu';
$translations['All Projects']='Všechny projekty';
$translations['Display projects with status']='Zobraz projekty se statusem';
$translations['Projects status']='Stav projektů';
$translations['Project Manager']='Projektový manažer';
$translations['Bug tracker']='Projekty a Problémy';
$translations['Projects List']='Seznam projektů';
$translations['Display only my projects']='Zobrazit pouze mé projekty';
$translations['Project (attachment) #%d, %s']='Projekt (příloha) #%d, %s';
$translations['Planned']='Naplánováno';
$translations['Projects & Tickets']='Projekty a Problémy';
$translations['Active projects']='Aktivní projekty';
$translations['Projects: %s']='Projekty: %s';
