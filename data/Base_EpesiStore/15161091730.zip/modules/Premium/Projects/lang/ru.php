<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage ru
 */
global $translations;
$translations['Completed']='Завершено';
$translations['Approved']='Подтверждено';
$translations['Projects']='Проекты';
$translations['Contact as customer']='Связать с клиентом';
$translations['Contact as project manager']='Связать с проект менеджером';
$translations['Contact as employee']='Связать с сотрудником';
$translations['Due Date']='Срок сдачи';
$translations['Project Name']='Название проекта';
$translations['All Projects']='Все проекты';
$translations['Display projects with status']='Отобразить проекты со статусом';
$translations['Projects status']='Статус проектов';
$translations['Project Manager']='Руководитель проекта';
$translations['Bug tracker']='Отладчик';
$translations['Projects List']='Список проектов';
$translations['Display only my projects']='Отображать только мои проекты';
$translations['Project (attachment) #%d, %s']='Проект( вложение) #%d, %s';
$translations['Planned']='Запланировано';
$translations['Projects & Tickets']='Проекты и билеты';
$translations['Active projects']='Активные проекты';
$translations['Projects: %s']='Проекты: %s';
