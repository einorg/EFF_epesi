<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage fa
 */
global $translations;
$translations['Completed']='تکمیل شده';
$translations['Approved']='تایید شده';
$translations['Projects']='پروژه ها';
$translations['Contact as customer']='مخاطب به عنوان مشتری';
$translations['Contact as project manager']='';
$translations['Contact as employee']='مخاطب به عنوان کارمند';
$translations['Due Date']='موعد مقرر';
$translations['Project Name']='نام پروژه';
$translations['All Projects']='';
$translations['Display projects with status']='';
$translations['Projects status']='وضعیت پروژه';
$translations['Project Manager']='مدیر پروژه';
$translations['Bug tracker']='اشکالات';
$translations['Projects List']='لیست پروژه ها';
$translations['Display only my projects']='';
$translations['Project (attachment) #%d, %s']='';
$translations['Planned']='برنامه ریزی';
$translations['Projects & Tickets']='پروژه ها و درخواستهای پشتیبانی';
$translations['Active projects']='';
$translations['Projects: %s']='';
