<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage he
 */
global $translations;
$translations['Completed']='בוצע';
$translations['Approved']='אושר';
$translations['Projects']='פרויקטים';
$translations['Contact as customer']='';
$translations['Contact as project manager']='צור קשר עם מנהל הפרוייקט';
$translations['Contact as employee']='';
$translations['Due Date']='תאריך יעד';
$translations['Project Name']='שם פרויקט';
$translations['All Projects']='כל הפרויקטים';
$translations['Display projects with status']='הצג פרויקט עם סטטוס';
$translations['Projects status']='סטטוס פרויקט';
$translations['Project Manager']='מנהל פרויקט';
$translations['Bug tracker']='מעקב פניות';
$translations['Projects List']='רשימת פרויקטים';
$translations['Display only my projects']='הצג רק את הפרויקטים שלי';
$translations['Project (attachment) #%d, %s']='קבצי פרוייקט';
$translations['Planned']='תוכנן';
$translations['Projects & Tickets']='פרויקטים וכרטיסי עבודה';
$translations['Active projects']='פרוייקטים פעילים';
$translations['Projects: %s']='% פרויקט';
