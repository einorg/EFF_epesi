<?php
/**
 * Translation file.
 * @package epesi-translations
 * @subpackage sk
 */
global $translations;
$translations['Completed']='Hotovo';
$translations['Approved']='Schválene';
$translations['Projects']='Projekty';
$translations['Contact as customer']='Kontakt ako zákazník';
$translations['Contact as project manager']='Kontakt ako projektový manažér';
$translations['Contact as employee']='Kontakt ako zamestnanec';
$translations['Due Date']='Požadovaný dátum';
$translations['Project Name']='Názov projektu';
$translations['All Projects']='Všetky projekty';
$translations['Display projects with status']='Zobraz projekty so stavom';
$translations['Projects status']='Stav projektov';
$translations['Project Manager']='Projekt manažér';
$translations['Bug tracker']='Projekty a tikety';
$translations['Projects List']='Zoznam projektov';
$translations['Display only my projects']='Zobraziť len moje projekty';
$translations['Project (attachment) #%d, %s']='Projekt (príloha) #%d, %s';
$translations['Planned']='Naplánované';
$translations['Projects & Tickets']='Projekty a tikety';
$translations['Active projects']='Aktívne projekty';
$translations['Projects: %s']='';
