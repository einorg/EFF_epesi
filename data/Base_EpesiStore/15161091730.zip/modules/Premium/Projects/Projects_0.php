<?php
/**
 * Projects Tracker
 *
 * @author Janusz Tylek <jtylek@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_Projects extends Module {
	private $rb;

public function body() {
		// premium_projects=recordset, premium_projects_module=internal unique name for RB
		$this->rb = $this->init_module('Utils/RecordBrowser','premium_projects','premium_projects_module');
		// set defaults
		$sts = Utils_CommonDataCommon::get_translated_array('Premium_Projects_Status');
		$trans = array('__NULL__'=>array(), '__ALLACTIVE__'=>array('!status'=>array(0,2,4,5)));
		foreach ($sts as $k=>$v)
			$trans[$k] = array('status'=>$k);
		$me = CRM_ContactsCommon::get_my_record();
		$this->rb->set_custom_filter('status',array('type'=>'select','label'=>__('Projects status'),'args'=>array('__NULL__'=>'['.__('All').']','__ALLACTIVE__'=>'['.__('All active').']')+$sts,'trans'=>$trans));
		$this->rb->set_defaults(array('project_manager'=>$me['id'], 'start_date'=>date('Y-m-d')));
		$this->rb->set_filters_defaults(array('status'=>'__ALLACTIVE__'));
		$this->rb->set_default_order(array('project_name'=>'ASC'));		

        $fcallback = array('CRM_ContactsCommon','autoselect_company_contact_format');
        $this->rb->set_custom_filter('customer', array('type'=>'autoselect','label'=>__('Customer'),'args'=>array(), 'args_2'=>array(array('CRM_ContactsCommon','auto_company_contact_suggestbox'), array($fcallback)), 'args_3'=>$fcallback, 'trans_callback'=>array('CRM_ContactsCommon','autoselect_contact_filter_trans')));        
		$this->display_module($this->rb);
	}

public function applet($conf, & $opts) {
		$opts['go'] = true; // enable full screen
		$sts = Utils_CommonDataCommon::get_translated_array('Premium_Projects_Status');
		$rb = $this->init_module('Utils/RecordBrowser','premium_projects','premium_projects');
		$limit = null;
		$crits = array();
		$me = CRM_ContactsCommon::get_my_record();
		if ($conf['status']=='__ALL__') {
			$opts['title'] = __('All Projects');
		} elseif ($conf['status']=='__NULL__') {
			$opts['title'] = __('Active projects');
			$crits['!status'] = array(2,4);
		} else {
			$projstatus = $sts[$conf['status']];
			$opts['title'] = __('Projects: %s',array($projstatus));
			$crits['status'] = $conf['status'];
		}
		if ($conf['my']==1) {
			$crits['project_manager'] = array($me['id']);
		}

		// $conds - parameters for the applet
		// 1st - table field names, width, truncate
		// 2nd - criteria (filter)
		// 3rd - sorting
		// 4th - function to return tooltip
		// 5th - limit how many records are returned, null = no limit
		// 6th - Actions icons - default are view + info (with tooltip)
		
		$sorting = array('project_name'=>'ASC');
		$cols = array(
							array('field'=>'project_name', 'width'=>10),
							array('field'=>'customer', 'width'=>10)
										);

		$conds = array(
									$cols,
									$crits,
									$sorting,
									array('Premium_ProjectsCommon','applet_info_format'),
									$limit,
									$conf,
									& $opts
				);
		$opts['actions'][] = Utils_RecordBrowserCommon::applet_new_record_button('premium_projects',array('project_manager'=>$me['id'], 'start_date'=>date('Y-m-d')));
		$this->display_module($rb, $conds, 'mini_view');
	}

public function company_premium_projects_addon($arg){
		$rb = $this->init_module('Utils/RecordBrowser','premium_projects');
		$rb->set_defaults(array('customer'=>array('C:'.$arg['id'])));
		$proj = array(array('customer'=>'C:'.$arg['id']), array('customer' => false), array('Fav'=>'DESC'));
		$this->display_module($rb,$proj,'show_data');
	}

    public function contact_premium_projects_addon($arg) {
        $rb = $this->init_module('Utils/RecordBrowser', 'premium_projects');
        $defaults = array('customer' => array('P:' . $arg['id']));
        $multiple = false;
        // check if it's employee
        $main_company = CRM_ContactsCommon::get_main_company();
        if ($arg['company_name'] == $main_company
                || array_search($main_company, $arg['related_companies']) !== false) {
            $defaults = array(
                _M('Contact as customer') => array('icon' => null, 'defaults' => $defaults),
                _M('Contact as project manager') => array('icon' => null, 'defaults' => array('project_manager' => array($arg['id']))),
                _M('Contact as employee') => array('icon' => null, 'defaults' => array('employees' => array($arg['id'])))
            );
            $multiple = true;
        }
        $rb->set_defaults($defaults, $multiple);
        $proj = array(array('(customer' => 'P:' . $arg['id'], '|project_manager' => $arg['id'], '|employees' => $arg['id']), array(), array('Fav' => 'DESC'));
        $this->display_module($rb, $proj, 'show_data');
    }

    public function caption(){
		if (isset($this->rb)) return $this->rb->caption();
	}
}

?>