<?php
/**
 * Projects Tracker
 *
 * @author Janusz Tylek <jtylek@telaxus.com>, Adam Bukowski <abukowski@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.4.1
 * @package epesi-premium
 * @subpackage projects
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_ProjectsInstall extends ModuleInstall {
    const version = '1.7.1';

	public function install() {
		Base_LangCommon::install_translations($this->get_type());
		
		Base_ThemeCommon::install_default_theme($this->get_type());
		$fields = array(
			array('name' => _M('Project Name'), 	'type'=>'text', 'required'=>true, 'param'=>'64', 'extra'=>false, 'visible'=>true,'display_callback'=>array('Premium_ProjectsCommon', 'display_proj_name')),
            array('name' => _M('Customer'), 'type' => 'crm_company_contact', 'required' => true, 'param' => array('field_type' => 'multiselect'), 'extra' => false, 'visible' => true, 'filter' => true),
			array('name' => _M('Project Manager'),'type'=>'crm_contact', 'param'=>array('field_type'=>'select', 'crits'=>array('Premium_ProjectsCommon','projects_employees_crits'), 'format'=>array('CRM_ContactsCommon','contact_format_no_company')), 'required'=>true, 'visible'=>true, 'extra'=>false, 'filter'=>true),
            array('name' => _M('Employees'), 'type' => 'crm_contact', 'required' => false, 'param' => array('field_type' => 'multiselect', 'crits' => array('CRM_ContactsCommon', 'employee_crits')), 'extra' => false, 'visible' => true, 'filter' => true),
			array('name' => _M('Status'), 		'type'=>'commondata', 'required'=>true, 'visible'=>true, 'filter'=>true, 'param'=>array('order_by_key'=>true,'Premium_Projects_Status'), 'extra'=>false),
			array('name' => _M('Start Date'), 	'type'=>'date', 'required'=>false, 'param'=>64, 'extra'=>false),
			array('name' => _M('Due Date'), 		'type'=>'date', 'required'=>false, 'param'=>64, 'extra'=>false),
			array('name' => _M('Description'), 	'type'=>'long text', 'required'=>false, 'param'=>'250', 'extra'=>false)
		);

		Utils_RecordBrowserCommon::install_new_recordset('premium_projects', $fields);
		Utils_RecordBrowserCommon::new_filter('premium_projects', 'Status');
		
		Utils_RecordBrowserCommon::set_quickjump('premium_projects', 'Project Name');
		Utils_RecordBrowserCommon::set_favorites('premium_projects', true);
		Utils_RecordBrowserCommon::set_recent('premium_projects', 15);
		Utils_RecordBrowserCommon::set_caption('premium_projects', _M('Projects'));
		Utils_RecordBrowserCommon::set_icon('premium_projects', Base_ThemeCommon::get_template_filename('Premium/Projects', 'icon.png'));
		Utils_RecordBrowserCommon::enable_watchdog('premium_projects', array('Premium_ProjectsCommon','watchdog_label'));
        Utils_RecordBrowserCommon::set_search('premium_projects',2,0);

// ************ addons ************** //
		Utils_AttachmentCommon::new_addon('premium_projects');
		Utils_RecordBrowserCommon::new_addon('company', 'Premium/Projects', 'company_premium_projects_addon', _M('Projects'));
		Utils_RecordBrowserCommon::new_addon('contact', 'Premium/Projects', 'contact_premium_projects_addon', _M('Projects'));

// ************ other ************** //	
		Utils_CommonDataCommon::new_array('Premium_Projects_Status',array(0=>_M('Planned'),1=>_M('Approved'),2=>_M('Canceled'),3=>_M('In Progress'),4=>_M('Completed'),5=>_M('On Hold')),true,true);
		
		Utils_RecordBrowserCommon::add_access('premium_projects', 'view', 'ACCESS:employee');
		Utils_RecordBrowserCommon::add_access('premium_projects', 'add', 'ACCESS:employee');
		Utils_RecordBrowserCommon::add_access('premium_projects', 'edit', 'ACCESS:employee');
		Utils_RecordBrowserCommon::add_access('premium_projects', 'selection', 'ACCESS:employee',array('!status'=>2,'_!status'=>4));
		Utils_RecordBrowserCommon::add_access('premium_projects', 'delete', 'ACCESS:employee', array(':Created_by'=>'USER_ID'));
 		Utils_RecordBrowserCommon::add_access('premium_projects', 'delete', array('ACCESS:employee','ACCESS:manager'));
		
		return true;
	}
	
	public function uninstall() {
		Base_ThemeCommon::uninstall_default_theme($this->get_type());
		Utils_AttachmentCommon::delete_addon('premium_projects');
		Utils_RecordBrowserCommon::delete_addon('company', 'Premium/Projects', 'company_premium_projects_addon');
		Utils_RecordBrowserCommon::uninstall_recordset('premium_projects');
		Utils_CommonDataCommon::remove('Premium_Projects_Status');
		return true;
	}
	
	public function version() {
		return array(self::version);
	}
	
	public function requires($v) {
		return array(
			array('name'=>'Base','version'=>0),
			array('name'=>'Utils/ChainedSelect', 'version'=>0), 
			array('name'=>'CRM/Contacts','version'=>0));
	}
	
	public static function info() {
		return array(
			'Description'=>'Projects Tracker - Premium Module',
			'Author'=>'jtylek@telaxus.com',
			'License'=>'MIT');
	}
	
    public static function simple_setup() {
        return array('package'=>__('Projects & Tickets'), 'version' => self::version);
    }
}

?>
