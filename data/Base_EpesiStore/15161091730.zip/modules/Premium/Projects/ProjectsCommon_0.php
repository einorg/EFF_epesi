<?php
/**
 * Projects Tracker
 *
 * @author Janusz Tylek <jtylek@telaxus.com>
 * @copyright Copyright &copy; 2008, Telaxus LLC
 * @license MIT
 * @version 1.0
 * @package epesi-premium
 * @subpackage projects
 */
defined("_VALID_ACCESS") || die('Direct access forbidden');

class Premium_ProjectsCommon extends ModuleCommon {
    public static function get_project($id) {
		return Utils_RecordBrowserCommon::get_record('premium_projects', $id);
    }

	public static function get_projects($crits=array(),$cols=array()) {
    		return Utils_RecordBrowserCommon::get_records('premium_projects', $crits, $cols);
	}

    public static function display_proj_name($v, $nolink=false) {
		return Utils_RecordBrowserCommon::create_linked_label_r('premium_projects', 'Project Name', $v, $nolink);
	}

    public static function menu() {
		if (Utils_RecordBrowserCommon::get_access('premium_projects','browse'))
			return array(_M('Bug tracker')=>array('__submenu__'=>1,_M('Projects')=>array()));
		else
			return array();
	}

// Filter criteria for Company Name
	public static function projects_company_crits(){
//  	   return array(':Fav'=>1);
// gc= GC (General Contractor), res=Residential
		return array('group'=>array('customer'));
   }

// Filter criteria for Epmloyees
// Used in Project Manager
	public static function projects_employees_crits(){
		return array('(company_name'=>CRM_ContactsCommon::get_main_company(),'|related_companies'=>array(CRM_ContactsCommon::get_main_company()));
   }


	public static function applet_caption() {
		if (Utils_RecordBrowserCommon::get_access('premium_projects','browse'))
			return __('Projects');
	}
	public static function applet_info() {
		return __('Projects List');
	}

	public static function applet_info_format($r){
		$arr = array(
			__('Project Name')=>$r['project_name'],
			__('Due Date')=>Base_RegionalSettingsCommon::time2reg($r['due_date'], false),
			__('Description')=>htmlspecialchars($r['description'])
		);
		$ret = array('notes'=>Utils_TooltipCommon::format_info_tooltip($arr));
		return $ret;
	}


	public static function applet_settings() {
		$sts = Utils_CommonDataCommon::get_array('Premium_Projects_Status');
		return Utils_RecordBrowserCommon::applet_settings(array(
			array('name'=>'status','label'=>__('Display projects with status'),'default'=>3,'type'=>'select','values'=>array('__NULL__'=>'['.__('All active').']','__ALL__'=>'['.__('All').']')+$sts),
			array('name'=>'my','label'=>__('Display only my projects'),'default'=>1,'type'=>'select','values'=>array(0=>__('No'),1=>__('Yes'))),
			));
	}
	
	public static function watchdog_label($rid = null, $events = array(), $details = true) {
		return Utils_RecordBrowserCommon::watchdog_label(
				'premium_projects',
				__('Projects'),
				$rid,
				$events,
				'project_name',
				$details
			);
	}
	
	public static function search_format($id) {
		if(!Utils_RecordBrowserCommon::get_access('premium_projects','browse')) return false;
		$row = self::get_projects(array('id'=>$id));
		if(!$row) return false;
		$row = array_pop($row);
		return Utils_RecordBrowserCommon::record_link_open_tag('premium_projects', $row['id']).__( 'Project (attachment) #%d, %s', array($row['id'], $row['project_name'])).Utils_RecordBrowserCommon::record_link_close_tag();
	}


	
	///////////////////////////////////
	// mobile devices

	public static function mobile_menu() {
		if(!Acl::is_user())
			return array();
		return array(__('Projects')=>'mobile_projects');
	}
	
	public static function mobile_projects() {
		$me = CRM_ContactsCommon::get_my_record();
		$defaults = array('project_manager'=>$me['id'], 'start_date'=>date('Y-m-d'));
		Utils_RecordBrowserCommon::mobile_rb('premium_projects',array('project_manager'=>$me['id'], '!status'=>array(2,4)),array('project_name'=>'ASC'),array('customer'=>1,'status'=>1),$defaults);
	}
}
?>
