<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::new_record_field('premium_projects', array(
    'name' => _M('Employees'),
    'type' => 'crm_contact',
    'required' => false,
    'param' => array('field_type' => 'multiselect', 'crits' => array('CRM_ContactsCommon', 'employee_crits')),
    'extra' => false,
    'visible' => true,
    'filter' => true,
    'position' => 'Project Manager'
));
?>