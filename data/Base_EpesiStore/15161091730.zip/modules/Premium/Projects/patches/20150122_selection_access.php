<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::add_access('premium_projects', 'selection', 'ACCESS:employee',array('!status'=>2,'_!status'=>4));
