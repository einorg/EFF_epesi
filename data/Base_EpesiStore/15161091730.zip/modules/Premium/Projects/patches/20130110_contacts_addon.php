<?php
defined("_VALID_ACCESS") || die('Direct access forbidden');

Utils_RecordBrowserCommon::new_addon('contact', 'Premium/Projects', 'contact_premium_projects_addon', _M('Projects'));
?>